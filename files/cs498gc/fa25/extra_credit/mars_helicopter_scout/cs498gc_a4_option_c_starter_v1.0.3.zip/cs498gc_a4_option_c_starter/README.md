# cs498gc_a4_option_c_starter (v1.0.3)

TA starter package for CS 498 GC / ABE 426 Assignment 4 Extra Credit **Option C: Mars Helicopter
Scout**. Added in November 2026 for future offerings; Option C was not part of the Fall 2025 course.

It gives you a seeded Gazebo Harmonic Mars test site (160 m x 160 m), a near-orthographic orbital
camera, an Ingenuity-style four-rotor helicopter stand-in with a downward camera, a starter rover,
the ros_gz bridge, and the TA nodes that keep runs safe and gradable (flight watchdog, rover hazard
guard, idealized hazard camera, grader odometry relay, 20 Hz clock, run info, bonus drift model).
You write your own package `option_c_scout` (mapping, planning, flight, mosaicking, fusion, rover
executive); see `docs/HANDOUT.md`.

Tested on two machines, both Ubuntu 24.04 + ROS 2 Jazzy + Gazebo Harmonic with headless rendering
and an NVIDIA GPU: an arm64 NVIDIA DGX Spark (gz-sim 8.15) and an amd64 laptop with an RTX 5080
Laptop GPU (gz-sim 8.11, the version ROS 2 Jazzy's `gz_sim_vendor` package ships). Everything else
(Humble + Harmonic, Intel or AMD integrated GPUs, software rendering, macOS, Windows/WSL2, Docker)
is untested: read `docs/KNOWN_LIMITS.md` first.

## Build (3 commands)

The commands below use `~/option_c_ws` as the example workspace; any folder works (replace the path
in every command). Put this folder in `<workspace>/src/` (copy, unzip or clone), then:

```bash
source /opt/ros/jazzy/setup.bash
cd ~/option_c_ws && colcon build --symlink-install
source ~/option_c_ws/install/setup.bash
```

Needs `ros-jazzy-ros-gz` (Gazebo Harmonic plus the bridge) and colcon (`ros-dev-tools`). The TA
nodes use only ROS 2 and the Python standard library; `local_check` also needs python3-numpy,
python3-yaml and python3-pil (all three come with ROS 2 Jazzy desktop). `--symlink-install` is
recommended (edits to the tools take effect without a rebuild) but not required.

## Run the M0 smoke test on practice seed 7 (5 commands, three terminals)

Every terminal: `source /opt/ros/jazzy/setup.bash && source ~/option_c_ws/install/setup.bash`.

```bash
# terminal 1: world + TA nodes (headless:=false shows the Gazebo GUI)
ros2 launch cs498gc_a4_option_c_starter option_c_world.launch.py seed:=7 condition:=orbit_scout headless:=true
# terminal 2: record the graded topic list; wait for its READY line (about 4-10 s), and stop it
# with Ctrl-C after hello_sortie ends
ros2 run cs498gc_a4_option_c_starter record_option_c_bag 7 orbit_scout
# terminal 3, after READY: take off, hover at 10 m, fly 20 m, land, drive the rover 10 m, save the orbital frame
ros2 run cs498gc_a4_option_c_starter hello_sortie --save-orbital seed7_orbital_bev.png
# after Ctrl-C in terminal 2, from the folder you recorded in:
ros2 run cs498gc_a4_option_c_starter local_check --stage M0 --bag bags/seed7_orbit_scout --seed 7
```

`local_check` prints PASS or FAIL for each M0 criterion (scout held at 9-11 m for >= 15 s, landing
horizontal speed < 0.5 m/s, first orbital frame within 15 s, rover odometry >= 8 Hz, hazard camera
>= 4 Hz, no geofence or ceiling events) and checks the bag's world hash against the regenerated
world. `teleop_scout` (keyboard, needs a real terminal) is the manual alternative to hello_sortie.

**Condition orbit_only** (launch with `condition:=orbit_only`): the scout cannot take off there (the
watchdog rejects every takeoff). `hello_sortie` reads the condition from `/option_c/run_info` and
then only drives the rover 10 m (or pass `--rover-only`). To drive the rover by hand, run
`ros2 run cs498gc_a4_option_c_starter teleop_scout --rover` in a real terminal (w/s forward and
back, a/d turn, space stop, q quit). `local_check --stage M0` on an orbit_only bag (recorded with
`record_option_c_bag 7 orbit_only`) reads the condition from run_info and checks that the scout
stayed on the ground instead of the hover and landing criteria; the other criteria are the same.

**Shared machines.** Give every simulation that runs at the same time its own `ROS_DOMAIN_ID` and
`GZ_PARTITION` (export both in every terminal of that run, for example `export ROS_DOMAIN_ID=23
GZ_PARTITION=netid23`), and on a machine where several people share one home folder also its own
`OPTION_C_WORK_DIR` (or the launch argument `work_dir:=`): that is where the generated world and
its ground truth go (default `~/.ros/cs498gc_option_c`). Set these in the terminal, not in files of
your package: AG-26 flags `GZ_PARTITION` in package source for TA review (HANDOUT.md, section 3).

## Your three seeds

```bash
ros2 run cs498gc_a4_option_c_starter option_c_seed --netid yournetid
```

Seed 7 is free practice and never graded. Pass `student_pkg_src:=<path to src/option_c_scout>` to
the launch file for graded runs, so `/option_c/run_info` carries your code hash.

## What is in the package

| path | what |
|---|---|
| `launch/option_c_world.launch.py` | world for a seed + scout + rover + bridge + TA nodes. Args: seed, condition (orbit_only, orbit_scout), headless, gui, shadows, scout_dynamics (multicopter, kinematic), odom_mode (truth, drift), rover (starter, custom), rover_description_file, rover_footprint_radius_m, student_pkg_src, work_dir, gz_verbosity, render_engine_path |
| `launch/calib_tile.launch.py` | calibration world for M0b (four 1.0 m fiducials) |
| `config/option_c_bridge*.yaml` | ros_gz bridge (truth and drift modes) |
| `config/orbiter.yaml`, `config/scout_mount.yaml` | camera geometry you need for pixel-to-world |
| `config/option_c_template.yaml` | template for your `option_c/config/option_c.yaml` |
| `tools/gen_option_c_world.py` | stdlib world generator v1.1.0 (same seed gives the same bytes; the grader regenerates it). Its ground-truth JSON lists the route family and corridor-cut results behind the rock-field guarantees (KNOWN_LIMITS.md) |
| `tools/option_c_seed.py` | your seeds from your NetID |
| `tools/record_option_c_bag.sh` | records exactly the graded topic list (sqlite3), refuses images and raw /clock |
| `tools/record_images_debug.sh` | records camera images for your own offline debugging (never submit) |
| `tools/check_projection.py` | M0b: tests your pixel-to-ground function on calib_tile |
| `tools/local_check.py` | M0 checks, and every autograder check on your submission folder: it runs the grader's own check code (`tools/option_c_grading/`, the same files as the Gradescope autograder) |
| `tools/make_submission.sh` | checks the submission tree and writes `<netid>_a4_option_c.zip` |
| `option_c_starter/` | TA nodes: run_info_publisher, scout_safety_watchdog, scout_odom_relay, clock_decimator, rover_hazard_guard, hazcam_sim, odom_degrader, teleop_scout |
| `models/` | mars_ground, option_c_orbiter, ingenuity_quad_approx (+ kinematic variant), option_c_rover |
| `xacro/odom_truth_plugin.xacro` | OdometryPublisher snippet for a custom (Part B) rover |
| `examples/hello_sortie.py` | the M0 flight (rover only in orbit_only) |
| `examples/pixel_to_ground_stub.py` | skeleton of your M0b function (interface of `check_projection`) |
| `docs/` | HANDOUT, TOPICS, FRAMES, INGENUITY_FACTS, KNOWN_LIMITS, CREDITS |
| `test/` | generator determinism, bridge config (and opt-in live smoke test), tool unit tests |

Run the package tests with `colcon test --packages-select cs498gc_a4_option_c_starter` and
`colcon test-result --verbose`.

## Rules that keep your runs gradable

- Never publish `/ingenuity/gazebo/command/twist`, `/ingenuity/gazebo/command/enable`,
  `/model/ingenuity_quad_approx/cmd_vel` or `/option_c/rover/cmd_vel`: the TA watchdog and guard
  own them. You publish `/ingenuity/enable`; the watchdog forwards it and ignores false while the
  scout is airborne (event enable_ignored), so land before you disable.
- Never subscribe to anything under `/option_c/grader/` and never read the generated world SDF or
  the ground-truth JSON in your code. Talk to the simulator through the TA launch and ROS topics
  only: no bridge or Gazebo transport of your own (source check AG-26, HANDOUT.md section 3).
- Record graded bags only with `record_option_c_bag` and keep each bag at or below 25 MB. Start
  the world, then the recorder, wait for its `READY` line, and only then launch your mission.
- Publish `/option_c/mission_phase` (depth >= 100), `/option_c/rover/active_path` (depth >= 20)
  and `/option_c/sortie_plan` (depth >= 5) as reliable + transient_local, like the costmaps and
  paths: rosbag2 needs 1 to 3 s to discover a new node and would otherwise miss your first events
  (`docs/TOPICS.md`, "Durability").
