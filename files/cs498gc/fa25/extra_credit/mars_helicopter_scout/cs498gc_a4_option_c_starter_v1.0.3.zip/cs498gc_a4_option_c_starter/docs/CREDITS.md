# Credits

## What the starter contains

- All models, worlds and textures in this package were made for the course from simple shapes
  and stdlib code: the Mars ground texture is procedural noise written by
  `tools/make_ground_assets.py`, and the scout is built from boxes, cylinders and disks. The
  package contains no NASA images, logos or meshes.
- The scout's look (box fuselage, two coaxial rotor disks, mast, solar panel, four legs) is
  inspired by NASA/JPL's Ingenuity Mars Helicopter. It is a stand-in, not a model of Ingenuity
  (KNOWN_LIMITS.md).
- NASA's official Ingenuity 3D model (ING-63) is not used. If a later release adds it as an
  optional visual-only mesh, it will be credited 'Courtesy NASA/JPL-Caltech' (ING-62).

## If you use NASA or HiRISE images in your report or video

- NASA/JPL images: credit 'Courtesy NASA/JPL-Caltech' unless the caption on the source page says
  otherwise (JPL Image Use Policy, https://www.jpl.nasa.gov/jpl-image-use-policy/, ING-62).
- HiRISE images: credit 'NASA/JPL/University of Arizona'.
- Do not use the NASA insignia ('meatball') or the JPL logo.
- Cite every NASA number you quote with its source; INGENUITY_FACTS.md lists them with URLs.

## Software

- Gazebo Harmonic (gz-sim 8) and ros_gz: Apache License 2.0, Open Robotics and contributors.
- ROS 2 Jazzy: Apache License 2.0 and other open-source licenses, Open Robotics and contributors.
- The multicopter flight recipe (MulticopterMotorModel + MulticopterVelocityControl with Mars
  gravity), the near-orthographic orbital camera with explicit lens intrinsics and the bridge
  strings were verified for this course by the course staff on an NVIDIA DGX Spark in November
  2026.

## Course

CS 498 GC / ABE 426 Mobile Robotics for Computer Scientists, University of Illinois
Urbana-Champaign. Option C was added in November 2026 for future offerings; it was not part of
the Fall 2025 course.
