# Frames, cameras and pixel-to-world formulas

Everything here was measured on the starter (DGX Spark arm64 with gz-sim 8.15; the M0b and orbital
checks were repeated on an amd64 RTX 5080 laptop with gz-sim 8.11; both ROS 2 Jazzy). The formulas are
the ones the grader uses. Your report derives them (MR-1, MR-2); this page gives the conventions.

## World and map frame

- ROS frame `map` is the Gazebo world frame of world `mars_scout`: x east, y north, z up, meters.
  The site is flat ground at z = 0 over [-80, 80] x [-80, 80] m.
- Both odometry streams you may use (`/model/ingenuity_quad_approx/odometry` for the scout,
  `/option_c/rover/odom_truth` for the rover) come from Gazebo's OdometryPublisher. Their pose is
  the vehicle's base_link pose **in the world frame**, whatever the frame_id strings say (they are
  Gazebo-scoped names, see the table at the end). Do not rely on TF frame names; use the poses.
- The scout's base_link is at the body center; on the pad z is about 0.08 m. The rover's base_link
  is on the ground between the wheels (z about 0).

## Orbital camera (near-orthographic BEV)

- Static model `orbiter`, sensor `bev_cam`, pose `0 0 6000 0 1.5707963 1.5707963` (roll, pitch,
  yaw): looking straight down from 6000 m, image up = north (+y), image right = east (+x).
- 320 x 320 rgb8, 0.5 Hz, explicit intrinsics fx = fy = 12000, cx = cy = 160 (read them from
  `/orbiter/bev_cam/camera_info`, K = [fx 0 cx; 0 fy cy; 0 0 1]).
- Pixel (u, v), with u the column index and v the row index (v = 0 is the top row), maps to

      x = X0 + (u - cx) * Z / fx
      y = Y0 - (v - cy) * Z / fy        with X0 = Y0 = 0, Z = 6000 m (config/orbiter.yaml)

  so one pixel is Z / fx = 0.5 m and the image covers exactly the 160 m x 160 m site.
  The inverse is u = cx + x fx / Z, v = cy - y fy / Z.
- Half-pixel convention (measured, state yours in the report): with u and v the integer pixel
  index, the rendered image puts the center of pixel u at u + 0.5 in the formula above. The
  course staff compared the sand patch seen in the image with its ground-truth polygon on seeds 7 and
  202: the observed blob sat 0.45-0.54 px left of and above the polygon's area centroid computed
  with integer indices, on both axes and both seeds. So with integer indices every point comes out
  about 0.25 m west and 0.25 m north of the truth (0.35 m, about 0.7 of an orbital costmap cell);
  with x = X0 + (u + 0.5 - cx) Z / fx and y = Y0 - (v + 0.5 - cy) Z / fy the offset was below
  0.03 m. Boulders (shadow-free frames, 34-35 per seed) agreed within one pixel with either form.
  Either convention is acceptable if you state it; u + 0.5 is the one the renderer matches.
- It is a perspective camera at high altitude, not a true orthographic camera (Gazebo Harmonic has
  none). A 2 m tall object at the image corner (113 m off nadir) leans by about 0.08 px; ignore it.
- Shadows: the sun is 35 deg above the horizon in the south-west. In the ORBITAL image the
  hazards cast NO shadow on the ground (the course staff found frames recorded with shadows on
  and off byte-identical); a boulder appears only as a self-shaded ellipse, about 6 px across, lit on its
  south-west side with a dark rim on its north-east side. Do not look for cast shadows in the
  orbital image (unlike HiRISE rock mapping, F05). Cast shadows toward the north-east do appear in
  the scout's nadir images, so launch option `shadows:=false` changes only the nadir images.

## Grids (costmaps and mosaic)

- OccupancyGrid cell (row i, column j) has its center at x = -80 + (j + 0.5) res,
  y = -80 + (i + 0.5) res, and is `data[i * width + j]`. Row 0 is the SOUTH edge (y = -80).
  An image row 0 is the NORTH edge: flip rows when you turn the orbital image into a grid.
- Orbital costmap: res 0.50, 320 x 320; fused costmap: res 0.25, 640 x 640; both origin
  (-80, -80), identity orientation.
- Mosaic (scout_mosaic.png, 1600 x 1600 RGBA, 0.10 m/px, north-up): pixel (row r, col c) center
  x = -80 + (c + 0.5) 0.10, y = -80 + (1600 - r - 0.5) 0.10. Here row 0 is the NORTH edge.

## Nadir camera on the scout

- Sensor `nadir_cam` on base_link, pose `0 0 -0.08 0 1.5707963 0` (config/scout_mount.yaml):
  8 cm below the body center, optical axis pointing down (-z of base_link).
- 320 x 240 rgb8, horizontal FOV 1.2 rad, 2 Hz, K: fx = fy = 233.87, cx = 160, cy = 120 (read
  them from `/ingenuity/nadir_cam/camera_info`; one camera_info per image, same stamp).
- Image axes: image up = body forward (+x of base_link), image right = body right (-y of
  base_link). The ray of pixel (u, v) expressed in base_link is

      d_b = ( -(v - cy) / fy ,  -(u - cx) / fx ,  -1 )

- Ground point of pixel (u, v), given the scout pose at the image stamp (position p, orientation
  q as a rotation R(q) from base_link to world):

      c   = p + R(q) (0, 0, -0.08)          camera center in the world
      d_w = R(q) d_b                         ray in the world
      s   = -c_z / d_w,z                     intersect the plane z = 0
      (x, y) = (c_x + s d_w,x , c_y + s d_w,y)

  The half-pixel rule of the orbital camera most likely holds here too (not measured separately:
  half a pixel is about 2 cm at 10 m, below what the M0b fiducials resolve).
  Interpolate the pose to the image stamp (linear position, slerp orientation) from the 20 Hz
  odometry. Use the full orientation. Examples from the course staff's M0b runs at 12 m (1 m/s
  pass): the formula above with the full pose had a worst fiducial error of 0.04-0.05 m in every
  run, while the same formula with roll and pitch ignored had worst errors from about 0.5 m to
  1.9 m, depending on how much the body happened to be tilted when a fiducial was in view (body
  tilt at those frames from about 2 deg to 8 deg in different runs). Your numbers will differ
  from run to run; M0b asks you to measure this for your own function.
- Footprint and scale: at 10 m altitude the image covers about 13.7 m (across, image u) x 10.3 m
  (along, image v), 4.28 cm per pixel at the center; 3.4 cm/px at 8 m and 6.4 cm/px at 15 m.
- M0b check: `tools/check_projection.py` flies the scout over `worlds/calib_tile.sdf` (1.0 m
  fiducials: red (+5, +5), green (-5, +5), blue (-5, -5), white (+5, -5)) and calls your function
  `pixel_to_ground(u, v, K, pose) -> (x, y)` with: u, v the float pixel coordinates of a fiducial
  centroid (u column, v row, v = 0 at the top); K the 9 numbers of CameraInfo.k (row-major,
  `[fx, 0, cx, 0, fy, cy, 0, 0, 1]`); pose a dict with keys x, y, z, qx, qy, qz, qw, the base_link
  pose in the map frame interpolated to the image stamp (the p and q above). Return the ground
  point (x, y) in meters. `--module-path` is the folder that holds your module file (any folder;
  no package or build needed), and `examples/pixel_to_ground_stub.py` is a skeleton with this
  interface. The course staff's implementation of the formula above, and the stub completed
  only from this page, passed (KNOWN_LIMITS.md, "What was tested").
- Flat ground is exact here; on real terrain the plane z = 0 is wrong, which is what MR-2 asks you
  to discuss (compare Ingenuity's flat-ground assumption, ING-24, F38).

## Command frames

- `/option_c/scout/cmd_vel`: WORLD frame ENU (linear.x east, linear.y north, linear.z up) and
  angular.z yaw rate. The watchdog rotates xy into the vehicle heading frame for the controller,
  so you never need the vehicle yaw to fly a world-frame path. Any yaw works for mapping because
  the projection uses the full pose; a constant yaw keeps frames easy to compare. The watchdog
  ramps the horizontal part at 1 m/s^2 in the world frame (TOPICS.md).
- `/option_c/rover/cmd_vel_request`: rover BODY frame (linear.x forward, angular.z yaw rate).
- `/option_c/rover/hazcam`: PoseArray in `map`; only positions carry meaning.

## Frame id strings seen on the topics

The OdometryPublisher and camera bridges use Gazebo-scoped names. Measured on seed 7 (Jazzy;
gz-sim 8.15 on the arm64 test machine and 8.11 on the amd64 one, identical strings); treat them as
labels only:

| topic | header.frame_id / child_frame_id |
|---|---|
| `/model/ingenuity_quad_approx/odometry`, `/option_c/grader/scout_odom` | `ingenuity_quad_approx/odom` / `ingenuity_quad_approx/base_footprint` |
| `/option_c/rover/odom_truth` | `rover/odom` / `rover/base_footprint` |
| `/ingenuity/nadir_cam/camera_info` | `ingenuity_quad_approx/base_link/nadir_cam` |
| `/orbiter/bev_cam/camera_info` | `orbiter/link/bev_cam` |
| `/option_c/rover/hazcam` | `map` |

Despite the names `odom` and `base_footprint`, the odometry pose is the base_link pose in the world
frame (the vehicle spawns at its helipad or start position, not at the origin, and the poses
report those world coordinates).

## Machines with both Gazebo Harmonic and Gazebo Jetty installed

Launching a camera world with plain `gz sim` there can load Jetty's rendering plugin and crash.
Two verified fixes: (1) launch from a shell that sourced `/opt/ros/jazzy/setup.bash` (the launch
files always do this through ros_gz_sim with gz_version 8), or (2) launch with
`render_engine_path:=auto` (or the full path of `libgz-rendering8-ogre2.so`), which loads a copy of
the world whose `<render_engine>` is that full path. Setting GZ_RENDERING_PLUGIN_PATH is not a fix.
