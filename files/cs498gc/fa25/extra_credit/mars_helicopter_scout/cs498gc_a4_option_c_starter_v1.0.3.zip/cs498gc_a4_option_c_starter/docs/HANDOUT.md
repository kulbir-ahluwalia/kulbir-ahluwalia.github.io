# A4 Extra Credit Option C: Mars Helicopter Scout

_Plan from orbit, scout from the air, drive on the ground._ CS 498 GC / ABE 426, Assignment 4,
extra credit. 50 points plus a 5-point bonus (Option C capped at 55); the semester syllabus sets
how options combine. Individual work. Added in November 2026 for future offerings; Option C was
not part of the Fall 2025 course.

Fact ids in brackets (ING-xx, Fxx) point to INGENUITY_FACTS.md, which gives every source.

## 1. Story

NASA's Ingenuity helicopter, mass 1.8 kg (ING-01), made 72 flights on Mars between April 19, 2021
and January 18, 2024 (ING-30, ING-31). After its technology demonstration it became an operations
demonstration whose goals included aerial observations of potential rover routes (ING-45). On
Flight 9 it flew 625 m in 166.4 s over the Seitah dune field, terrain too risky for Perseverance
(ING-47). Its images from about 10 m gave the rover team what Deputy Project Scientist Ken
Williford called intermediate-scale imagery that fills the gap in resolution between orbit and
rover (F33); mobility planners used them to judge where the rover could drive (ING-48), and on
Flight 12 its images confirmed that a planned route into South Seitah was traversable (F34). Its
last flight is a warning: about 20 s after takeoff its vision navigation could not find enough
features over steep, featureless sand ripples, and the most likely result was high horizontal
velocity at touchdown, which broke all four rotor blades (ING-39, ING-40, ING-41).

Why scout when orbiters already image Mars? HiRISE pixels are about 30 cm (F01), but rocks are
reliably resolved only from about 1.5 m across (F04, F05), and HiRISE has imaged about 4 percent of
the planet (F09). Orbital images are valuable for strategic route planning, but not every rover
hazard is visible in them (F16). In the Snowdrift Peak boulder field the straight-line route was
520 m, but Perseverance drove 759 m, much of it steering around rocks the orbiter images did not
show (F17). Planning from orbit is still where routes start: in December 2025 Perseverance drove
210 m and 246 m on waypoints generated from HiRISE imagery and slope data and checked in JPL's
digital twin before upload (F22).

You play the ground team for a 160 m x 160 m Mars test site, three worlds seeded from your NetID:

1. **Orbit only (condition O).** Map boulders and a sand patch from a near-orthographic orbital
   image, plan a rover route with your own A*, and drive it. Small rock fields that the orbital
   image cannot resolve lie across the route; your rover reacts only to its short-range hazard
   camera, as AutoNav does.
2. **Orbit + scout (condition S).** On a fresh copy of the same world, fly up to three helicopter
   sorties (at most 90 s each in the air) over the corridor. Between sorties, process the images on
   the ground: project every downward frame onto the terrain, mosaic them into a bird's-eye map at
   0.10 m/px, detect the rocks, fuse with the orbital map and replan. Then drive the scouted route
   with the same rover software and hazard camera.
3. **Compare.** Measure both runs on all three seeds and decide, with numbers, whether the flight
   time paid off.

Honesty notes: Ingenuity is a coaxial helicopter (two counter-rotating rotors, swashplate control,
ING-03, ING-05); it navigated with an IMU, a downward 640 x 480 grayscale camera at 30 Hz and a
laser altimeter (ING-13, ING-14, ING-20, ING-22), assumed flat ground (ING-23, ING-24), had no GPS
and built no map onboard. Its images were downlinked to Earth and used by ground teams; they did
not guide the rover in real time. The simulator scout is a four-rotor stand-in with Ingenuity's
mass in Mars gravity (about 3.71 m/s^2, ING-50); thin air is not simulated; thrust is tuned so it
hovers near 2,544 rpm, close to the 2,537 rpm Ingenuity flew on flights 1-13 (ING-07). Details:
KNOWN_LIMITS.md.

## 2. Learning objectives

- Explain with numbers why an orbital map supports strategic planning but cannot show every rover
  hazard, keeping pixel scale (GSD) separate from the smallest reliably detected object (F01, F04,
  F05, F16).
- Map image pixels to world coordinates for a calibrated pinhole camera with a known pose (read K
  from CameraInfo, compose the camera mount with the vehicle pose, intersect rays with the ground:
  inverse perspective mapping, F45; orthoimages, F46).
- Turn hazards into an occupancy/cost grid, inflate it for a circular rover footprint, and state a
  policy for unknown cells.
- Implement grid A* with an admissible heuristic (F44), compare it with a reference optimum, and
  reuse it for incremental replanning as the hazard camera reports obstacles (the idea of D*, F43).
- Plan coverage sorties under an airborne-time budget: altitude, line spacing and overlap from
  camera geometry, aimed at the corridor where the orbital plan is least certain.
- Close a velocity loop on an aerial vehicle and land below a touchdown-speed limit at a
  hazard-free site.
- Mosaic georeferenced nadir images into a bird's-eye map and say where the flat-ground assumption
  breaks (ING-24, ING-25, F38).
- Fuse maps of different resolutions, replan, and hand a verified path to a ground robot.
- Design and analyze a paired experiment (prediction first, paired differences, costs, failure
  cases, no overclaiming from n = 3).
- (Bonus) Correct drift by registering aerial imagery to the orbital map (as Mars 2020's Lander
  Vision System did, F29, and the Ingenuity-to-HiRISE orthomosaic work, F37).

## 3. What the starter gives you and what you write

The starter package `cs498gc_a4_option_c_starter` (README.md) gives the seeded world, the orbital
camera, the scout with its nadir camera, the starter rover, the bridge and the TA nodes: flight
watchdog, rover hazard guard, idealized hazard camera, grader odometry relay, 20 Hz clock, run
info, drift model (bonus), the recorder, the projection checker, the local checker and the
submission builder. TOPICS.md lists every topic; FRAMES.md every frame and formula.

You write one ROS 2 package `option_c_scout` (ament_python or ament_cmake) with these nodes (names
are suggestions; the topics are the contract):

| node | job |
|---|---|
| orbital_mapper | orbital image to world (0.5 m/px), boulder and sand detection, `orbital_hazards.csv`, inflated 0.50 m `/option_c/orbital_costmap` |
| global_planner | your own A*, Dijkstra or D* search (Part B A* may be reused; no Nav2 planner server or library planner) |
| sortie_planner | coverage under the budget, adapted between sorties; `/option_c/sortie_plan` before each takeoff |
| scout_flight_controller | waypoint following on `/option_c/scout/cmd_vel` (>= 10 Hz, world frame), takeoff, landing-site check, touchdown |
| nadir_mosaicker | ray-ground projection with the full 6-DoF pose, 1600 x 1600 RGBA mosaic at 0.10 m/px |
| scout_hazard_detector | rocks and boulders from the mosaic, `scout_hazards.csv` |
| map_fuser | 0.25 m `/option_c/fused_costmap` with your unknown-cell policy and the landed scout (0.35 m disk); hazcam insertion while driving |
| rover_executive | path follower plus hazcam-triggered replanning, ONE parameter set for both conditions (hash it into follower_params_sha256), 40 s stall abort |
| mission_manager | `/ingenuity/enable` and the JSON `/option_c/mission_phase` events |
| registration_node | bonus only |

Rules: never publish the TA-owned command topics (`/ingenuity/gazebo/command/twist`,
`/ingenuity/gazebo/command/enable`, `/model/ingenuity_quad_approx/cmd_vel`,
`/option_c/rover/cmd_vel`); never subscribe to `/option_c/grader/*`; never read the generated world
SDF or the ground-truth JSON in your code; talk to the simulator only through the TA launch file and
ROS topics (no `ros_gz_bridge` of your own, no Gazebo transport library, no `gz` command-line
tools); record graded bags only with `record_option_c_bag`.

Recording order and durability (v1.0.3): start the world, then `record_option_c_bag`, wait for its
`READY` line (rosbag2 has subscribed to every graded topic that is published; usually 4 to 10 s),
and only then launch your mission; stop the recorder with Ctrl-C after the rover finishes. Publish
`/option_c/mission_phase` (history depth >= 100), `/option_c/rover/active_path` (>= 20) and
`/option_c/sortie_plan` (>= 5) as reliable + transient_local, like the costmaps and paths the spec
already makes transient_local. rosbag2 needs 1 to 3 s to discover each new node, and a volatile
publisher never re-sends: in the staff's first reference runs this lost orbital_plan_ready in 4 of
6 bags and made one drive ungradable. With transient_local the recorder receives the earlier
messages when it subscribes, and the grader times them by their own `t_sim` or `header.stamp`
(TOPICS.md, "Durability"), so stamp them with sim time.

What AG-26 checks automatically (a hidden 0-point test; each hit is a flag for TA review, never an
automatic deduction): every text file in `src/option_c_scout` (binary files, files over 1 MB and the
build, install, log, .git and __pycache__ folders are skipped) is searched line by line, case
sensitive, for these strings: `/option_c/grader`, `hazards_seed`, `ground_truth`,
`ground_truth_file`, `gen_option_c_world`, `dynamic_pose`, `world_file`, `mars_scout_seed_`,
`drift_parameters`, `odom_degrader`, `gazebo/command`, `ros_gz_bridge`, `parameter_bridge`,
`gz.transport`, `gz_transport`, `gz.msgs`, `gz topic`, `gz service`, `gz model`, `GZ_PARTITION`;
and for three patterns: a `/world/<name>/pose/info` topic name, a `.sdf` file name, and the word
`gz` followed by `topic`, `service` or `model` after quotes, commas or spaces (as in a subprocess
argument list). The flag lists file and line numbers, never file contents. A string in a comment
counts too, so keep these names out of your package, and set `ROS_DOMAIN_ID` and `GZ_PARTITION` in
your terminal, not in package files. Not checked automatically, left to the TA's review of your
code, report and video: anything outside `src/option_c_scout` (for example a bridge or `gz` tool
started from a terminal, or a script kept elsewhere), names built at run time or renamed, and how
your nodes use the topics they may read. The rules hold whether or not a string is flagged.

## 4. Milestones (points bank in this order)

| milestone | what | cumulative points |
|---|---|---:|
| M0 | bring-up smoke test on practice seed 7 (not graded) | 0 |
| M1 | orbital map + A* (C2), orbit-only drive (C3), bring-up evidence (C1) | 17 |
| M2 | scout sorties (C4) | 24 |
| M3 | nadir mosaic and scout detections (C5) | 32 |
| M4 | fusion, replanning and hand-off drive (C6) | 40 |
| M5 | paired experiment, ablation, report, video (C7, C8) | 50 |

Suggested pace (about two weeks): days 1-3 M1, 4-6 M2, 7-9 M3, 10-11 M4, 12-14 M5.

### M0: bring-up (seed 7, not graded)

Follow README.md "Run the M0 smoke test": launch seed 7 (`condition:=orbit_scout headless:=true`),
start `record_option_c_bag 7 orbit_scout` and wait for its READY line, then run `hello_sortie` (or `teleop_scout`): take off from
the helipad, climb to 10 m, hover 20 s, fly 20 m, land, drive the rover 10 m and save the first
orbital frame. Then `local_check --stage M0 --bag bags/seed7_orbit_scout --seed 7`.
PASS: scout z in [9, 11] m for >= 15 s continuously; landing horizontal speed < 0.5 m/s; first
orbital frame within 15 s sim of launch; rover odometry >= 8 Hz; hazard camera >= 4 Hz; no
geofence or ceiling events.

Also bring up condition O once (`condition:=orbit_only`): the scout cannot take off there, so
`hello_sortie` sees the condition in run_info and only drives the rover (or pass `--rover-only`);
to drive by hand use `teleop_scout --rover` (w/s/a/d, space stop) in a real terminal. On an
orbit_only bag `local_check --stage M0` checks that the scout stayed on the ground instead of the
hover and landing criteria.

### M0b: projection unit test (calib_tile, not graded, evidence for MR-2)

Copy `examples/pixel_to_ground_stub.py` to a folder of your own, for example
`~/option_c_m0b/my_projection.py`, and write the projection (FRAMES.md, "Nadir camera on the
scout"). Then, in two terminals:

```bash
ros2 launch cs498gc_a4_option_c_starter calib_tile.launch.py headless:=true
ros2 run cs498gc_a4_option_c_starter check_projection --func my_projection:pixel_to_ground \
    --module-path ~/option_c_m0b --fly --out m0b.json
```

`--func` is `module:function`; `--module-path` is the folder that holds the module file (it is put
first on the Python path, so no package, `__init__.py` or build is needed; you do not have
`option_c_scout` yet at M0). Later, point `--module-path` at the folder of the module inside your
package to test the projection your mosaicker really uses. `check_projection --help` prints the
whole interface.

The tool calls your function `pixel_to_ground(u, v, K, pose) -> (x, y)` on each detected fiducial:
- `u`, `v`: float pixel coordinates of the fiducial centroid, u = column index, v = row index
  (v = 0 is the top row of the image);
- `K`: the list of the 9 numbers of `sensor_msgs/CameraInfo.k` from
  `/ingenuity/nadir_cam/camera_info`, row-major 3 x 3: `[fx, 0, cx, 0, fy, cy, 0, 0, 1]`;
- `pose`: a dict with float keys `x, y, z, qx, qy, qz, qw`, the scout base_link pose in the map
  frame (meters, unit quaternion) interpolated to the image stamp from
  `/model/ingenuity_quad_approx/odometry` (linear position, slerp orientation);
- return the ground point `(x, y)` (z = 0) in the map frame, in meters.

PASS: every error <= 0.15 m while hovering and <= 0.30 m while translating at 1 m/s. Also report
the larger error of the same function with attitude ignored during translation (the tool prints it).

### S1 (M1, graded in C2): orbital BEV and global A*

Pixel to world: x = X0 + (u - cx) Z / fx, y = Y0 - (v - cy) Z / fy with X0 = Y0 = 0, Z = 6000 m,
fx = fy = 12000, cx = cy = 160 (FRAMES.md). Publish the inflated costmap and the A* path from S to
G; emit orbital_plan_ready.
PASS: AG-07 frame map, 0.50 m, 320 x 320, origin (-80, -80). AG-08 >= 90 % of boulders have a
center cell >= 99 and >= 80 % of sand samples are >= 99. AG-09 <= 10 % of lethal cells farther than
r_fp + 1.0 m from every hazard edge. AG-10 endpoints within 1.0 m of S and G, poses <= 1.0 m apart,
footprint clears every boulder and the sand patch, length <= 1.15 x the grader's reference A*.

### S2 (M1, graded in C3): orbit-only baseline, condition O

The scout stays on the pad (the watchdog rejects takeoff). rover_executive starts on
`/option_c/orbital_path`, publishes it as the first `/option_c/rover/active_path`, inserts hazcam
points into its working costmap as disks of radius `hazcam_obstacle_radius_m`, replans with the
same A* when the path is blocked (each new path on active_path, at most 200), and streams
`/option_c/rover/cmd_vel_request` through the TA guard. Abort after < 0.5 m progress in 40 s or at
900 s sim. Record with `record_option_c_bag <seed> orbit_only`.
Expect to meet rocks: every world has at least two rock fields with a band of rocks laid across
the whole corridor of shortest 8-connected routes from S to G (any A* tie-break, either search
direction, smoothed or not), so an orbit-only route crosses at least two bands. A 4-connected
planner is not covered by this, and its route is too long for AG-10 anyway.
PASS: AG-11 phase order, rover_start with path_topic and follower_params_sha256, scout never
airborne, no fused costmap, guard output >= 8 Hz while driving, rover speed <= 1.1 m/s; AG-12 valid
replans; AG-13 within 1.5 m of G in 900 s; AG-14 zero intrusions.

### S3 (M2, graded in C4): scout sorties

Before each takeoff publish one `/option_c/sortie_plan` and set `/ingenuity/enable` true; set it
false after touchdown (the watchdog ignores false while the scout is above 0.3 m and logs event
enable_ignored, so a false in the air never stops the rotors). Fly the plan with `/option_c/scout/cmd_vel` (world frame, >= 10 Hz). The watchdog ramps your horizontal
velocity at 1 m/s^2 (TOPICS.md): from 3 m/s the scout needs about 3 s and 4.5 m to stop, so slow
down before turns, the landing site and the geofence. Up to 3 sorties; later sorties start
from the previous landing site. Replan between sorties and aim later sorties at detours or uncovered
corridor.
PASS: AG-15 <= 3 airborne intervals (z > 0.5 m), each <= 90.0 s; z never above 15.5 m; while
moving faster than 0.5 m/s, z in [8, 15] m for >= 95 % of samples. AG-16 zero geofence, ceiling or
forced_descent events, <= 3 cmd_timeout events per sortie, xy within [-78, 78] m. AG-17 horizontal
speed < 0.5 m/s over the 2 s before touchdown; landing site >= 1.5 m from every hazard edge and off
the sand. AG-18 plan stamped before takeoff; cruise cross-track RMS <= 1.5 m.

### S4 (M3, graded in C5): nadir mosaic and scout hazard detection

After each landing, project every frame taken at 6-16 m altitude onto z = 0 with K and the full
camera pose (FRAMES.md), blend them into the 1600 x 1600 RGBA north-up mosaic at 0.10 m/px
(alpha 255 = observed), and write `scout_hazards.csv`.
PASS: AG-20 scout_mosaic.json exactly as specified; IoU >= 0.80 between observed pixels and the
grader's footprint union (partial credit from 0.50). AG-21 small-rock recall >= 0.70 and
precision >= 0.70 inside scouted ground (partial credit from 0.40).

### S5 (M4, graded in C6): fused replan and hand-off, condition S

Merge orbital hazards, scout hazards and the landed scout into the 0.25 m fused costmap (unknown
cells never >= 99), replan, emit fused_plan_ready and then rover_start with path_topic
`/option_c/fused_path`, and drive with the SAME rover_executive parameters. Record with
`record_option_c_bag <seed> orbit_scout`.
PASS: AG-22 fused grid 0.25 m, 640 x 640, origin (-80, -80), after the last touchdown; boulder
recall >= 0.90; scouted rock recall >= 0.70; false-lethal <= 15 %. AG-23 valid fused path that
clears every hazard in the scouted ground and the landed scout. AG-24 arrival within 900 s, zero
intrusions, <= 1 hazard stop, >= 90 % of the executed path over scouted ground.

### S6 (M5, graded in C7): paired experiment and ablation

Write your prediction in the report BEFORE running seeds 1 and 2. Run seeds s0, s1, s2 in both
conditions with identical rover executive parameters, fill `comparison_table.csv` (6 rows), and
run one ablation on all 3 seeds:
AB1 unknown-cell policy, optimistic vs pessimistic (offline replanning allowed);
AB2 cruise altitude 8 m vs 15 m (GSD 3.4 vs 6.4 cm/px, coverage vs recall);
AB3 sortie budget, 1 vs 3 sorties;
AB4 hazard camera range in condition O, 3 m vs 6 m;
AB5 inflation margin sweep, 3 values (offline replanning allowed).
PASS: AG-25 table values within tolerance of the grader's recomputation (lengths max(5 %, 0.5 m),
times max(5 %, 1.0 s), fractions +/-0.03, counts exact) and the same follower_params_sha256 in O
and S for each seed.

### Bonus B1: drift mode and map-relative registration (+5, Option C capped at 55)

Run seed s0 in condition S with `odom_mode:=drift`. The only scout pose you may use is
`/ingenuity/odom_est` (the truth velocity integrated with a yaw-rate bias of 0.02-0.05 deg/s in
size and a velocity scale error in [-3 %, +3 %], both 5x larger over the sand patch, where
`/ingenuity/nav_status` reports FEATURE_POOR, plus gyro noise). These are design values that drift
like MAVeN's estimates (ING-23) and echo Flight 72's feature loss (ING-39), not Ingenuity's measured
errors. The values are drawn fresh for every run (not from the seed) and wander during the run
(TOPICS.md). The watchdog executes your commands in this estimated frame. Register frames or the
mosaic to the orbital BEV (template matching / NCC as in the Lander Vision System, F29, or SIFT +
RANSAC as in F37), publish `/option_c/scout/registration_offset`, and build the mosaic, hazards
and fused map from the corrected poses. Record with `record_option_c_bag <s0> orbit_scout_drift`.
Integrity rule for the bonus: the correction must come from registering images to the orbital map.
For the scout pose only `/ingenuity/odom_est`, your own commands, your nadir images and the orbital
image are allowed. `/ingenuity/nav_status` may be used to segment or weight intervals (for example
to trust odom_est less while it reports FEATURE_POOR, or to split the MR-B figure), but not to
localize the scout: it is computed from the scout's TRUE position against the exact sand-patch
outline, so its switching times mark where the true track crosses the patch edge. Using any truth
pose (the Gazebo transport topics, for example the scout's odometry under its gz name through a
bridge or `gz` tool of your own; `/option_c/grader/*`; the world or ground-truth files), a
truth-derived signal (the watchdog's output topic `/ingenuity/gazebo/command/twist`, the time of a
geofence event, the rover guard's reaction to the landed scout, nav_status switching times used as
position fixes; TOPICS.md), or copying the drift model (the starter's `drift_parameters` or
`odom_degrader`) is an integrity violation, and a confirmed case is handled under the course
academic-integrity policy (section 9). What is checked automatically: AG-26 flags the strings and
patterns listed in section 3 (among them `/option_c/grader`, `ground_truth`, `gazebo/command`,
`drift_parameters`, `odom_degrader`, `ros_gz_bridge`, `parameter_bridge`, `gz.transport`,
`gz.msgs`, `gz topic` and `GZ_PARTITION`) when they appear in the files of `src/option_c_scout`.
Left to TA review of your code, report and video: a bridge or `gz` tool started outside your
package, names built at run time, and any use of the truth-derived signals above.
All of odom_est may be used, including its twist; the twist is consistent with the drifting pose
(its gyro carries the same yaw-error rate, bias plus noise), so dead reckoning with it gives the
same drifting estimate and is not a way around registration. odom_est is 20 Hz while the scout is
above 0.3 m and 1 Hz on the ground. In drift mode the watchdog steers by the estimated heading and
adds a random yaw disturbance (TOPICS.md), so neither assuming the takeoff heading nor recomputing
the heading from the hold law and your commands recovers the true heading.
Auto (3 pts, AG-B1): median localization error of scout detections <= 0.6 m (1.5) and the rover
reaches G in 900 s with zero intrusions (1.5). Manual (2 pts, MR-B): method write-up and a
before/after error figure split into FEATURE_POOR and NOMINAL intervals.

## 5. Points

| component | pts | grading |
|---|---:|---|
| C1 bring-up and evidence integrity (AG-01 to AG-06) | 4 | auto |
| C2 orbital BEV costmap and A* (AG-07 to AG-10, MR-1) | 8 | 6 auto + 2 manual |
| C3 orbit-only baseline (AG-11 to AG-14) | 5 | auto |
| C4 sortie planning and flight (AG-15 to AG-18) | 7 | auto |
| C5 nadir mosaic and scout detections (AG-20, AG-21, MR-2) | 8 | 6 auto + 2 manual |
| C6 fusion, replan and hand-off (AG-22 to AG-24) | 8 | auto |
| C7 paired experiment, ablation, analysis (AG-25, MR-3a to MR-3e) | 8 | 2 auto + 6 manual |
| C8 video, README, provenance (MR-4) | 2 | manual |
| Bonus B1 drift and registration (AG-B1, MR-B) | +5 | 3 auto + 2 manual |

Checks C2 to C6 run per seed; each seed is one third of the listed points. If a bag's seed or world
hash does not match (AG-02), every auto point tied to that bag is 0 and the case goes to TA review.

Manual items: MR-1 orbital figure and pixel-to-world derivation checked on one boulder; MR-2 mosaic
figure with sortie tracks, projection method, one frame projected with and without attitude during
3 m/s cruise with the error measured, and where the flat-ground assumption would break (ING-24,
ING-25, F38); MR-3a prediction and per-seed paired differences; MR-3b overlay figure; MR-3c the
discussion questions below; MR-3d the ablation; MR-3e the limitations checklist; MR-4 video,
README and PROVENANCE.md.

## 6. Discussion questions (MR-3c, answer with numbers from your runs)

- Q1. Why did the orbital map miss the rock fields? Use the 0.5 m/px GSD and the 5-pixel rule
  (F04, F05).
- Q2. Compare your condition-O detour ratio with Snowdrift Peak, 759 m driven against a 520 m
  straight line (about 1.46, F17).
- Q3. Was scouting worth it? Use airborne seconds, the energy proxy (airborne s x 350 W / 3600,
  from ING-09; the simulator has no power model), hazard stops and surprises avoided, and total
  mission time. When would it not be worth it?
- Q4. How did your sortie plan target the uncertain corridor, and how did your unknown-cell policy
  shape the fused path?
- Q5. Analyze one failure case with bag timestamps.

Limitations checklist (MR-3e), each tied to how it could change your results: (i) the scout is a
four-rotor stand-in, Ingenuity is coaxial with swashplate control (ING-03, ING-05); (ii) thin air
is not simulated and thrust is a lumped coefficient (ING-51); (iii) truth odometry and an idealized
hazard camera replace Ingenuity's drifting vision navigation (ING-23) and the rover's stereo;
(iv) images are processed live between sorties instead of being downlinked, the nadir camera runs
at 2 Hz instead of 30 Hz (ING-14), and n = 3.

## 7. Metrics (comparison_table.csv)

Columns: seed, condition, reached_goal, intrusions, hazard_stops, hazcam_surprises, replans,
min_clearance_m, planned_length_m, executed_length_m, detour_ratio, drive_time_s, sorties,
airborne_s, scout_track_m, energy_proxy_wh, scouted_area_m2, scouted_path_fraction,
total_mission_s. Definitions follow the course spec: intrusions count distinct hazards overlapping
the rover footprint for >= 0.2 s; hazard_stops count rising edges on `/option_c/rover/hazard_stop`;
hazcam_surprises count distinct rocks reported by the hazcam that were not lethal in the costmap the
drive started with; detour_ratio = executed length / |S - G|; airborne = z > 0.5 m;
energy_proxy_wh = airborne_s x 350 / 3600 (a proxy, labeled as such). Report each seed and the mean
of the three paired differences (S minus O); no p-values. A value that cannot be computed from the
bag (for example the drive columns of a bag without rover_start) is written as an empty cell or
`n/a` (also accepted: `na`, `nan`, `none`, `null`, `-`), in count columns as in the others; AG-25
accepts such a cell exactly when the grader cannot compute that value either.

## 8. Deliverables (zip `<netid>_a4_option_c.zip`, at most 150 MB)

```
option_c/
  README.md            build + run one seed in <= 5 commands; ROS distro; rover choice; node/topic graph
  PROVENANCE.md        external code, libraries and AI assistance, each with what it was used for
  report.pdf           <= 8 pages + appendix
  video_link.txt       one URL viewable by course staff, video <= 4 min
  config/option_c.yaml netid, seeds, rover, rover_model_name, rover_footprint_radius_m,
                       unknown_cell_policy, inflation_margin_m, hazcam_obstacle_radius_m,
                       ablation_id, ros_distro, scout_dynamics  (template: config/option_c_template.yaml)
  src/option_c_scout/  your package (hashed into src_sha256), launch/option_c_mission.launch.py,
                       test/test_projection.py
  bags/seed<s>_orbit_only/, bags/seed<s>_orbit_scout/   for your three seeds, each <= 25 MB
  results/seed<s>/     orbital_bev.png, orbital_hazards.csv, orbital_sand_polygon.json,
                       scout_mosaic.png, scout_mosaic.json, scout_hazards.csv,
                       figures/path_overlay_O_vs_S.png, figures/mosaic_with_tracks.png
  results/comparison_table.csv, results/ablation.csv, results/analysis/
  bonus_drift/         optional: bags/seed<s0>_orbit_scout_drift/ and results/
```

CSV columns: `x_m,y_m,diameter_m,class,source,confidence`. `orbital_sand_polygon.json`:
`{"frame":"map","vertices_xy_m":[[x,y],...]}`. `scout_mosaic.json`: resolution_m 0.10,
origin_xy_m [-80.0, -80.0], width_px 1600, height_px 1600, frame map, north_up true.

Build the zip with `ros2 run cs498gc_a4_option_c_starter make_submission <path>/option_c`: it
checks the tree, sizes, your seeds, and runs `local_check --submission` (bag seeds, conditions,
world hashes, topics, rates and your code hash).

Launch graded runs with `student_pkg_src:=<path>/option_c/src/option_c_scout` so every bag's
run_info carries the hash of exactly the code you submit; rerun the bags after any code change.

## 9. Integrity

Per-NetID seeds, world and code hashes, and source checks tie every bag to your code. Suspected use
of ground truth (reading the world SDF or the ground-truth JSON, subscribing to
`/option_c/grader/*`, using Gazebo truth topics in drift mode, for example through a bridge of your
own) goes to a TA for review under the course academic-integrity policy. The automatic source check
(AG-26, section 3) only flags strings in your package; the TA review covers the rest. Estimating rock abundance from orbital texture is a legitimate
technique (compare F04, F24) if your report explains it. Disclose AI assistance in PROVENANCE.md
where the semester policy allows it.
