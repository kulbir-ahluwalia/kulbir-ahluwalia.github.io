# Known limits (read before you start)

## What was tested, and on what

Starter v1.0.3 as shipped was tested by the course staff in November 2026 on an amd64 laptop:
Intel CPU, NVIDIA GeForce RTX 5080 Laptop GPU (16 GB), Ubuntu 24.04, ROS 2 Jazzy, Gazebo Harmonic
(gz-sim 8.11, the version Jazzy's `gz_sim_vendor` package ships; run_info reports it), headless
rendering (`headless:=true`), one simulation at a time, with its own ROS_DOMAIN_ID, GZ_PARTITION
and OPTION_C_WORK_DIR on a machine shared with other work. v1.0.1 differs from v1.0.0 only in the
bonus drift mode (fresh random drift values every run, gyro noise, a random yaw disturbance in the
watchdog's drift-mode heading hold), check_projection's handling of an exception in your
function, `make_submission --help`, and the documentation. v1.0.2 differs from v1.0.1 in
`/ingenuity/enable` (the watchdog now forwards it and ignores false while the scout is airborne;
the bridge and the scout model use a TA-only enable topic), the watchdog's horizontal speed clamp
(safe for huge finite commands), `teleop_scout` (refuses 'g' in the air), the help and error
messages of `record_option_c_bag`, `make_submission` and `local_check`, more AG-26 source strings
(Gazebo transport) in `tools/option_c_grading`, unit tests and the documentation. v1.0.3 differs
from v1.0.2 in `record_option_c_bag` (a READY line, printed by the new
`tools/recorder_ready_watch.py`), the grading code in `tools/option_c_grading` (grader 1.0.1:
transient_local history is timed by its own stamps, bags without the first mission events get an
explanation, empty or n/a cells in comparison_table.csv are handled alike in every column),
`local_check` 1.0.1, unit tests and the documentation (recording order; transient_local
durability for `/option_c/mission_phase`, `/option_c/rover/active_path` and `/option_c/sortie_plan`).
Rows marked **(v1.0.3)** were run on the final v1.0.3 code, rows marked **(v1.0.2)** on v1.0.2,
rows marked **(v1.0.1)** on v1.0.1 and the other rows on v1.0.0, each time on the same laptop and
for code those tests did not see change in later versions. Results:

| Test | What was checked | Result |
|---|---|---|
| Build and package tests **(v1.0.3)** | `colcon build --symlink-install`, a plain `colcon build` and `colcon test` on v1.0.3 | both builds work and install `tools/recorder_ready_watch.py`; `colcon test`: 65 tests, 64 passed, 1 skipped (the live bridge smoke test runs only with OPTION_C_LIVE_SMOKE=1). v1.0.2: 63 tests, 62 passed, 1 skipped |
| Recorder READY and the recording order **(v1.0.3)** | seed 7: (1) world, `ros2 run ... record_option_c_bag 7 orbit_scout`, `hello_sortie` after READY, then SIGINT to the recorder's process group (what Ctrl-C does); (2) the staff's reference mission (transient_local event topics) started first and the recorder 15 s later, condition orbit_only; (3) world, recorder, reference mission after READY, orbit_only | (1) READY after 4.3 s with 11 of 21 topics (every TA topic of orbit_scout); the recorder stopped 2 s after SIGINT, nothing left running, `local_check --stage M0` PASS. (2) READY after 1.3 s plus the WARNING naming the 5 mission topics that were already published; the bag's clock starts at sim 17.4 s and it still holds orbital_plan_ready (t_sim 4.1 s), rover_start (4.2 s) and the first active_path (stamp 4.25 s), delivered as transient_local history and timed by their stamps by the grading code (0 events off by more than 1 s). (3) READY after 5.2 s with 9 of 14 topics; every event recorded live. A volatile publisher in a separate test: a recorder started 5 s after 30 messages received none of them (transient_local depth 100: all 30; depth 20: the last 20) |
| Enable through the watchdog **(v1.0.2)** | multicopter and kinematic, seed 7: five `/ingenuity/enable` false over 4 s at 10 m, then a 2 m/s leg; after landing, false and then a climb command; then true; in drift mode three false at 10 m after crossing the sand patch | at 10 m nothing reached the flight controller, the altitude did not change (10.33 m and 9.83 m before and after), 3 enable_ignored events each (at most one per second), and the scout then flew the 2 m/s leg (11.5 and 12.0 m); after landing false was forwarded and a climb command did not lift the scout (z stayed 0.075 m); true re-enabled it (climbed to 2.8 m). Drift mode: the enable_ignored events carried pose_source odom_est and the odom_est position while the truth was 1.82 m away. Before v1.0.2 false in the air dropped the scout from 1.48 m to 0.07 m in 4 s |
| Huge finite command **(v1.0.2)** | 1e308 m/s west for 6 s at 10 m | multicopter: 17.0 m in 6 s, 2.89 m/s in the last second; kinematic: 18.1 m, 3.00 m/s; speed_clamped events. Before v1.0.2 the scout hovered (the clamp overflowed to inf). The test sent v_z = 0 with no altitude hold, and the multicopter lost altitude at 3 m/s (lowest 7.75 m): your flight controller needs its own altitude hold |
| World generator 1.1.0 | 20 seeds generated twice on this laptop and compared with the lists from Python 3.10, 3.12, 3.13 and 3.14 (Linux x86_64 and macOS arm64); in earlier rounds every spec placement rule on 115 seeds with an independent checker, and rocks met by shortest-path, smoothed, 16-connected and noisy-map routes from independent planners (the generator's logic has not changed since) | byte-identical worlds and ground truth everywhere; 115 of 115 seeds pass every rule; every such route meets at least 2 rocks (the 7 named routes at least 3); at most 4.5 s per seed |
| World load | seeds 7, 101 (`render_engine_path:=auto`), 202 and 303 (`shadows:=false`), headless | no SDF errors; first orbital camera_info at 0.008 s of sim time; nadir camera, rover odometry and scout odometry publishing |
| M0 (`hello_sortie`) on seeds 7 and 303 (seed 7 also on v1.0.1, **v1.0.2** and **v1.0.3**, the latter started after the recorder's READY line) | `local_check --stage M0` on the recorded bags (v1.0.2: from the symlink install and from a plain install in a clean environment) | PASS on all: 40.6-40.8 s in the 9-11 m band, touchdown horizontal speed 0 m/s, first orbital frame at 0.01 s, rover odometry 10 Hz, hazcam 5 Hz, no events |
| Flight with step commands | the 3 m/s step test that showed the altitude loss before the ramp existed: three 8 s legs at +3, -3, +3 m/s with step changes, then the same legs ramped by the driver, at 10 m with a simple altitude hold; then out of the west geofence at 2 m/s and back; then hovering until the 120 s forced descent | steps: lowest point 9.33 m, 100 % of the samples above 0.5 m/s inside 8-15 m (before the ramp: 7.80 m and 89 %); ramped by the driver: 9.34 m, 100 %; one geofence event; forced descent at 120.0 s airborne |
| Required topics (live) | type, rate and frame of every graded topic during the seed 7 M0 flight; student topics in the test mission bags; the drift topics in the drift bag | every topic type matches TOPICS.md (the student-only bonus topic `/option_c/scout/registration_offset` was not published in these tests); clock 19.2 Hz, scout and rover odometry 19.2 and 10 Hz, nadir 2 Hz, orbital 0.5 Hz, hazcam 5 Hz, guard 17.7 Hz, watchdog 20 Hz airborne; frame ids as listed in FRAMES.md |
| Condition orbit_only (also **v1.0.2**) | `hello_sortie` with no options; `local_check --stage M0` on that bag; `teleop_scout --rover`; enable plus climb commands | hello_sortie read the condition from run_info, skipped the flight and drove the rover 10.05 m; local_check M0 PASS (no airborne interval, rover odometry 10 Hz, hazcam 5 Hz); keyboard rover teleop drove 6.0 m at 0.5 m/s; takeoff refused (takeoff_rejected events, the scout stayed at z = 0.08 m) |
| Kinematic fallback (`scout_dynamics:=kinematic`) | M0 check (also on **v1.0.2**: 36.6 s in the band); a 3-sortie test mission graded with local_check | M0 PASS; `/ingenuity/gazebo/command/twist` at 20 Hz airborne; every AG-02 to AG-06 item of the mission bags passes, AG-15 to AG-17 pass; no integrity flags |
| Orbital pixels to world | sand patch on seeds 7, 202 and 303; 35 and 32 boulders on seeds 7 and 303 | sand IoU 0.953-0.975 with the predicted polygon, centroid within 0.73-0.83 px; boulders: median offset 0.56 px, worst 1.6 px (see FRAMES.md for the half-pixel result) |
| Small rocks in the orbital image | seeds 7, 101, 202 and 303 | the spec's single-threshold test passes on every seed (a threshold that finds >= 90 % of boulders finds 0 % of rocks), but see "How the simulation differs" below |
| M0b (`check_projection --fly`, spawn yaw 1.0 rad) **(v1.0.1)**, again on **v1.0.2** (stub and a completed projection: same outcome, hover and translation worst 0.041 m) | `examples/pixel_to_ground_stub.py` copied to a folder of its own: (1) unchanged, (2) completed with the FRAMES.md formula, as the handout asks | (1) the stub's NotImplementedError is printed with a hint, the tool stops calling it, lands the scout and exits with code 1; (2) PASS: hover worst error 0.041 m, translation worst 0.041 m. Example of the attitude-ignored error in that run (it varies from run to run with the body tilt when a fiducial is in view): tilt up to 6.7 deg, median 0.16 m, worst 1.61 m; other runs showed worst errors down to about 0.5 m |
| Watchdog **(v1.0.1)** | stale command, speed above the limit, ceiling, flying out of the geofence at 3 m/s and back, 120 s airborne; NaN and infinite commands; the ramp, the drift-mode heading hold and yaw disturbance (unit tests) | each produced its event (ceiling: highest point 20.3 m); one geofence event per excursion, the ramped stop left the scout landing outside at x = -84.7 m, and it took off back inside without a new event; forced descent at 120.0 s airborne; 2 s of NaN and 1 s of inf commands: the scout kept hovering, 4 invalid_cmd events, 0 of 961 relayed twists non-finite; setpoint steps never above 0.05 m/s per 0.05 s tick |
| Keyboard scout teleop | `teleop_scout` in a pseudo-terminal | climbed to 3.07 m and descended on key presses, exit 0. **v1.0.2**: 'g' at 2.6 m printed "'g' ignored" and published nothing (the scout stayed at 2.6 m); 'g' after landing published enable false |
| Rover hazard guard | 2.0 m/s requested; driving at a boulder at 1.0 and 0.5 m/s; reversing; a NaN request; driving at a 0.355 m tall rock | speed capped at 1.0 m/s; stopped with 0.28 m (1.0 m/s) and 0.40 m (0.5 m/s) between the 0.45 m footprint and the boulder; held 10 s; forward blocked, reverse allowed; a NaN request stops the rover and it drives again after; the rover reached the 0.355 m rock and did not climb or pass it (closest center distance 0.69 m) |
| Test mission (3 sorties, fused path, rover drive) | `record_option_c_bag` + `local_check --submission` (the grader's code) on a test student package for NetID abc123 | bags 2.5 MB (158 s, `orbit_only`) and 9.9 MB (370 s, `orbit_scout`, 203 s airborne); every AG-01 to AG-06 item of both bags passes, and AG-15 to AG-18 pass for that seed (a simple waypoint follower at 2.5 m/s that slows down near each waypoint: cross-track RMS 0.81 m with the 1 m/s^2 ramp); no integrity flags (the fabricated-dynamics check included); a wrong seed in config.yaml was caught by AG-01 and `make_submission` |
| Bag size | byte rates per topic in the test mission bag and in the drift bags | see "Bag size" below |
| Bonus drift mode **(v1.0.1)** | `odom_mode:=drift`: `hello_sortie` on `/ingenuity/odom_est` toward the sand patch at a clamped 3.05 m/s; twice, a two-sortie mission flown only on odom_est (loiter over the sand, too-fast and NaN commands, out of the geofence and back, a rover probe toward the landed scout); every recorded topic except images checked against the truth; the attacks that undid v1.0.0's drift without registration: the bias read from the most common airborne gyro value or from the first 3 s of flight, and the heading recomputed with the hold law from odom_est and the student's own commands | `/ingenuity/odom_est` at 19.2 Hz airborne and 1 Hz on the ground, `nav_status` FEATURE_POOR over the sand; no public topic carries the scout truth; every watchdog event carried the odom_est position; no truth position or drift value in /rosout or the launch log; the two missions drifted the opposite ways (heading error -8.4 and +8.7 deg at the end of the first sortie), median position error of odom_est over the flight 3.3 and 5.2 m; no gyro value occurred twice, and no attack brought the median error under the AG-B1 threshold of 0.6 m or clearly below odom_est's own (over the flight 3.4 to 55 m; with the hold-law heading, per sortie, 1.5 to 6.7 m, the heading itself off by 4 to 59 deg); in the hello flights integrating odom_est's own twist follows odom_est (within 0.19 deg and 0.15 m) and dead reckoning at the start heading is no closer to the truth (2.7-2.8 m, odom_est 2.0-2.6 m), so neither undoes the drift; M0 check of the drift bag PASS, run_info starter_version 1.0.1. Only the watchdog's output topic, which student code must not read, still tracks the true heading (0.7 and 2.5 deg off at the end of the first sortie). **v1.0.2**: `hello_sortie --odom-topic /ingenuity/odom_est` plus a sortie across the sand patch with enable false in the air: M0 check of the drift bag PASS (run_info starter_version 1.0.2); no numeric field or string on any non-image topic (watchdog events and /rosout included) tracked the truth, with truth and estimate up to 4.45 m apart |
| Shutdown (Ctrl-C) | 25 simulation runs on v1.0.0, 9 on v1.0.1, 9 on **v1.0.2** and 3 on **v1.0.3** (recorder output through the READY watcher; it stopped within 2 s of SIGINT to its process group and nothing was left running) | every recorder stopped 1.0 s after Ctrl-C, no process was left behind, no TA node logged an error or a traceback, and bags were intact; in our test harness no launch log showed a died process, but depending on how Ctrl-C reaches it `gz sim` can be reported as `process has died ... exit code -2` (its normal SIGINT exit; see "Stopping the simulation" below). In the v1.0.2 harness every launch exited within 2 s of Ctrl-C and the only died line was that `gz sim` exit -2 |
| Style **(v1.0.3)** | the package's text files | no em or en dashes (73 files scanned) |

**Earlier arm64 run.** A previous build of this package was also tested on an NVIDIA DGX Spark
(arm64, Ubuntu 24.04, ROS 2 Jazzy, gz-sim 8.15): build, world load, M0, M0b, watchdog, teleop,
rover guard, a test mission and drift mode all passed there. Since then the watchdog (NaN
handling, kinematic command topic, drift-mode event positions, ground idle rate, the 1 m/s^2
horizontal ramp, the drift-mode heading hold and yaw disturbance), the drift model (twist
consistent with the estimate, 1 Hz on the ground, per-run random values, gyro noise), the rover
guard (NaN handling), run_info, local_check and the world generator (1.1.0) changed; those
changes were re-tested only on the amd64 laptop above, so every result in the table is from it.

## Not tested (use with caution)

- **ROS 2 Humble + Gazebo Harmonic** (ros-humble-ros-gzharmonic from packages.osrfoundation.org).
  Gazebo lists this combination as possible but 'use with caution'; it conflicts with the
  ros-humble-ros-gz* packages. Not tested for Option C.
- **Laptops with only an Intel or AMD GPU**, and software rendering (llvmpipe). The cameras were
  only tested on NVIDIA GPUs. If cameras are slow or black, try `shadows:=false` first.
- **The Gazebo GUI** (`headless:=false`): all tests ran headless.
- **macOS, Windows (including WSL2)**: not tested.
- **Docker image**: the spec plans an Ubuntu 24.04 + Jazzy + Harmonic image; it is not part of
  starter v1.0.1 (not built or tested yet).
- **Demo debug bag**: a seed-7 debug bag with the nadir and orbital images of the M0 flight (116 s
  of sim time, about 73 MB, recorded with `record_images_debug`) is offered separately by the
  course staff, not in this package. Use it to develop the mosaicker offline if your cameras do
  not render; it was recorded on the amd64 laptop above.
- **Your Part B Husky as the rover** (`rover:=custom` with `xacro/odom_truth_plugin.xacro`): the
  custom-rover path of the launch file was not exercised with a Husky.
- **Gradescope with real bags**: `local_check` runs the grader's own code; it reads bags with
  rosbags if installed, otherwise with its standard-library reader. The bags of the tests above
  were checked with it on Ubuntu 24.04 (Python 3.12). The Gradescope image (Ubuntu 22.04, Python
  3.10) was tested by the staff with synthetic bags only.
- **Two simulations at the same time on one machine**: not tested. Give each one its own
  ROS_DOMAIN_ID, GZ_PARTITION and OPTION_C_WORK_DIR (README.md, "Shared machines").

## How the simulation differs from Ingenuity and Mars

- **Four rotors, not a coaxial helicopter.** Ingenuity has two counter-rotating rotors controlled
  by swashplate cyclic and collective pitch (ING-03, ING-05). Gazebo Harmonic's multicopter
  controller rejects coaxial rotors, so the scout is a four-rotor vehicle with Ingenuity's 1.8 kg
  mass (ING-01) in Mars gravity. Its dynamics (tilting to accelerate, response times) are a
  quadrotor's, not Ingenuity's; the watchdog's 1 m/s^2 horizontal ramp (below) is a course
  design value that keeps this stand-in in its altitude band, not an Ingenuity limit.
- **No thin air.** Mars air density is about 0.016 kg/m^3 (ING-51); the simulator has no
  aerodynamics model, and thrust is one lumped coefficient tuned so the vehicle hovers near
  2,544 rpm in Mars gravity, close to the 2,537 rpm Ingenuity flew on flights 1-13 (ING-07).
- **Truth odometry** for the scout and the rover in the core task. Ingenuity estimated its state
  with a drifting vision-and-IMU filter (MAVeN, ING-23) and had no global position. The bonus
  drift mode adds a simple designed drift; it is not Ingenuity's measured error.
- **Idealized hazard camera and guard.** The rover's hazcam reports exact rock centers and edge
  points within 3 m with 5 cm noise, never misses and ignores occlusion; the guard knows the true
  hazards. Real rovers detect hazards from their own stereo images (F20, F40).
- **Near-orthographic orbital camera.** A perspective camera at 6000 m with explicit intrinsics,
  because Gazebo Harmonic has no orthographic camera. No orbital blur, noise, haze or
  compression, and a 0.5 m pixel, about 1.6-2x coarser than HiRISE (F01, F02).
- **Small rocks can show in the orbital image.** Real HiRISE images resolve rocks only from about
  1.5 m across (F04). Because the simulated orbital image has no blur or noise, many of the
  0.4-0.9 m rocks appear as 1-2 px specks, mostly brighter than the ground on their sunlit side
  (the darkest-pixel test above finds none). In a staff test a detector that compares each pixel
  with its 7 x 7 neighborhood found 74-89 % of the rocks on seeds 7, 101, 202 and 303, with 13-19
  false detections per image. The barrier chains of the on-path rock fields were not among the
  10 strongest straight lines of a blind Hough search (seeds 7 and 303: 57 to 419 line bins
  scored at least as high), but measured along a chain's known line the image anomaly is above
  99 % of random lines of the same length, simply because its rocks show; a planner that looks
  for rock rows in the orbital image could find some. Using orbital texture is allowed if your report
  explains it (HANDOUT.md, section 9), and the analysis is graded on reasoning, not on scouting
  winning.
- **Nadir camera: 320 x 240 color at 2 Hz** with a 1.2 rad field of view. Ingenuity's navigation
  camera was 640 x 480 grayscale at 30 Hz with a 133 x 100 deg field of view (ING-13, ING-14).
- **Images are processed in the simulation between sorties.** Ingenuity's images were downlinked
  to Earth and used by ground teams; they never guided the rover in real time.
- **Flat ground.** The site is a plane, so the ground-plane projection is exact. Ingenuity's
  navigation also assumed flat ground and made heading errors over slopes (ING-24, ING-25, F38).
- **Design values.** The 90 s sortie budget, 8-15 m cruise band, 3 m/s speed limit, touchdown
  speed rule, 350 W energy proxy, rock sizes, the drift model and the guard's 10 s hold are
  course design values motivated by Ingenuity and Perseverance facts, not measurements.
- **n = 3.** Three seeds per condition cannot support significance claims.

## Practical limits of the starter

- **Hard landings**: the scout's collision box can sink 2-4 cm into the ground at touchdown; the
  grader uses z > 0.5 m for airborne and z < 0.2 m for landed.
- **The flight controller latches its last command.** The watchdog protects you (0.5 s timeout,
  clamps, geofence, ceiling, 120 s forced descent); never bypass it. While the scout is landed
  and idle the watchdog repeats the zero twist at 1 Hz instead of 20 Hz (TOPICS.md); your first
  nonzero command or enable switches it back to 20 Hz on the next tick.
- **Horizontal ramp (1 m/s^2).** The quadrotor stand-in tilts to accelerate. Without a limit, a
  3 m/s step pitched it to about 49 deg and cost about 2.5 m of altitude at 10 m cruise even with
  zero vertical command, and it could not climb while braking: with step reversals, only 89 % of
  the fast samples stayed in the 8-15 m band that AG-15 checks (it needs 95 %). The watchdog
  therefore ramps the horizontal velocity setpoint at 1 m/s^2, for your commands and for its own
  stops (TOPICS.md). Consequences: reaching 3 m/s takes 3 s, and stopping from 3 m/s takes 3 s and
  about 4.5 m, also after a cmd_timeout and at the geofence; a position controller that expects
  instant response will overshoot waypoints and the landing site. Plan a speed profile that slows
  down in time.
- **NaN and infinite commands.** One NaN in a Twist used to reach the rotor controller and drop
  the scout from 10 m. The watchdog now replaces any scout command with a NaN or infinite field by
  a zero twist (the scout hovers) and logs `invalid_cmd`, and the rover guard treats such a
  request as no request (the rover stops). `invalid_cmd` is a starter addition to the spec's
  event list; fix the bug in your controller anyway (usually a division by a zero vector length).
- **Rock fields (generator 1.1.0).** Each world has at least two on-path rock fields whose rock
  band crosses the whole corridor of plausible orbit-only routes: every shortest 8-connected path
  on the 0.5 m reference grid (any tie-break, searched from S or from G), the smoothed versions,
  and the routes with 0.3 m less or more inflation, each with +-1.5 m of margin. So every such
  route overlaps at least one rock per band (at least 2 in all), and the 7 named routes in the
  ground truth overlap at least 3. A 4-connected planner is not covered (its staircase route can
  pass beside the bands, and it is too long for AG-10 anyway). Worlds from generator 1.0.0 are
  different worlds: regenerate them.
- **Rover stop distance.** At 1.0 m/s the starter rover needs about 0.5 m to stop (its drive
  decelerates at 1.0 m/s^2), so the guard looks further ahead at speed (TOPICS.md). If your rover
  executive drives at full speed straight at hazards it will collect hazard stops; plan and
  replan around hazcam detections instead.
- **Geofence**: flying out of [-78, 78] m logs a geofence event (AG-16) even if you fly straight
  back; the watchdog lets inward commands through so you can recover, but the event counts. Its
  stop is ramped too, so at 3 m/s the scout ends about 4.5 m beyond the fence: brake before it.
- **Bonus integrity**: in v1.0.0 the drift model was deterministic for a seed, and a staff test
  showed it could be undone from public data: the scout often holds its true heading exactly for
  seconds, and the gyro then read the bias exactly. Since v1.0.1 the drift values are drawn fresh
  for every run from the operating system's random source, random-walk during the run, the gyro
  is noisy, and the watchdog's drift-mode heading hold adds a random yaw disturbance; the staff's
  inversion attacks no longer reach the AG-B1 threshold (table above). Some parts of the drift
  can still be estimated from public data, for example the scale error from odom_est's speed in
  steady cruise against your own commanded speed; that alone does not remove the heading error.
  The correction must come from registration: truth-derived signals (the watchdog's output topic
  `/ingenuity/gazebo/command/twist`, the time of a geofence event, the rover guard's reaction to
  the landed scout, nav_status switching times used as position fixes) and copying the drift
  model are integrity violations (HANDOUT.md B1). **Gazebo transport topics** stay reachable
  outside ROS: a staff test in v1.0.1 started the stock `ros_gz_bridge` on the scout's gz truth
  odometry in drift mode and read the exact truth pose (within 0.0001 m). The starter cannot
  hide them (the simulator needs them), so this is a rule, not a technical barrier. Since v1.0.2
  AG-26 flags `ros_gz_bridge`, `parameter_bridge`, `gz.transport`, `gz_transport`, `gz.msgs`, the
  `gz topic`, `gz service` and `gz model` tools and `GZ_PARTITION` in the files of your package,
  next to `drift_parameters`, `odom_degrader`, `gazebo/command` and the ground-truth names
  (HANDOUT.md section 3 lists every checked string). A bridge or `gz` tool started from a
  terminal or a script outside your package leaves no string to find; that case is left to TA
  review of your code, report and video.
- **Bag start**: start `record_option_c_bag` soon after the world launch so the bag covers a
  long enough sim span (AG-03 needs >= 60 s). The M0 "first orbital frame within 15 s" check
  reads `first_orbital_t_sim` from run_info, so a late recorder no longer hides or fakes it.
- **Bag size (25 MB limit).** Measured in the 3-sortie test mission: about 33 KB per second while
  the scout flies (most of it the 20 Hz grader odometry) and about 17 KB per second on the ground
  (most of it the 10 Hz rover odometry), plus about 0.41 MB per fused costmap and 0.10 MB per
  orbital costmap message. A mission with 270 s in the air, 630 s on the ground and six costmap
  messages comes to about 22 MB. So with three full sorties and four costmap messages a bag holds
  about 15 minutes of ground time: a drive that uses most of the 900 s limit, added to the time on
  the ground between sorties, can go over 25 MB. Start recording just before the mission, stop
  right after the rover finishes, publish costmaps only when they change (at most 5 of each), and
  check the size `record_option_c_bag` prints at the end. **Drift bag (bonus):** it also holds
  `/ingenuity/odom_est` (20 Hz airborne, 1 Hz on the ground) and nav_status, measured at about
  51-53 KB per second in the air and 16.7-18 KB per second on the ground (v1.0.0 and v1.0.1). With
  three full sorties (270 s) and four costmap messages it holds about 9.5 minutes of ground time;
  the same mission as above (270 s in the air, 630 s on the ground, six costmaps) comes to
  24.3-25.7 MB, at or over
  the limit, and AG-B1 needs that bag to pass AG-03. Keep the drift mission lean: fewer or shorter
  sorties if your rover drive is long.
- **Stopping the simulation**: stop the bag recorder first (Ctrl-C in its terminal), then the
  launch. In an earlier test series, in one of 21 runs every ROS node exited cleanly but the
  `gz sim` server did not exit within 30 s of Ctrl-C. If that happens, press Ctrl-C again or run
  `pkill -f "gz sim"` before the next launch; a leftover server keeps publishing on the same
  topics. In 1 of 10 runs of that series the upstream ros_gz `parameter_bridge` aborted while
  shutting down (`terminate called after throwing an instance of 'rclcpp::exceptions::RCLError'`,
  exit code -6), and `gz sim` can be reported as `process has died ... exit code -2` after Ctrl-C
  (its normal SIGINT exit). Neither affected the bags or the TA nodes.
- **Orbital shadows.** The orbital image shows no cast shadows (frames with shadows on and off
  were byte-identical); boulders appear as self-shaded ellipses. `shadows:=false` changes only the
  scout's nadir images (FRAMES.md).
- **run_info carries no file paths** (it is recorded in your bags). The TA nodes still receive the
  ground-truth file as a ROS parameter, and the world and ground truth are on your disk (they can
  also be regenerated from the seed): using any of them in your nodes is checked in code review
  (AG-26).
- **Orbital half pixel**: the renderer puts pixel centers at u + 0.5 (FRAMES.md). With integer
  pixel indices your orbital positions come out about 0.35 m north-west of the truth; state your
  convention in the report.
- **Event topics may be empty**: `/option_c/scout/watchdog_events` and `/option_c/rover/hazard_stop`
  must be recorded, but a good run can have zero messages on them; `local_check.py` accepts that.
