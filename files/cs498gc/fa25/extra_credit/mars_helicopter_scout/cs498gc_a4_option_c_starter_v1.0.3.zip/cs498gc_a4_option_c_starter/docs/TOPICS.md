# Option C topics

All nodes use simulation time (`use_sim_time: true`). Frames: ROS frame `map` is the Gazebo world
frame, x east, y north, z up (FRAMES.md). "Recorded" means `record_option_c_bag` puts the topic in
the graded bag; graded bags never contain images or raw `/clock`.

Who publishes: **TA** = the starter (launch file, bridge, TA nodes); **STUDENT** = your package
`option_c_scout`.

## Graded topics (the spec's required list)

| topic | type | min Hz | publisher | notes |
|---|---|---:|---|---|
| `/option_c/clock_20hz` | rosgraph_msgs/msg/Clock | 15 | TA clock_decimator | sim time at 20 Hz; recorded instead of raw /clock. The grader maps receive times of headerless messages (Twist, Bool, String) to sim time with it |
| `/option_c/run_info` | std_msgs/msg/String | | TA run_info_publisher | transient_local JSON: seed, condition, world_sha256, src_sha256, starter_version, odom_mode, scout_dynamics, rover, rover_footprint_radius_m, S, G, helipad, ros_distro, gz_sim_version, plus informational keys (loaded_world_sha256, world_variant, generator_version, src_files, src_note, first_orbital_t_sim = header stamp of the first orbital camera_info, null until it arrives). No file paths. Republished every 10 s of sim time and once when the first orbital frame arrives |
| `/orbiter/bev_cam/image` | sensor_msgs/msg/Image | 0.4 | TA bridge | 320 x 320 rgb8 near-orthographic orbital view at 0.5 Hz. NOT recorded: save the first frame as results/seed*/orbital_bev.png |
| `/orbiter/bev_cam/camera_info` | sensor_msgs/msg/CameraInfo | 0.4 | TA bridge | K: fx = fy = 12000, cx = cy = 160. Recorded |
| `/model/ingenuity_quad_approx/odometry` | nav_msgs/msg/Odometry | 15 | TA bridge | scout truth pose (world frame), 20 Hz, for your flight control and mosaicking in the core task. NOT recorded. Not bridged in odom_mode:=drift |
| `/option_c/grader/scout_odom` | nav_msgs/msg/Odometry | 15 | TA scout_odom_relay | truth scout odometry, 20 Hz while z > 0.3 m and 1 Hz on the ground. Recorded. Never subscribe to it |
| `/ingenuity/nadir_cam/image` | sensor_msgs/msg/Image | 1.5 | TA bridge | 320 x 240 rgb8 nadir frames at 2 Hz. NOT recorded (use `record_images_debug` for your own debugging) |
| `/ingenuity/nadir_cam/camera_info` | sensor_msgs/msg/CameraInfo | 1.5 | TA bridge | one per frame, header stamp = frame time; K: fx = fy = 233.87, cx = 160, cy = 120. Recorded |
| `/option_c/scout/cmd_vel` | geometry_msgs/msg/Twist | 10 | STUDENT | world-frame ENU velocity: linear.x east, linear.y north, linear.z up (m/s), angular.z yaw rate (rad/s). Stream at >= 10 Hz while airborne (0.5 s timeout). Recorded |
| `/ingenuity/gazebo/command/twist` | geometry_msgs/msg/Twist | 10 | TA scout_safety_watchdog | the clamped and ramped command (horizontal setpoint slew 1.0 m/s^2), rotated into the vehicle heading frame, 20 Hz, in both scout_dynamics modes (with kinematic the same twist also goes to `/model/ingenuity_quad_approx/cmd_vel`). Starter detail: while the scout is landed and idle (zero twist, no fresh nonzero command, no enable in the last second) the zero twist is repeated at 1 Hz to keep bags small; the 10 Hz rule is checked over airborne intervals only. Students never publish here, and student nodes never subscribe to it: in drift mode it carries the per-run yaw disturbance and so the true heading's history (AG-26 flags `gazebo/command` in student source). Recorded |
| `/ingenuity/enable` | std_msgs/msg/Bool | | STUDENT mission_manager | true before each takeoff, false after touchdown. Not bridged to Gazebo (v1.0.2): the TA watchdog forwards it to the TA-only `/ingenuity/gazebo/command/enable` and **ignores false while the scout is above 0.3 m** (event enable_ignored), because false switches the flight controller off and the scout falls (1.48 m to 0.07 m in 4 s in a staff test before this change). Land first, then publish false. Recorded |
| `/option_c/scout/watchdog_events` | std_msgs/msg/String | | TA watchdog | JSON {t_sim, event, x, y, z, pose_source}; events cmd_timeout, geofence, ceiling, forced_descent, speed_clamped, takeoff_rejected, invalid_cmd (starter addition: a NaN or infinite command was replaced by zero), enable_ignored (starter addition, v1.0.2: /ingenuity/enable false arrived while the scout was above 0.3 m and was not passed on; at most once per second). x, y, z is the scout position at the event: the truth pose (pose_source "truth") in the core task, the `/ingenuity/odom_est` position (pose_source "odom_est") in odom_mode:=drift, never truth there; pose_source "none" and no x, y, z before the first pose. The geofence event's TIME follows the truth (the true x or y crossed +/-78 m): in drift mode do not use it to correct odom_est. The grader reads only t_sim and event. Recorded |
| `/option_c/rover/odom_truth` | nav_msgs/msg/Odometry | 8 | TA bridge of gz /model/rover/odometry | rover world-frame pose at 10 Hz; you may use it as the rover pose. Recorded |
| `/option_c/rover/cmd_vel_request` | geometry_msgs/msg/Twist | 5 | STUDENT rover_executive | body frame: linear.x forward (m/s), angular.z yaw rate (rad/s). Stream it while driving. Recorded |
| `/option_c/rover/cmd_vel` | geometry_msgs/msg/Twist | 8 | TA rover_hazard_guard | guard output at 20 Hz (caps 1.0 m/s and 1.0 rad/s, zero during holds), bridged to the rover's DiffDrive. Students never publish here. Recorded |
| `/option_c/rover/hazcam` | geometry_msgs/msg/PoseArray | 4 | TA hazcam_sim | frame map, 5 Hz: rock centers plus boulder-edge and sand-edge points every 0.5 m within 3.0 m and +/-60 deg of the rover heading, noise sigma 0.05 m. Recorded |
| `/option_c/rover/hazard_stop` | std_msgs/msg/Bool | | TA guard | True when a 10 s stop-and-hold starts, False when it ends. Recorded |
| `/option_c/orbital_costmap` | nav_msgs/msg/OccupancyGrid | | STUDENT | transient_local; frame map, 0.50 m, 320 x 320, origin (-80, -80); 0 free, 1-98 cost, 99-100 lethal, -1 unknown (unknown never >= 99); >= 1 before orbital_plan_ready, <= 5 per run. Recorded |
| `/option_c/orbital_path` | nav_msgs/msg/Path | | STUDENT | transient_local, frame map, A* path S to G, poses <= 1.0 m apart. Recorded |
| `/option_c/sortie_plan` | nav_msgs/msg/Path | | STUDENT | transient_local, depth >= 5 (v1.0.3, see Durability below); frame map, one per sortie, stamped before takeoff; xy waypoints with the planned altitude in z. Recorded (orbit_scout) |
| `/option_c/fused_costmap` | nav_msgs/msg/OccupancyGrid | | STUDENT | transient_local; frame map, 0.25 m, 640 x 640, origin (-80, -80), same values, includes the landed scout as a 0.35 m disk; after the last touchdown and before rover_start; <= 5. Recorded (orbit_scout) |
| `/option_c/fused_path` | nav_msgs/msg/Path | | STUDENT | transient_local, frame map, replanned S to G on the fused costmap. Recorded (orbit_scout) |
| `/option_c/rover/active_path` | nav_msgs/msg/Path | | STUDENT rover_executive | transient_local, depth >= 20 (v1.0.3, see Durability below); stamp each path (header.stamp, sim time); the path being followed: first = orbital path (O) or fused path (S), then one per hazcam replan; <= 200 per run. Recorded |
| `/option_c/mission_phase` | std_msgs/msg/String | | STUDENT mission_manager | transient_local, depth >= 100 (v1.0.3, see Durability below); JSON with event and t_sim (sim time) plus extras: orbital_plan_ready; sortie_start (k); sortie_end (k); fused_plan_ready; rover_start (path_topic, follower_params_sha256); rover_goal_reached; rover_aborted (reason). Recorded |
| `/ingenuity/odom_est` | nav_msgs/msg/Odometry | 15 | TA odom_degrader | bonus only (odom_mode:=drift): the only scout pose student code may use there. 20 Hz while z > 0.3 m, 1 Hz on the ground (like the grader's scout_odom); the twist is consistent with the drifting pose (see odom_degrader below). Recorded in the drift bag |
| `/ingenuity/nav_status` | std_msgs/msg/String | 1.5 | TA odom_degrader | bonus only: 'NOMINAL' or 'FEATURE_POOR' (scout over the sand patch), 2 Hz. It is computed from the scout's TRUE position against the exact sand-patch outline: use it to segment or weight intervals (trust odom_est less while FEATURE_POOR, split your MR-B figure), never to localize the scout (its switching times mark where the true track crosses the patch edge; HANDOUT B1). Recorded in the drift bag |
| `/option_c/scout/registration_offset` | geometry_msgs/msg/PoseStamped | 0.5 | STUDENT | bonus only: correction (x, y, yaw) from odom_est to your registered scout pose, frame map. Recorded in the drift bag |

## Topics that are not yours

| topic | why it exists |
|---|---|
| `/model/ingenuity_quad_approx/cmd_vel` | kinematic fallback input, written only by the watchdog (scout_dynamics:=kinematic) |
| `/ingenuity/gazebo/command/enable` | the flight controller's enable input (v1.0.2), written only by the watchdog, which forwards your `/ingenuity/enable` and ignores false in the air. Never publish here (AG-26 flags `gazebo/command`) |
| `/option_c/grader/_private/scout_odom_truth` | hidden ROS topic (name starts with `_`): the truth scout odometry the TA watchdog, relay, guard and degrader read in every mode. It is under `/option_c/grader/`, so AG-26 flags any student use |
| `/clock` | raw sim time from the bridge (every 4 ms physics step); never recorded |
| gz-only topics (`gz topic -l`) | Gazebo transport topics behind the bridge; student code talks to ROS only. A bridge, Gazebo transport library or `gz` command-line tool of your own reaches the truth (for example the scout's odometry under its gz name in drift mode) and the TA-only inputs, so it is not allowed. AG-26 flags `ros_gz_bridge`, `parameter_bridge`, `gz.transport`, `gz_transport`, `gz.msgs`, `gz topic`, `gz service`, `gz model` and `GZ_PARTITION` in the files of your package (the full list of checked strings is in HANDOUT.md section 3); a bridge or tool started outside your package is left to TA review |

## TA node behavior you can rely on

- **scout_safety_watchdog**: relays your `/option_c/scout/cmd_vel` at 20 Hz (1 Hz zero twist
  while the scout is landed and idle; your first nonzero command or enable switches it back to
  20 Hz on the next tick) after rotating it into the vehicle heading frame (truth yaw, or the odom_est yaw in drift mode) and clamping
  |v_xy| <= 3.0 m/s (direction kept, also for huge finite values such as 1e308), v_z to
  [-1.0, 1.0] m/s and the yaw rate to [-1.0, 1.0] rad/s (event speed_clamped, at most once per
  second). **Enable:** it forwards your `/ingenuity/enable` to the flight controller; true always,
  false only while the scout is at or below 0.3 m. A false above 0.3 m is ignored (event
  enable_ignored, at most once per second) and the scout keeps flying on your commands; before
  v1.0.2 it switched the controller off and the scout fell. **Ramp:** the horizontal velocity setpoint changes by
  at most 1.0 m/s^2 (world frame), so a step from hover to 3 m/s becomes a 3 s ramp (about
  4.5 m), stopping from 3 m/s takes 3 s and about 4.5 m, and a reversal from +3 to -3 m/s takes
  6 s. The watchdog's own stops (cmd_timeout, invalid_cmd, geofence, ceiling, forced descent)
  ramp the same way; v_z and the yaw rate are not ramped. Reason: the quadrotor stand-in tilts to
  accelerate, and an unramped 3 m/s step pitched it to about 49 deg and cost about 2.5 m of
  altitude at 10 m cruise even with v_z = 0 (it could not climb while braking), enough to break
  the 8-15 m band (AG-15) or reach the ground at low altitude. Plan your own speed profile
  (slow down before waypoints, the landing site and the geofence) rather than relying on the
  ramp. A command with any NaN or infinite field is replaced
  by a zero twist, so the scout hovers in place (event invalid_cmd, at most once per second);
  check your controller for divisions by a zero vector length. A command older than 0.5 s gives a
  zero twist (event cmd_timeout while airborne). Above 20 m: descent at 1 m/s until below 19 m
  (event ceiling).
  120 s airborne (z > 0.5 m): descent at 1 m/s to touchdown (event forced_descent).
  Geofence: when |x| or |y| exceeds 78 m it logs one geofence event per excursion and removes
  the outward parts of your command; a command that still points inward is passed through (no
  climbing above 3 m), so you can fly back in; with no inward command the scout hovers 2 s, then
  descends. The excursion ends when the scout is back inside, so a scout that landed outside can
  take off toward the inside without new events. In condition orbit_only every command is
  replaced by zero and takeoff attempts log takeoff_rejected.
- **rover_hazard_guard**: relays `/option_c/rover/cmd_vel_request` at 20 Hz with caps 1.0 m/s and
  1.0 rad/s and a 0.5 s staleness limit. A request with a NaN or infinite field counts as no
  request (the rover stops). If the footprint circle swept along the commanded
  direction up to the lookahead L overlaps a ground-truth hazard (rock, boulder, sand patch, or
  the landed scout as a 0.35 m disk), it stops and holds the rover for 10.0 s of sim time and
  publishes hazard_stop True, then False. L = max(0.60 m, v^2/(2 x 1.0 m/s^2) + 0.15 s x v +
  0.25 m) with v the larger of the commanded and measured speed: 0.60 m up to about 0.4 m/s,
  0.90 m at 1.0 m/s. After a hold it blocks forward commands that would trigger again (turning in
  place and backing away are allowed) without counting a new stop. The landed scout is placed at
  its TRUE position (the guard is a safety device), so in drift mode a hazard stop or the
  "landed_scout ahead" /rosout line near the scout's landing spot is a truth-derived signal: do
  not use it to correct odom_est.
- **hazcam_sim**: idealized hazard camera (no occlusion, no misses), see the table.
- **odom_degrader** (drift mode only). Design values, not Ingenuity's measured errors:
  a yaw-rate bias with |b| in [0.02, 0.05] deg/s and a random sign, and a velocity scale error
  in [-3 %, +3 %], both drawn fresh for every run from the operating system's random source (not
  from the seed, so no seed or earlier run reproduces them) and both slowly random-walking
  inside these ranges during the run; both x5 over the sand patch; plus white gyro noise
  (standard deviation 0.01 rad/s per 20 Hz message) that is integrated into the yaw error. The
  yaw error grows only while the scout is above 0.5 m. The values are never published, logged or
  exposed as parameters. In drift mode no TA node puts the scout's truth pose on a public topic
  or in a log line; the watchdog's events carry the odom_est position. odom_est's twist matches
  its pose: linear is the estimated velocity (scale error and yaw error applied) in the
  estimated body frame, angular is the body rate including the yaw-error rate (bias plus noise),
  so integrating it reproduces the drifting estimate, not the truth. odom_est is published at
  20 Hz while z > 0.3 m and at 1 Hz on the ground. **Heading in drift mode:** while the scout is
  above 0.5 m the watchdog holds the ESTIMATED heading: your yaw-rate command plus
  0.5 x (commanded heading - odom_est yaw), at most 0.2 rad/s extra, where the commanded heading
  starts at the odom_est yaw at takeoff and integrates your yaw rate, plus a random yaw-rate
  disturbance (zero mean, about 0.02 rad/s, correlation time about 3 s, fresh every run) that the
  hold rejects within seconds. With a zero yaw rate the odom_est yaw stays near its takeoff
  value and the true heading turns by minus the yaw error (up to a few degrees per sortie), as on
  a vehicle that steers by a drifting estimate; your nadir images show that turn, which is what
  registration has to find. The noise, the random walks and the disturbance are there so that
  the drift cannot be computed back from public data (the gyro, the hold law, your own commands)
  instead of registering images.
- **Truth-derived signals in drift mode** (do not use them for the scout pose): the time of a
  geofence event, the watchdog's output `/ingenuity/gazebo/command/twist`, the guard's reaction to
  the landed scout (above), the switching times of `/ingenuity/nav_status` used as position fixes
  (you may use nav_status to segment or weight intervals), and anything read from Gazebo directly
  (a bridge, Gazebo transport library or `gz` tool of your own). Using them, or copying the drift
  model, is an integrity violation (HANDOUT B1). AG-26 flags only strings in your package's files,
  among them `drift_parameters`, `odom_degrader`, `gazebo/command`, `ros_gz_bridge`,
  `parameter_bridge`, `gz.transport`, `gz.msgs`, `gz topic` and `GZ_PARTITION` (full list in
  HANDOUT.md section 3); the rest is left to TA review of your code and report.

## Recording

```bash
ros2 run cs498gc_a4_option_c_starter record_option_c_bag <seed> <orbit_only|orbit_scout|orbit_scout_drift> [parent_dir]
ros2 run cs498gc_a4_option_c_starter record_images_debug <name> [parent_dir]   # your debugging only
```

Order of a graded run (v1.0.3):

1. Start the world launch.
2. Start `record_option_c_bag` and wait for its line `[record_option_c_bag] READY after ... s: ...
   Start your mission nodes now.` READY means rosbag2 has subscribed to `/option_c/run_info`,
   `/option_c/clock_20hz` and every other graded topic that has a publisher (a small helper checks
   the ROS graph), and nothing has changed for 2 s; it usually takes 4 to 10 s. Until then it
   prints `not READY yet ...` every 10 s with what it is waiting for (usually: the world is not
   running in this `ROS_DOMAIN_ID`).
3. Launch your mission nodes.
4. Stop the recorder with Ctrl-C after the rover finishes.

If the recorder starts after your mission (or before READY), it prints a WARNING naming your
topics that already had publishers; restart the mission for a clean graded bag. The spec calls
the image recorder `scripts/record_images_debug.sh`; in the starter it is
`tools/record_images_debug.sh`.

### Durability (v1.0.3)

Even with the order above, rosbag2 needs 1 to 3 s to discover each new node of your mission, and a
reliable but volatile publisher never re-sends what it published before a subscriber matched. In
the course staff's first reference runs (recorder and mission started a few seconds apart) the first
`/option_c/mission_phase` event (orbital_plan_ready) was missing from 4 of 6 bags, and one bag also
lost rover_start and the first active_path, so that drive could not be graded. Therefore publish
these topics with `durability=TRANSIENT_LOCAL`, `reliability=RELIABLE` and at least this history
depth (same QoS object in Python and C++):

| topic | depth | why |
|---|---:|---|
| `/option_c/mission_phase` | >= 100 | a run has about 10 events; the grader needs the first one |
| `/option_c/rover/active_path` | >= 20 | the first path at rover_start must reach the bag |
| `/option_c/sortie_plan` | >= 5 | one plan per sortie, at most 3 |
| `/option_c/orbital_costmap`, `/option_c/orbital_path`, `/option_c/fused_costmap`, `/option_c/fused_path` | >= 1 | already transient_local in the spec |

```python
from rclpy.qos import DurabilityPolicy, QoSProfile, ReliabilityPolicy
qos = QoSProfile(depth=100, durability=DurabilityPolicy.TRANSIENT_LOCAL,
                 reliability=ReliabilityPolicy.RELIABLE)
self.pub_phase = self.create_publisher(String, "/option_c/mission_phase", qos)
```

rosbag2 matches a transient_local publisher with a transient_local subscription and receives its
stored history (up to the depth) as soon as it subscribes; staff test on Jazzy: a recorder started
5 s after a publisher sent 30 messages got all 30 from depth 100, the last 20 from depth 20, and
none from a volatile publisher. Subscribers of yours keep working: a volatile subscription matches
a transient_local publisher. History messages reach the bag late, so the grader times them by
their own stamps: `t_sim` for mission_phase, `header.stamp` for paths and costmaps. Stamp them with
sim time (the node's clock with `use_sim_time: true`). `local_check` explains a bag that lacks the
first events (missing orbital_plan_ready or rover_start) in the lost-point message.
