#!/usr/bin/env python3
"""hello_sortie.py: M0 bring-up flight for CS 498 GC A4 Option C.

Take off from the helipad, climb to 10 m, hover 20 s, fly a 20 m leg, descend and land, streaming
world-frame velocity setpoints at 10 Hz on /option_c/scout/cmd_vel (the TA watchdog rotates them
into the vehicle frame and enforces the safety limits). Then drive the rover forward 10 m through
/option_c/rover/cmd_vel_request and stop. Optionally save the first orbital frame as a PNG.

  ros2 run cs498gc_a4_option_c_starter hello_sortie --save-orbital ~/option_c_seed7_orbital_bev.png

In condition orbit_only the scout cannot take off (the watchdog rejects every takeoff), so when
/option_c/run_info says condition orbit_only, or with --rover-only, the script skips the flight
and only drives the rover (the M0 rover check of an orbit_only run):

  ros2 run cs498gc_a4_option_c_starter hello_sortie --rover-only

Options:
  --alt 10 --hover 20 --leg 20 --leg-speed 2.0   flight profile (m, s, m, m/s)
  --heading-deg H        leg direction in degrees counterclockwise from east; default: toward the
                         rover goal G read from /option_c/run_info (east if run_info is missing)
  --odom-topic T         scout pose source (default /model/ingenuity_quad_approx/odometry;
                         use /ingenuity/odom_est in odom_mode:=drift)
  --rover-drive-m 10     rover drive distance (0 = skip)
  --rover-only           skip the flight, only drive the rover (automatic in orbit_only)
  --save-orbital PATH    write the first /orbiter/bev_cam/image as PNG
  --summary PATH         write a JSON summary (also printed)
  --max-time 300         give up after this many sim seconds after the script starts

This is the simplest possible controller (proportional position hold, fixed descent speeds); your
scout_flight_controller should do better. It never publishes /ingenuity/enable false in the air.
"""
import argparse
import json
import math
import sys

import rclpy
from rclpy.node import Node
from rclpy.parameter import Parameter
from rclpy.qos import DurabilityPolicy, QoSProfile, ReliabilityPolicy
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from sensor_msgs.msg import Image
from std_msgs.msg import Bool, String

try:
    from option_c_starter.common import write_png_rgb
except ImportError:  # running from a source tree
    sys.path.insert(0, __file__.rsplit("/examples/", 1)[0])
    from option_c_starter.common import write_png_rgb


def clip(v, lim):
    return float(max(-lim, min(lim, v)))


class HelloSortie(Node):
    def __init__(self, a):
        super().__init__("hello_sortie", parameter_overrides=[Parameter("use_sim_time", value=True)])
        self.a = a
        self.pub_cmd = self.create_publisher(Twist, "/option_c/scout/cmd_vel", 10)
        self.pub_en = self.create_publisher(Bool, "/ingenuity/enable", 10)
        self.pub_rover = self.create_publisher(Twist, "/option_c/rover/cmd_vel_request", 10)
        self.create_subscription(Odometry, a.odom_topic, self.on_odom, 20)
        self.create_subscription(Odometry, "/option_c/rover/odom_truth", self.on_rover, 10)
        self.create_subscription(Image, "/orbiter/bev_cam/image", self.on_orbital, 2)
        qos = QoSProfile(depth=1, durability=DurabilityPolicy.TRANSIENT_LOCAL,
                         reliability=ReliabilityPolicy.RELIABLE)
        self.create_subscription(String, "/option_c/run_info", self.on_run_info, qos)
        self.pos = None
        self.prev = None
        self.hspeed = 0.0
        self.rover = None
        self.run_info = None
        self.state = "WAIT"
        self.t_start = None
        self.t_state = None
        self.p0 = None
        self.target = None
        self.direction = None
        self.rover_start = None
        self.rover_progress = (None, None)
        self.log = {"z": [], "hspeed": []}
        self.summary = {"first_orbital_stamp_s": None, "orbital_png": None}
        self.done = False
        self.timer = self.create_timer(0.1, self.tick)

    # -- callbacks --------------------------------------------------------------------------------
    def now(self):
        return self.get_clock().now().nanoseconds * 1e-9

    def on_odom(self, msg):
        t = msg.header.stamp.sec + msg.header.stamp.nanosec * 1e-9
        p = msg.pose.pose.position
        if self.prev is not None and t > self.prev[0]:
            dt = t - self.prev[0]
            self.hspeed = math.hypot(p.x - self.prev[1], p.y - self.prev[2]) / dt
        self.prev = (t, p.x, p.y)
        self.pos = (p.x, p.y, p.z)
        self.log["z"].append((t, p.z))
        self.log["hspeed"].append((t, self.hspeed))

    def on_rover(self, msg):
        p = msg.pose.pose.position
        self.rover = (p.x, p.y)

    def on_run_info(self, msg):
        try:
            self.run_info = json.loads(msg.data)
        except ValueError:
            pass

    def on_orbital(self, msg):
        if self.summary["first_orbital_stamp_s"] is not None:
            return
        self.summary["first_orbital_stamp_s"] = msg.header.stamp.sec + msg.header.stamp.nanosec * 1e-9
        self.summary["orbital_size"] = [msg.width, msg.height, msg.encoding]
        if self.a.save_orbital and msg.encoding in ("rgb8", "8UC3"):
            write_png_rgb(self.a.save_orbital, msg.width, msg.height, msg.data, msg.step)
            self.summary["orbital_png"] = self.a.save_orbital
        self.get_logger().info("first orbital frame at t=%.2f s" % self.summary["first_orbital_stamp_s"])

    # -- control ----------------------------------------------------------------------------------
    def send(self, vx, vy, vz):
        # Always float(): an int in a Twist float64 field aborts rclpy inside C.
        t = Twist()
        t.linear.x, t.linear.y, t.linear.z = float(vx), float(vy), float(vz)
        self.pub_cmd.publish(t)

    def hold(self, tx, ty, tz, vmax=1.0):
        x, y, z = self.pos
        self.send(clip(0.6 * (tx - x), vmax), clip(0.6 * (ty - y), vmax), clip(0.8 * (tz - z), 1.0))

    def go(self, state):
        self.state = state
        self.t_state = self.now()
        self.get_logger().info("state -> %s" % state)

    def tick(self):
        t = self.now()
        if t <= 0.0:            # no /clock yet (sim time not started)
            return
        if self.t_start is None:
            self.t_start = t    # all timing below is relative to when this script started
        if t - self.t_start > self.a.max_time and not self.done:
            self.get_logger().error("max time (%.0f s after start) reached in state %s"
                                    % (self.a.max_time, self.state))
            self.finish(ok=False)
            return
        a = self.a
        if self.pos is None and not (a.rover_only or self.state in ("ROVER", "END")):
            return                  # the flight needs the scout pose; the rover drive does not
        x, y, z = self.pos if self.pos is not None else (0.0, 0.0, 0.0)
        if self.state == "WAIT":
            if t - self.t_start < 2.0:
                return
            # run_info is transient_local; give discovery up to 10 s (it also tells the condition)
            if self.run_info is None and t - self.t_start < 10.0 and not a.rover_only:
                return
            condition = (self.run_info or {}).get("condition")
            self.summary["condition"] = condition
            if a.rover_only or condition == "orbit_only":
                why = "--rover-only" if a.rover_only else "condition orbit_only (takeoff is rejected)"
                self.get_logger().info("%s: no flight, driving the rover %.1f m"
                                       % (why, a.rover_drive_m))
                self.summary["mode"] = "rover_only"
                self.go("ROVER" if a.rover_drive_m > 0 else "END")
                return
            self.summary["mode"] = "flight_and_rover"
            self.p0 = (x, y)
            if a.heading_deg is not None:
                h = math.radians(a.heading_deg)
            elif self.run_info:
                gx, gy = self.run_info["G"]
                h = math.atan2(gy - y, gx - x)
            else:
                h = 0.0
                self.get_logger().warn("no /option_c/run_info after 10 s: leg heading east")
            self.get_logger().info("leg heading %.1f deg (counterclockwise from east)" % math.degrees(h))
            self.summary["leg_heading_deg"] = round(math.degrees(h), 2)
            self.direction = (math.cos(h), math.sin(h))
            for _ in range(3):
                self.pub_en.publish(Bool(data=True))
            self.go("CLIMB")
        elif self.state == "CLIMB":
            self.hold(self.p0[0], self.p0[1], a.alt)
            if abs(z - a.alt) < 0.3:
                self.go("HOVER")
        elif self.state == "HOVER":
            self.hold(self.p0[0], self.p0[1], a.alt)
            if t - self.t_state >= a.hover:
                self.target = (self.p0[0] + a.leg * self.direction[0],
                               self.p0[1] + a.leg * self.direction[1])
                self.go("LEG")
        elif self.state == "LEG":
            ex, ey = self.target[0] - x, self.target[1] - y
            d = math.hypot(ex, ey)
            sp = min(a.leg_speed, 0.8 * d)
            if d > 1e-6:
                self.send(sp * ex / d, sp * ey / d, clip(0.8 * (a.alt - z), 1.0))
            if d < 0.4 and self.hspeed < 0.3:
                self.go("SETTLE")
        elif self.state == "SETTLE":
            self.hold(self.target[0], self.target[1], a.alt, vmax=0.5)
            if t - self.t_state >= 2.0:
                self.go("DESCEND")
        elif self.state == "DESCEND":
            x0, y0 = self.target
            vz = -0.8 if z > 2.0 else -0.3
            self.send(clip(0.6 * (x0 - x), 0.3), clip(0.6 * (y0 - y), 0.3), vz)
            if z < 0.2:
                self.go("TOUCHDOWN")
        elif self.state == "TOUCHDOWN":
            self.send(0.0, 0.0, -0.2)
            if t - self.t_state >= 1.5:
                for _ in range(3):
                    self.pub_en.publish(Bool(data=False))
                self.send(0.0, 0.0, 0.0)
                self.go("ROVER" if a.rover_drive_m > 0 else "END")
        elif self.state == "ROVER":
            if self.rover is None:
                return
            if self.rover_start is None:
                self.rover_start = self.rover
                self.rover_progress = (t, 0.0)
            dist = math.hypot(self.rover[0] - self.rover_start[0], self.rover[1] - self.rover_start[1])
            cmd = Twist()
            if dist < a.rover_drive_m:
                cmd.linear.x = 0.5
                if dist > self.rover_progress[1] + 0.2:
                    self.rover_progress = (t, dist)
                elif t - self.rover_progress[0] > 20.0:
                    self.get_logger().warn("rover made no progress for 20 s (hazard hold?)")
                    self.summary["rover_stalled"] = True
                    self.pub_rover.publish(Twist())
                    self.summary["rover_drive_m"] = round(dist, 3)
                    self.go("END")
                    return
                self.pub_rover.publish(cmd)
            else:
                self.pub_rover.publish(Twist())
                self.summary["rover_drive_m"] = round(dist, 3)
                self.go("END")
        elif self.state == "END":
            self.pub_rover.publish(Twist())
            if self.summary["first_orbital_stamp_s"] is not None or t - self.t_state > 10.0:
                self.finish(ok=True)

    def finish(self, ok):
        if self.done:
            return
        self.done = True
        zs = self.log["z"]
        best = 0.0
        run_start = None
        for t, z in zs:
            if 9.0 <= z <= 11.0:
                run_start = t if run_start is None else run_start
                best = max(best, t - run_start)
            else:
                run_start = None
        t_touch = next((t for t, z in reversed(zs) if z >= 0.5), None)
        land_speed = None
        if t_touch is not None:
            land_speed = max((s for t, s in self.log["hspeed"] if t_touch - 2.0 <= t <= t_touch),
                             default=None)
        self.summary.update({
            "ok": ok,
            "final_state": self.state,
            "max_z_m": round(max((z for _, z in zs), default=0.0), 3),
            "longest_z_9_11_s": round(best, 2),
            "landing_hspeed_max_2s_m_s": None if land_speed is None else round(land_speed, 3),
        })
        text = json.dumps(self.summary, indent=1, sort_keys=True)
        print(text, flush=True)
        if self.a.summary:
            with open(self.a.summary, "w", encoding="utf-8") as f:
                f.write(text + "\n")


def main(argv=None):
    ap = argparse.ArgumentParser(description="Option C M0 hello sortie")
    ap.add_argument("--alt", type=float, default=10.0)
    ap.add_argument("--hover", type=float, default=20.0)
    ap.add_argument("--leg", type=float, default=20.0)
    ap.add_argument("--leg-speed", type=float, default=2.0)
    ap.add_argument("--heading-deg", type=float, default=None)
    ap.add_argument("--odom-topic", default="/model/ingenuity_quad_approx/odometry")
    ap.add_argument("--rover-drive-m", type=float, default=10.0)
    ap.add_argument("--rover-only", action="store_true",
                    help="skip the flight and only drive the rover (automatic when run_info says "
                         "condition orbit_only)")
    ap.add_argument("--save-orbital", default="")
    ap.add_argument("--summary", default="")
    ap.add_argument("--max-time", type=float, default=300.0)
    a, ros_args = ap.parse_known_args(argv)
    rclpy.init(args=ros_args)
    node = HelloSortie(a)
    try:
        while rclpy.ok() and not node.done:
            rclpy.spin_once(node, timeout_sec=0.1)
    except KeyboardInterrupt:
        pass
    except Exception as e:  # noqa: BLE001
        if rclpy.ok():
            raise
        print("hello_sortie: stopped (%s)" % type(e).__name__, file=sys.stderr)
    finally:
        try:
            if rclpy.ok():
                node.pub_cmd.publish(Twist())
            node.destroy_node()
            if rclpy.ok():
                rclpy.shutdown()
        except Exception:  # noqa: BLE001
            pass
    return 0 if node.summary.get("ok") else 1


if __name__ == "__main__":
    sys.exit(main())
