"""pixel_to_ground_stub.py: skeleton of the M0b function for tools/check_projection.py.

Copy this file to any folder, rename it (for example ~/option_c_m0b/my_projection.py), fill in the
TODO and run (calib_tile.launch.py must be running in another terminal, same ROS_DOMAIN_ID):

  ros2 run cs498gc_a4_option_c_starter check_projection --func my_projection:pixel_to_ground \\
      --module-path ~/option_c_m0b --fly --out m0b.json

--module-path is the folder that holds the file; no package, __init__.py or build is needed.

Interface (the checker calls it once per detected fiducial and frame):
  u, v   float pixel coordinates, u = column index, v = row index (v = 0 is the top row), the
         centroid of the fiducial blob in the same index coordinates as the image array
  K      list of the 9 numbers of sensor_msgs/CameraInfo.k from /ingenuity/nadir_cam/camera_info,
         row-major 3 x 3: K = [fx, 0, cx, 0, fy, cy, 0, 0, 1] (fx = fy = 233.87, cx = 160,
         cy = 120 on the starter scout)
  pose   dict with float keys x, y, z (meters) and qx, qy, qz, qw (unit quaternion): the scout
         base_link pose in the map (world) frame, interpolated to the image stamp from
         /model/ingenuity_quad_approx/odometry (linear position, slerp orientation)
  return (x, y): the ground point (z = 0) in the map frame, meters

The formulas (camera mount, ray of a pixel, ray-plane intersection) are in docs/FRAMES.md,
"Nadir camera on the scout". The mount is in config/scout_mount.yaml. The checker also calls your
function with roll and pitch removed from the pose (yaw kept) and reports that error for MR-2.
Write the projection yourself: this stub only fixes the interface.
"""


def rotation_matrix(qx, qy, qz, qw):
    """3 x 3 rotation matrix (tuple of rows) from base_link to the world for a quaternion."""
    n = (qx * qx + qy * qy + qz * qz + qw * qw) ** 0.5 or 1.0
    x, y, z, w = qx / n, qy / n, qz / n, qw / n
    return ((1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)),
            (2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)),
            (2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)))


def pixel_to_ground(u, v, K, pose):
    fx, cx = float(K[0]), float(K[2])
    fy, cy = float(K[4]), float(K[5])
    p = (float(pose["x"]), float(pose["y"]), float(pose["z"]))
    R = rotation_matrix(pose["qx"], pose["qy"], pose["qz"], pose["qw"])
    # TODO (docs/FRAMES.md, "Nadir camera on the scout"):
    #   1. the ray of pixel (u, v) in base_link (uses fx, fy, cx, cy),
    #   2. the camera center in the world (base_link position plus the rotated mount offset),
    #   3. the ray in the world (R times the base_link ray),
    #   4. intersect it with the ground plane z = 0 and return (x, y).
    del fx, cx, fy, cy, p, R
    raise NotImplementedError("pixel_to_ground_stub.py: write the projection first (see the TODO)")
