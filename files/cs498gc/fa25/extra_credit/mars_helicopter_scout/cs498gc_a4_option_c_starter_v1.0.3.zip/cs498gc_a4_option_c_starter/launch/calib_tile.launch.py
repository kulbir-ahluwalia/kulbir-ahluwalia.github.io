"""calib_tile.launch.py: nadir projection calibration world (M0b) for CS 498 GC A4 Option C.

  ros2 launch cs498gc_a4_option_c_starter calib_tile.launch.py headless:=true

Spawns the scout at the origin of worlds/calib_tile.sdf (four 1.0 m fiducials at (+-5, +-5) m) with
the same bridge, watchdog (condition orbit_scout), grader odometry relay and clock decimator as the
mission world. Then run tools/check_projection.py (it can fly the standard calibration maneuver
itself with --fly).

Arguments: headless [false], gui [true], scout_dynamics [multicopter], spawn_yaw [0.0] (rad),
gz_verbosity [2].
"""
import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import AppendEnvironmentVariable, DeclareLaunchArgument, IncludeLaunchDescription, OpaqueFunction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node

PKG = "cs498gc_a4_option_c_starter"


def _setup(context, *args, **kwargs):
    share = get_package_share_directory(PKG)
    headless = LaunchConfiguration("headless").perform(context).lower() in ("1", "true", "yes")
    gui = LaunchConfiguration("gui").perform(context).lower() in ("1", "true", "yes")
    dynamics = LaunchConfiguration("scout_dynamics").perform(context)
    if dynamics not in ("multicopter", "kinematic"):
        raise RuntimeError("scout_dynamics must be multicopter or kinematic")
    yaw = float(LaunchConfiguration("spawn_yaw").perform(context))
    verbosity = LaunchConfiguration("gz_verbosity").perform(context)
    world = os.path.join(share, "worlds", "calib_tile.sdf")
    mode = "-s --headless-rendering" if headless else ("-s" if not gui else "")
    scout_file = os.path.join(share, "models",
                              "ingenuity_quad_approx_kinematic" if dynamics == "kinematic"
                              else "ingenuity_quad_approx", "model.sdf")
    sim = {"use_sim_time": True}
    return [
        AppendEnvironmentVariable("GZ_SIM_RESOURCE_PATH", os.path.join(share, "models")),
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(os.path.join(
                get_package_share_directory("ros_gz_sim"), "launch", "gz_sim.launch.py")),
            launch_arguments={"gz_args": "-r -v %s %s %s" % (verbosity, mode, world),
                              "gz_version": "8", "on_exit_shutdown": "true"}.items()),
        Node(package="ros_gz_sim", executable="create", name="spawn_scout", output="screen",
             arguments=["-world", "calib_tile", "-file", scout_file, "-name", "ingenuity_quad_approx",
                        "-x", "0", "-y", "0", "-z", "0.08", "-Y", "%.4f" % yaw]),
        Node(package="ros_gz_bridge", executable="parameter_bridge", name="option_c_bridge",
             output="screen",
             parameters=[{"config_file": os.path.join(share, "config", "option_c_bridge.yaml")}]),
        Node(package=PKG, executable="clock_decimator", name="clock_decimator", parameters=[sim]),
        Node(package=PKG, executable="scout_odom_relay", name="scout_odom_relay", parameters=[sim]),
        Node(package=PKG, executable="scout_safety_watchdog", name="scout_safety_watchdog",
             output="screen", parameters=[sim, {"condition": "orbit_scout",
                                                "scout_dynamics": dynamics, "odom_mode": "truth"}]),
    ]


def generate_launch_description():
    args = [("headless", "false"), ("gui", "true"), ("scout_dynamics", "multicopter"),
            ("spawn_yaw", "0.0"), ("gz_verbosity", "2")]
    return LaunchDescription([DeclareLaunchArgument(n, default_value=d) for n, d in args]
                             + [OpaqueFunction(function=_setup)])
