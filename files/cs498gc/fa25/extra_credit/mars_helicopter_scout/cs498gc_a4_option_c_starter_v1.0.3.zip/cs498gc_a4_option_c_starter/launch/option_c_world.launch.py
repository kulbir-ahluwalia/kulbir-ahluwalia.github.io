"""option_c_world.launch.py: CS 498 GC A4 Extra Credit Option C world + TA nodes.

  ros2 launch cs498gc_a4_option_c_starter option_c_world.launch.py seed:=7 condition:=orbit_scout

Arguments (defaults in brackets):
  seed [7]                       world seed (your three NetID seeds for graded runs; 7 = practice)
  condition [orbit_scout]        orbit_only | orbit_scout   (orbit_only: the watchdog rejects takeoff)
  headless [false]               true = gz sim -s -r --headless-rendering (no GUI, cameras still render)
  gui [true]                     false = server only (ignored when headless:=true)
  shadows [true]                 false = load a copy of the world with shadows off (slow laptops);
                                 run_info still reports the canonical world_sha256
  scout_dynamics [multicopter]   multicopter | kinematic (fallback: velocity-commanded camera platform)
  odom_mode [truth]              truth | drift (bonus: /ingenuity/odom_est + /ingenuity/nav_status)
  rover [starter]                starter | custom
  rover_description_file ['']    rover:=custom only: an SDF or URDF file spawned as model 'rover'; it
                                 must listen on gz /model/rover/cmd_vel and publish
                                 /model/rover/odometry (see xacro/odom_truth_plugin.xacro)
  rover_footprint_radius_m [0.45]  footprint radius used by the TA guard (>= 0.45)
  student_pkg_src ['']           path to YOUR src/option_c_scout; hashed into run_info src_sha256
  work_dir ['']                  where the generated world and ground truth are written
                                 (default $OPTION_C_WORK_DIR or ~/.ros/cs498gc_option_c)
  gz_verbosity [2]               gz sim -v level
  render_engine_path ['']        '' = the world's <render_engine>ogre2</render_engine>;
                                 'auto' or a full path to libgz-rendering8-ogre2.so = load a copy
                                 of the world with that full path (second fix for machines with
                                 both Harmonic and Jetty; run_info keeps the canonical hash)

Machines with BOTH Gazebo Harmonic and Gazebo Jetty installed: launch from a shell that has sourced
/opt/ros/jazzy/setup.bash (verified fix for the camera segfault); see docs/FRAMES.md and
docs/KNOWN_LIMITS.md.
"""
import glob
import importlib.util
import json
import math
import os
import subprocess
from pathlib import Path

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import (AppendEnvironmentVariable, DeclareLaunchArgument, IncludeLaunchDescription,
                            LogInfo, OpaqueFunction)
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node

PKG = "cs498gc_a4_option_c_starter"
SCOUT_NAME = "ingenuity_quad_approx"


def _load_generator(share):
    path = os.path.join(share, "tools", "gen_option_c_world.py")
    spec = importlib.util.spec_from_file_location("gen_option_c_world", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def gz_sim_version():
    try:
        out = subprocess.run(["gz", "sim", "--versions"], capture_output=True, text=True,
                             timeout=20).stdout.split()
        v8 = [v for v in out if v.startswith("8.")]
        return v8[0] if v8 else (out[0] if out else "unknown")
    except Exception:  # noqa: BLE001
        return "unknown"


def resolve_render_engine(value):
    """'' -> None (use 'ogre2' as written in the world); 'auto' -> the full path of
    libgz-rendering8-ogre2.so on this machine; anything else must be an existing file."""
    if not value:
        return None
    if value == "auto":
        hits = sorted(glob.glob("/usr/lib/*/gz-rendering-8/engine-plugins/libgz-rendering8-ogre2.so")
                      + glob.glob("/usr/lib/gz-rendering-8/engine-plugins/libgz-rendering8-ogre2.so")
                      + glob.glob("/opt/ros/*/opt/gz_rendering_vendor/lib/gz-rendering-8/"
                                  "engine-plugins/libgz-rendering8-ogre2.so"))
        if not hits:
            raise RuntimeError("render_engine_path:=auto found no libgz-rendering8-ogre2.so; "
                               "pass the full path instead")
        return hits[0]
    if not Path(value).is_file():
        raise RuntimeError("render_engine_path:=%s is not a file" % value)
    return value


def display_variant(sdf_path, shadows, render_engine):
    """Return (world file to load, variant name). The canonical file is never modified; a variant
    is a copy next to it, so run_info still reports the canonical world_sha256."""
    if shadows and not render_engine:
        return sdf_path, "canonical"
    txt = Path(sdf_path).read_text(encoding="utf-8")
    parts = []
    if not shadows:
        txt = txt.replace("<shadows>true</shadows>", "<shadows>false</shadows>")
        txt = txt.replace("<cast_shadows>true</cast_shadows>", "<cast_shadows>false</cast_shadows>")
        parts.append("noshadows")
    if render_engine:
        txt = txt.replace("<render_engine>ogre2</render_engine>",
                          "<render_engine>%s</render_engine>" % render_engine)
        parts.append("ogre2fullpath")
    name = ".".join(parts)
    out = Path(str(sdf_path).replace(".sdf", ".%s.sdf" % name))
    out.write_text(txt, encoding="utf-8")
    return out, name


def _choice(context, name, allowed):
    v = LaunchConfiguration(name).perform(context).strip()
    if v not in allowed:
        raise RuntimeError("launch argument %s:=%s is not one of %s" % (name, v, allowed))
    return v


def _bool(context, name):
    return LaunchConfiguration(name).perform(context).strip().lower() in ("1", "true", "yes", "on")


def _setup(context, *args, **kwargs):
    share = get_package_share_directory(PKG)
    seed = int(LaunchConfiguration("seed").perform(context))
    condition = _choice(context, "condition", ("orbit_only", "orbit_scout"))
    dynamics = _choice(context, "scout_dynamics", ("multicopter", "kinematic"))
    odom_mode = _choice(context, "odom_mode", ("truth", "drift"))
    rover = _choice(context, "rover", ("starter", "custom"))
    headless = _bool(context, "headless")
    gui = _bool(context, "gui")
    shadows = _bool(context, "shadows")
    r_fp = float(LaunchConfiguration("rover_footprint_radius_m").perform(context))
    if r_fp < 0.45:
        raise RuntimeError("rover_footprint_radius_m must be >= 0.45")
    student_src = LaunchConfiguration("student_pkg_src").perform(context).strip()
    if student_src:
        student_src = str(Path(student_src).expanduser().resolve())
        if not Path(student_src).is_dir():
            raise RuntimeError("student_pkg_src=%s is not a directory" % student_src)
    work = LaunchConfiguration("work_dir").perform(context).strip() or None
    verbosity = LaunchConfiguration("gz_verbosity").perform(context).strip() or "2"

    render_engine = resolve_render_engine(
        LaunchConfiguration("render_engine_path").perform(context).strip())

    gen = _load_generator(share)
    sdf_path, gt_path, sha = gen.write_world(seed, work)
    world_to_load, variant = display_variant(sdf_path, shadows, render_engine)
    gt = json.loads(Path(gt_path).read_text(encoding="utf-8"))
    sx, sy = gt["S"]
    gx, gy = gt["G"]
    hx, hy = gt["helipad"]
    yaw = math.atan2(gy - sy, gx - sx)

    if headless:
        mode = "-s --headless-rendering"
    elif not gui:
        mode = "-s"
    else:
        mode = ""
    gz_args = "-r -v %s %s %s" % (verbosity, mode, world_to_load)

    actions = [
        AppendEnvironmentVariable("GZ_SIM_RESOURCE_PATH", os.path.join(share, "models")),
        LogInfo(msg="[option_c] seed=%d condition=%s dynamics=%s odom_mode=%s rover=%s world=%s "
                    "(%s) sha256=%s" % (seed, condition, dynamics, odom_mode, rover, world_to_load,
                                        variant, sha)),
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(os.path.join(
                get_package_share_directory("ros_gz_sim"), "launch", "gz_sim.launch.py")),
            launch_arguments={"gz_args": gz_args, "gz_version": "8",
                              "on_exit_shutdown": "true"}.items()),
    ]

    scout_file = os.path.join(share, "models",
                              "ingenuity_quad_approx_kinematic" if dynamics == "kinematic"
                              else "ingenuity_quad_approx", "model.sdf")
    actions.append(Node(package="ros_gz_sim", executable="create", name="spawn_scout", output="screen",
                        arguments=["-world", gt["world_name"], "-file", scout_file, "-name", SCOUT_NAME,
                                   "-x", "%.4f" % hx, "-y", "%.4f" % hy, "-z", "0.08",
                                   "-Y", "%.4f" % yaw]))
    if rover == "custom":
        rover_file = LaunchConfiguration("rover_description_file").perform(context).strip()
        if not rover_file or not Path(rover_file).is_file():
            raise RuntimeError("rover:=custom needs rover_description_file:=<existing SDF or URDF>")
    else:
        rover_file = os.path.join(share, "models", "option_c_rover", "model.sdf")
    actions.append(Node(package="ros_gz_sim", executable="create", name="spawn_rover", output="screen",
                        arguments=["-world", gt["world_name"], "-file", rover_file, "-name", "rover",
                                   "-x", "%.4f" % sx, "-y", "%.4f" % sy, "-z", "0.02",
                                   "-Y", "%.4f" % yaw]))

    bridge_cfg = os.path.join(share, "config", "option_c_bridge_drift.yaml" if odom_mode == "drift"
                              else "option_c_bridge.yaml")
    actions.append(Node(package="ros_gz_bridge", executable="parameter_bridge", name="option_c_bridge",
                        output="screen", parameters=[{"config_file": bridge_cfg}]))

    sim = {"use_sim_time": True}
    gt_file = str(gt_path)
    actions += [
        Node(package=PKG, executable="clock_decimator", name="clock_decimator", output="screen",
             parameters=[sim]),
        Node(package=PKG, executable="run_info_publisher", name="run_info_publisher", output="screen",
             parameters=[sim, {"seed": seed, "condition": condition, "world_file": str(sdf_path),
                               "loaded_world_file": str(world_to_load), "world_variant": variant,
                               "ground_truth_file": gt_file, "student_pkg_src": student_src,
                               "odom_mode": odom_mode, "scout_dynamics": dynamics, "rover": rover,
                               "rover_footprint_radius_m": r_fp,
                               "ros_distro": os.environ.get("ROS_DISTRO", ""),
                               "gz_sim_version": gz_sim_version()}]),
        Node(package=PKG, executable="scout_odom_relay", name="scout_odom_relay", output="screen",
             parameters=[sim]),
        Node(package=PKG, executable="scout_safety_watchdog", name="scout_safety_watchdog",
             output="screen", parameters=[sim, {"condition": condition, "scout_dynamics": dynamics,
                                                "odom_mode": odom_mode}]),
        Node(package=PKG, executable="rover_hazard_guard", name="rover_hazard_guard", output="screen",
             parameters=[sim, {"ground_truth_file": gt_file, "rover_footprint_radius_m": r_fp}]),
        Node(package=PKG, executable="hazcam_sim", name="hazcam_sim", output="screen",
             parameters=[sim, {"ground_truth_file": gt_file, "seed": seed}]),
    ]
    if odom_mode == "drift":
        actions.append(Node(package=PKG, executable="odom_degrader", name="odom_degrader",
                            output="screen", parameters=[sim, {"seed": seed,
                                                               "ground_truth_file": gt_file}]))
    return actions


def generate_launch_description():
    args = [
        ("seed", "7"), ("condition", "orbit_scout"), ("headless", "false"), ("gui", "true"),
        ("shadows", "true"), ("scout_dynamics", "multicopter"), ("odom_mode", "truth"),
        ("rover", "starter"), ("rover_description_file", ""), ("rover_footprint_radius_m", "0.45"),
        ("student_pkg_src", ""), ("work_dir", ""), ("gz_verbosity", "2"),
        ("render_engine_path", ""),
    ]
    return LaunchDescription([DeclareLaunchArgument(n, default_value=d) for n, d in args]
                             + [OpaqueFunction(function=_setup)])
