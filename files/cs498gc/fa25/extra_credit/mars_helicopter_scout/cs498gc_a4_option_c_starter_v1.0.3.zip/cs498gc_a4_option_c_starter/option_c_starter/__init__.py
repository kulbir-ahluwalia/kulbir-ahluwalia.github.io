"""CS 498 GC / ABE 426 A4 Extra Credit Option C (Mars Helicopter Scout) starter, TA nodes."""
