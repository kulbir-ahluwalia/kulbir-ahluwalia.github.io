"""clock_decimator (TA): republish simulation time as /option_c/clock_20hz.

Raw /clock arrives every physics step (250 Hz) and is never recorded. This node publishes one
rosgraph_msgs/Clock whenever sim time has advanced by at least 0.05 s, so the bags carry a 20 Hz
time base. The grader maps receive times of headerless messages (Twist, Bool, String) to sim time
through this topic.
"""
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy
from rosgraph_msgs.msg import Clock

from .common import T_CLOCK_20HZ, run_node, stamp_to_sec


class ClockDecimator(Node):
    def __init__(self):
        super().__init__("clock_decimator")
        self.declare_parameter("period_s", 0.05)
        self.period = float(self.get_parameter("period_s").value)
        self.last = None
        qos_in = QoSProfile(depth=10, reliability=ReliabilityPolicy.BEST_EFFORT,
                            history=HistoryPolicy.KEEP_LAST)
        self.pub = self.create_publisher(Clock, T_CLOCK_20HZ, 10)
        self.sub = self.create_subscription(Clock, "/clock", self.on_clock, qos_in)

    def on_clock(self, msg):
        t = stamp_to_sec(msg.clock)
        if self.last is None or t - self.last >= self.period - 1e-6 or t < self.last:
            self.last = t
            self.pub.publish(msg)


def main(args=None):
    return run_node(ClockDecimator, args)


if __name__ == "__main__":
    main()
