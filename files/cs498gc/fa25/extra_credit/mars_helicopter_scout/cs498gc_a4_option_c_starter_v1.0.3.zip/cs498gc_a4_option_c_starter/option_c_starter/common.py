"""Shared helpers for the CS 498 GC A4 Option C starter (TA) nodes.

Students: these helpers are part of the TA starter; your own package must not import the ground
truth loaders below (source check AG-26 flags 'ground_truth' and 'hazards_seed' in student code).
"""
import hashlib
import json
import math
import os
import struct
import zlib
from pathlib import Path

STARTER_VERSION = "1.0.3"
PKG = "cs498gc_a4_option_c_starter"

# Topics (single place so nodes and tools agree)
T_SCOUT_ODOM_PUBLIC = "/model/ingenuity_quad_approx/odometry"
# Private truth input of the TA nodes. It lives under /option_c/grader/ on purpose: student code
# must never use it, and source check AG-26 flags any '/option_c/grader' string.
T_SCOUT_ODOM_PRIVATE = "/option_c/grader/_private/scout_odom_truth"
T_SCOUT_ODOM_GRADER = "/option_c/grader/scout_odom"
T_SCOUT_ODOM_EST = "/ingenuity/odom_est"
T_SCOUT_NAV_STATUS = "/ingenuity/nav_status"
T_SCOUT_CMD_STUDENT = "/option_c/scout/cmd_vel"
T_SCOUT_CMD_MULTICOPTER = "/ingenuity/gazebo/command/twist"
T_SCOUT_CMD_KINEMATIC = "/model/ingenuity_quad_approx/cmd_vel"
T_SCOUT_ENABLE = "/ingenuity/enable"
# TA-only: the watchdog forwards /ingenuity/enable here (bridged to the gz controller's enable
# input) and ignores false while the scout is airborne. Under gazebo/command, so AG-26 flags it.
T_SCOUT_ENABLE_GZ = "/ingenuity/gazebo/command/enable"
T_WATCHDOG_EVENTS = "/option_c/scout/watchdog_events"
T_ROVER_ODOM = "/option_c/rover/odom_truth"
T_ROVER_CMD_REQUEST = "/option_c/rover/cmd_vel_request"
T_ROVER_CMD = "/option_c/rover/cmd_vel"
T_ROVER_HAZCAM = "/option_c/rover/hazcam"
T_ROVER_HAZARD_STOP = "/option_c/rover/hazard_stop"
T_RUN_INFO = "/option_c/run_info"
T_CLOCK_20HZ = "/option_c/clock_20hz"

SCOUT_LANDED_HAZARD_RADIUS = 0.35   # the landed scout counts as a 0.35 m disk hazard
SRC_HASH_EXCLUDED_DIRS = {"__pycache__", "build", "install", "log", ".git"}


# ----------------------------------------------------------------------------------------------
# Node runner with a quiet Ctrl-C (launch sends SIGINT, then SIGTERM)
# ----------------------------------------------------------------------------------------------
def run_node(factory, args=None):
    """Create the node with factory(), spin it, and shut down quietly on SIGINT or SIGTERM.

    rclpy's own signal handler invalidates the context while the executor is waiting, so the next
    wait can raise RCLError ('the given context is not valid') or crash in C during shutdown. Here
    rclpy installs no signal handler: Python turns SIGINT and SIGTERM into KeyboardInterrupt in
    this thread, the spin loop ends, and shutdown runs once, in order. spin_once uses a 0.2 s wall
    timeout so a stopped /clock (simulator already gone) cannot block the exit.

    If the signal arrives while rclpy is inside a C++ call (for example taking a message), pybind11
    reports the KeyboardInterrupt as a RuntimeError ('Unable to convert call argument ...'); once a
    stop signal has been received any exception from the spin loop is a normal exit (seen in 1 of
    31 shutdowns of clock_decimator in the course staff's tests, which then exited with code 1)."""
    import signal

    import rclpy
    try:
        from rclpy.signals import SignalHandlerOptions
        rclpy.init(args=args, signal_handler_options=SignalHandlerOptions.NO)
    except (ImportError, TypeError):  # older rclpy without the option
        rclpy.init(args=args)

    stopping = []

    def _to_interrupt(signum, frame):  # noqa: ARG001
        stopping.append(signum)
        raise KeyboardInterrupt

    signal.signal(signal.SIGINT, _to_interrupt)
    signal.signal(signal.SIGTERM, _to_interrupt)
    node = None
    try:
        node = factory()
        while rclpy.ok() and not stopping:
            rclpy.spin_once(node, timeout_sec=0.2)
    except KeyboardInterrupt:
        pass
    except Exception as e:  # noqa: BLE001
        # A stop signal surfaced inside rclpy, or the context was already shut down by someone
        # else: treat both as a normal exit.
        if not stopping and (type(e).__name__ not in ("ExternalShutdownException", "RCLError")
                             or rclpy.ok()):
            raise
    finally:
        signal.signal(signal.SIGINT, signal.SIG_IGN)
        signal.signal(signal.SIGTERM, signal.SIG_IGN)
        try:
            if node is not None:
                node.destroy_node()
        except Exception:  # noqa: BLE001
            pass
        try:
            if rclpy.ok():
                rclpy.shutdown()
        except Exception:  # noqa: BLE001
            pass
    return 0


# ----------------------------------------------------------------------------------------------
# Ground truth (TA nodes only)
# ----------------------------------------------------------------------------------------------
def load_ground_truth(path):
    with open(path, "r", encoding="utf-8") as f:
        gt = json.load(f)
    return gt


def gt_disk_hazards(gt):
    """List of (id, type, x, y, radius) for boulders and rocks."""
    out = []
    for h in gt.get("boulders", []) + gt.get("rocks", []):
        out.append((h["id"], h["type"], float(h["x"]), float(h["y"]), float(h["radius"])))
    return out


def gt_sand_polygon(gt):
    return [(float(p[0]), float(p[1])) for p in gt["sand_patch"]["polygon"]]


# ----------------------------------------------------------------------------------------------
# Geometry
# ----------------------------------------------------------------------------------------------
def point_in_polygon(px, py, poly):
    inside = False
    n = len(poly)
    j = n - 1
    for i in range(n):
        xi, yi = poly[i]
        xj, yj = poly[j]
        if (yi > py) != (yj > py):
            xc = xi + (py - yi) * (xj - xi) / (yj - yi)
            if px < xc:
                inside = not inside
        j = i
    return inside


def dist_point_segment(px, py, ax, ay, bx, by):
    vx, vy = bx - ax, by - ay
    vv = vx * vx + vy * vy
    if vv <= 0.0:
        return math.hypot(px - ax, py - ay)
    t = max(0.0, min(1.0, ((px - ax) * vx + (py - ay) * vy) / vv))
    return math.hypot(px - (ax + t * vx), py - (ay + t * vy))


def dist_point_polygon(px, py, poly):
    """0.0 inside, else distance to the boundary."""
    if point_in_polygon(px, py, poly):
        return 0.0
    n = len(poly)
    return min(dist_point_segment(px, py, poly[i][0], poly[i][1],
                                  poly[(i + 1) % n][0], poly[(i + 1) % n][1]) for i in range(n))


def yaw_from_quat(x, y, z, w):
    return math.atan2(2.0 * (w * z + x * y), 1.0 - 2.0 * (y * y + z * z))


def quat_from_yaw(yaw):
    return (0.0, 0.0, math.sin(yaw / 2.0), math.cos(yaw / 2.0))


def quat_multiply(a, b):
    ax, ay, az, aw = a
    bx, by, bz, bw = b
    return (aw * bx + ax * bw + ay * bz - az * by,
            aw * by - ax * bz + ay * bw + az * bx,
            aw * bz + ax * by - ay * bx + az * bw,
            aw * bw - ax * bx - ay * by - az * bz)


def stamp_to_sec(stamp):
    return stamp.sec + stamp.nanosec * 1e-9


def clamp_xy(vx, vy, vmax):
    """(vx, vy) scaled to length <= vmax with its direction kept, plus a 'clamped' flag. Safe for
    every finite input: hypot(1e308, 1e308) is inf, and vx * vmax overflows to inf for |vx| above
    about 6e307, so the vector is first divided by its largest component (each part is then in
    [-1, 1] and the length in [1, sqrt(2)]). A zero or non-finite input is returned unchanged
    (the watchdog replaces non-finite commands by zero before it clamps)."""
    m = max(abs(vx), abs(vy))
    if not (m > 0.0) or not math.isfinite(m) or not vmax > 0.0:
        return vx, vy, False
    ux, uy = vx / m, vy / m
    h = math.hypot(ux, uy)
    if m <= vmax / h:
        return vx, vy, False
    s = vmax / h
    return ux * s, uy * s, True


def twist_is_finite(msg):
    """True if all six fields of a geometry_msgs/Twist are finite numbers. NaN slips through
    every comparison-based clamp (abs(nan) > x is False, min(1.0, nan) is 1.0), so the TA
    command filters reject non-finite commands before clamping."""
    try:
        return all(math.isfinite(float(v)) for v in (
            msg.linear.x, msg.linear.y, msg.linear.z,
            msg.angular.x, msg.angular.y, msg.angular.z))
    except (TypeError, ValueError, AttributeError):
        return False


# ----------------------------------------------------------------------------------------------
# Hashes
# ----------------------------------------------------------------------------------------------
def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def src_tree_lines(root):
    """Lines '<relative path> <file sha256>' for every regular file under root, skipping any path
    with a component in SRC_HASH_EXCLUDED_DIRS and files ending in .pyc. Relative paths use '/'.
    Symbolic links are not followed (a symlinked file is hashed as the file it points to only if
    it is a regular file entry; symlinked directories are skipped)."""
    root = Path(root)
    lines = []
    for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
        dirnames[:] = sorted(d for d in dirnames if d not in SRC_HASH_EXCLUDED_DIRS)
        for fn in filenames:
            if fn.endswith(".pyc"):
                continue
            full = Path(dirpath) / fn
            if not full.is_file():
                continue
            rel = full.relative_to(root).as_posix()
            lines.append("%s %s" % (rel, sha256_file(full)))
    return sorted(lines)


def src_tree_sha256(root):
    """src_sha256 definition (shared with the grader, AG-06): sha256 of the UTF-8 text formed by
    the sorted lines '<relative path> <file sha256>' joined with '\\n' plus one trailing '\\n'."""
    lines = src_tree_lines(root)
    text = "".join(line + "\n" for line in lines)
    return hashlib.sha256(text.encode("utf-8")).hexdigest(), len(lines)


# ----------------------------------------------------------------------------------------------
# SHA-256 counter-mode RNG (same construction as tools/gen_option_c_world.py)
# ----------------------------------------------------------------------------------------------
class ShaRng:
    def __init__(self, seed, domain):
        self.prefix = ("cs498gc-a4c:%s:%d:" % (domain, int(seed))).encode("ascii")
        self.counter = 0

    def u01(self):
        h = hashlib.sha256(self.prefix + str(self.counter).encode("ascii")).digest()
        self.counter += 1
        return int.from_bytes(h[:8], "big") / 18446744073709551616.0

    def uniform(self, a, b):
        return a + (b - a) * self.u01()


def drift_parameters(rng=None):
    """Starting values of the bonus drift model (odom_mode:=drift), drawn fresh for EVERY run from
    os.urandom (not from the seed), so no seed, earlier run or copied code reproduces them:
    |yaw-rate bias| in [0.02, 0.05] deg/s with a random sign, velocity scale error in [-3 %, +3 %],
    both x5 over the sand patch. odom_degrader then lets both values random-walk inside these ranges.

    TA use only (odom_degrader). rng: a random.Random for unit tests; None = os.urandom. AG-26 still
    flags 'drift_parameters' and 'odom_degrader' in student source: copying the drift model is never
    a substitute for registration."""
    import random
    r = rng if rng is not None else random.Random(int.from_bytes(os.urandom(32), "big"))
    yaw_bias_dps = r.uniform(0.02, 0.05) * (1.0 if r.random() < 0.5 else -1.0)
    scale_err = r.uniform(-0.03, 0.03)
    return {"yaw_rate_bias_deg_s": yaw_bias_dps, "velocity_scale_error": scale_err,
            "feature_poor_multiplier": 5.0}


# ----------------------------------------------------------------------------------------------
# PNG writer (stdlib) for saving camera frames
# ----------------------------------------------------------------------------------------------
def write_png_rgb(path, width, height, data, step=None):
    """data: bytes of an R8G8B8 image with row stride `step` (default 3 * width)."""
    step = 3 * width if step is None else step
    rows = [b"\x00" + bytes(data[r * step:r * step + 3 * width]) for r in range(height)]

    def chunk(tag, payload):
        return (struct.pack(">I", len(payload)) + tag + payload
                + struct.pack(">I", zlib.crc32(tag + payload) & 0xFFFFFFFF))

    png = (b"\x89PNG\r\n\x1a\n"
           + chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0))
           + chunk(b"IDAT", zlib.compress(b"".join(rows), 6))
           + chunk(b"IEND", b""))
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_bytes(png)
