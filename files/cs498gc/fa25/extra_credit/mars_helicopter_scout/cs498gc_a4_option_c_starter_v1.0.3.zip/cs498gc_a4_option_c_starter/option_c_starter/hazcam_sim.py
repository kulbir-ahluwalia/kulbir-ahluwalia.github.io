"""hazcam_sim (TA): idealized rover hazard camera.

Publishes /option_c/rover/hazcam (geometry_msgs/PoseArray, frame 'map', 5 Hz of sim time):
  * the center of every ground-truth rock within 3.0 m of the rover and within +/-60 deg of its
    heading,
  * points every 0.5 m along each boulder's edge circle and along the sand-patch polygon edges,
    for the points that fall inside the same sector,
each with Gaussian position noise sigma 0.05 m (orientation is identity and carries no meaning).
It does not model occlusion. It is a stand-in for the rover's onboard stereo hazard detection;
insert the points into your working costmap as disks of radius hazcam_obstacle_radius_m.
"""
import math
import random

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Pose, PoseArray
from nav_msgs.msg import Odometry

from .common import T_ROVER_HAZCAM, T_ROVER_ODOM, load_ground_truth, run_node, yaw_from_quat


def _edge_points(gt, spacing):
    pts = []
    for b in gt.get("boulders", []):
        r = float(b["radius"])
        n = max(8, int(math.ceil(2.0 * math.pi * r / spacing)))
        for k in range(n):
            a = 2.0 * math.pi * k / n
            pts.append((float(b["x"]) + r * math.cos(a), float(b["y"]) + r * math.sin(a)))
    poly = [(float(p[0]), float(p[1])) for p in gt["sand_patch"]["polygon"]]
    for i in range(len(poly)):
        ax, ay = poly[i]
        bx, by = poly[(i + 1) % len(poly)]
        seg = math.hypot(bx - ax, by - ay)
        n = max(1, int(math.ceil(seg / spacing)))
        for k in range(n):
            t = k / n
            pts.append((ax + t * (bx - ax), ay + t * (by - ay)))
    return pts


class HazcamSim(Node):
    def __init__(self):
        super().__init__("hazcam_sim")
        p = self.declare_parameter
        p("ground_truth_file", "")
        p("range_m", 3.0)
        p("half_fov_deg", 60.0)
        p("rate_hz", 5.0)
        p("noise_sigma_m", 0.05)
        p("edge_spacing_m", 0.5)
        p("seed", 7)
        g = lambda n: self.get_parameter(n).value  # noqa: E731
        gt = load_ground_truth(g("ground_truth_file"))
        self.rocks = [(float(r["x"]), float(r["y"])) for r in gt.get("rocks", [])]
        self.edges = _edge_points(gt, float(g("edge_spacing_m")))
        self.range = float(g("range_m"))
        self.cos_half = math.cos(math.radians(float(g("half_fov_deg"))))
        self.sigma = float(g("noise_sigma_m"))
        self.rng = random.Random(int(g("seed")) * 7919 + 17)
        self.pose = None
        self.pub = self.create_publisher(PoseArray, T_ROVER_HAZCAM, 10)
        self.create_subscription(Odometry, T_ROVER_ODOM, self.on_odom, 10)
        self.timer = self.create_timer(1.0 / float(g("rate_hz")), self.tick)

    def on_odom(self, msg):
        q = msg.pose.pose.orientation
        p = msg.pose.pose.position
        self.pose = (p.x, p.y, yaw_from_quat(q.x, q.y, q.z, q.w))

    def _visible(self, x, y, px, py, hx, hy):
        dx, dy = px - x, py - y
        d = math.hypot(dx, dy)
        if d > self.range:
            return False
        if d < 1e-6:
            return True
        return (dx * hx + dy * hy) / d >= self.cos_half

    def tick(self):
        if self.pose is None:
            return
        x, y, yaw = self.pose
        hx, hy = math.cos(yaw), math.sin(yaw)
        msg = PoseArray()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = "map"
        for src in (self.rocks, self.edges):
            for px, py in src:
                if abs(px - x) > self.range or abs(py - y) > self.range:
                    continue
                if self._visible(x, y, px, py, hx, hy):
                    pose = Pose()
                    pose.position.x = px + self.rng.gauss(0.0, self.sigma)
                    pose.position.y = py + self.rng.gauss(0.0, self.sigma)
                    pose.orientation.w = 1.0
                    msg.poses.append(pose)
        self.pub.publish(msg)


def main(args=None):
    return run_node(HazcamSim, args)


if __name__ == "__main__":
    main()
