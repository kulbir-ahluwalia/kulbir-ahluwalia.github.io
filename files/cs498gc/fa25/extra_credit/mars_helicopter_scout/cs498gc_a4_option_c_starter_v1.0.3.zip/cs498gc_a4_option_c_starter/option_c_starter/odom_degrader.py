"""odom_degrader (TA, bonus odom_mode:=drift only): drifting scout pose estimate.

Input:  /option_c/grader/_private/scout_odom_truth (truth, 20 Hz; student code never uses it)
Output: /ingenuity/odom_est   (nav_msgs/Odometry) - the ONLY scout pose student code may use in
                                drift mode: every truth message (20 Hz) while z > 0.3 m, one
                                message per sim second while z <= 0.3 m (1 Hz on the ground, like
                                the grader's scout_odom relay; keeps drift bags small)
        /ingenuity/nav_status (std_msgs/String, 2 Hz of sim time) - 'FEATURE_POOR' while the
                                scout is over the sand patch, else 'NOMINAL'

Drift model (design values, not Ingenuity's measured error statistics):
  * a yaw-rate bias b and a velocity scale error s, drawn FRESH FOR EVERY RUN from os.urandom
    (common.drift_parameters): |b| in [0.02, 0.05] deg/s with a random sign, s in [-3 %, +3 %].
    Neither depends on the seed, so no earlier run, seed or copied code reproduces them,
  * both random-walk inside their ranges while the simulation runs (|b| by about 0.006 deg/s and
    s by about 0.8 % per square-root second, reflected at the range ends), so a value read at one
    moment is soon out of date,
  * white gyro noise: while the scout is above 0.5 m the yaw-error rate is k b + n, with n a new
    normal draw (standard deviation 0.01 rad/s) for every message; n is integrated into the yaw
    error too (angle random walk, about 0.13 deg per square-root second),
  * k = 5 while the scout is over the sand patch (FEATURE_POOR), else 1,
  * the yaw error grows only while the scout is above 0.5 m (truth altitude; the same height above
    which the watchdog's heading hold and yaw disturbance act): e += (k b + n) dt,
  * the estimated horizontal position integrates the true world-frame velocity (finite
    differences of truth positions), scaled by (1 + k s) and rotated by the yaw error e,
  * altitude is the true altitude (Ingenuity also had a laser altimeter),
  * orientation is the true orientation with the yaw error added about the world z axis.
The estimate starts equal to the truth at launch.

The twist is consistent with the drifting pose, so it carries no truth that the pose does not:
  * linear (body frame of the estimated orientation): the estimated world velocity, i.e. the
    true horizontal velocity scaled by (1 + k s) and rotated by e, plus the true vertical speed,
    expressed in the estimated body frame,
  * angular (body frame): the true body rates plus the yaw-error rate de/dt = k b + n (0 below
    0.5 m) about the world z axis. Integrating this gyro gives the estimated yaw, not the true
    yaw, and dead reckoning with odom_est's twist reproduces odom_est's pose, not the truth.
Why the noise and the random walks: the scout often holds its true heading exactly for seconds
(after takeoff, hovering, landing). With a constant, noise-free bias the gyro then read exactly
k b, and the whole yaw error could be undone from public data without registration (found in the
course staff's tests). Now a gyro reading is k b + n with n much larger than b, and b itself keeps
changing (unit tests in test/test_drift_integrity.py).

Integrity: the per-run values are never published, logged (no /rosout line) or declared as ROS
parameters; only the design ranges above are documented. Student code that copies this node or
common.drift_parameters is flagged by AG-26 for TA review.
"""
import math
import os
import random

import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from std_msgs.msg import String

from .common import (T_SCOUT_NAV_STATUS, T_SCOUT_ODOM_EST, T_SCOUT_ODOM_PRIVATE,
                     drift_parameters, gt_sand_polygon, load_ground_truth, point_in_polygon,
                     quat_from_yaw, quat_multiply, run_node, stamp_to_sec)

AIRBORNE_Z_M = 0.3      # above this odom_est is published at 20 Hz (like the grader's relay)
GROUND_PERIOD_S = 1.0   # odom_est period while z <= AIRBORNE_Z_M
DRIFT_Z_M = 0.5         # above this the yaw error grows (= the watchdog's airborne_z_m)
BIAS_RANGE_DEG_S = (0.02, 0.05)     # |yaw-rate bias|
SCALE_RANGE = (-0.03, 0.03)         # velocity scale error
BIAS_WALK_DEG_S = 0.006             # random-walk std of |b| per square-root second
SCALE_WALK = 0.008                  # random-walk std of s per square-root second
GYRO_NOISE_RAD_S = 0.01             # std of the white gyro (yaw-error rate) noise per message


def quat_rotate(q, v):
    """Rotate the vector v by the unit quaternion q = (x, y, z, w)."""
    x, y, z, w = q
    # t = 2 (u x v); v' = v + w t + u x t
    tx = 2.0 * (y * v[2] - z * v[1])
    ty = 2.0 * (z * v[0] - x * v[2])
    tz = 2.0 * (x * v[1] - y * v[0])
    return (v[0] + w * tx + (y * tz - z * ty),
            v[1] + w * ty + (z * tx - x * tz),
            v[2] + w * tz + (x * ty - y * tx))


def quat_conjugate(q):
    return (-q[0], -q[1], -q[2], q[3])


def reflect(x, lo, hi):
    """Fold x back into [lo, hi] (reflecting random walk)."""
    span = hi - lo
    if span <= 0.0:
        return lo
    y = (x - lo) % (2.0 * span)
    return lo + (y if y <= span else 2.0 * span - y)


def new_run_rng():
    """A random.Random seeded from os.urandom: different in every run, reproducible by nobody."""
    return random.Random(int.from_bytes(os.urandom(32), "big"))


class DriftState:
    """The drift model without ROS (unit-tested). One step per truth message.

    By default every value comes from new_run_rng() (os.urandom). Unit tests pass rng, and may fix
    bias_rad_s / scale and set the walks or the noise to 0."""

    def __init__(self, sand_polygon, rng=None, bias_rad_s=None, scale=None,
                 mult=5.0, gyro_noise=GYRO_NOISE_RAD_S, bias_walk_deg_s=BIAS_WALK_DEG_S,
                 scale_walk=SCALE_WALK, drift_z=DRIFT_Z_M):
        self.rng = rng if rng is not None else new_run_rng()
        if bias_rad_s is None or scale is None:
            d = drift_parameters(self.rng)
            if bias_rad_s is None:
                bias_rad_s = math.radians(d["yaw_rate_bias_deg_s"])
            if scale is None:
                scale = d["velocity_scale_error"]
            del d
        self._sign = 1.0 if bias_rad_s >= 0.0 else -1.0
        self._bias_mag = abs(bias_rad_s)
        self._bias_lo, self._bias_hi = (math.radians(BIAS_RANGE_DEG_S[0]),
                                        math.radians(BIAS_RANGE_DEG_S[1]))
        self._bias_walk = math.radians(bias_walk_deg_s)
        self._scale = scale
        self._scale_walk = scale_walk
        self.mult = mult
        self.gyro_noise = gyro_noise
        self.sand = sand_polygon
        self.drift_z = drift_z
        self.prev = None          # (t, x, y)
        self.est_xy = None
        self.yaw_err = 0.0
        self.e_dot = 0.0          # yaw-error rate of the latest step (published in the gyro)
        self.over_sand = False

    @property
    def bias(self):
        return self._sign * self._bias_mag

    @property
    def scale(self):
        return self._scale

    def _walk(self, dt):
        sq = math.sqrt(dt)
        if self._bias_walk > 0.0:
            lo = min(self._bias_lo, self._bias_mag)
            hi = max(self._bias_hi, self._bias_mag)
            self._bias_mag = reflect(self._bias_mag + self.rng.gauss(0.0, self._bias_walk * sq),
                                     lo, hi)
        if self._scale_walk > 0.0:
            lo = min(SCALE_RANGE[0], self._scale)
            hi = max(SCALE_RANGE[1], self._scale)
            self._scale = reflect(self._scale + self.rng.gauss(0.0, self._scale_walk * sq), lo, hi)

    def step(self, t, pos, quat, v_body, w_body):
        """pos (x, y, z), quat (x, y, z, w), v_body and w_body: the truth twist (body frame).
        Returns (est_pos, est_quat, est_v_body, est_w_body)."""
        self.over_sand = bool(self.sand) and point_in_polygon(pos[0], pos[1], self.sand)
        k = self.mult if self.over_sand else 1.0
        drifting = pos[2] > self.drift_z
        self.e_dot = 0.0
        if self.prev is None or self.est_xy is None:
            self.est_xy = [pos[0], pos[1]]
        else:
            dt = t - self.prev[0]
            if 0.0 < dt < 1.0:
                self._walk(dt)
                vx = (pos[0] - self.prev[1]) / dt
                vy = (pos[1] - self.prev[2]) / dt
                if drifting:
                    noise = self.rng.gauss(0.0, self.gyro_noise) if self.gyro_noise > 0.0 else 0.0
                    self.e_dot = k * self.bias + noise
                    self.yaw_err += self.e_dot * dt
                c, s = math.cos(self.yaw_err), math.sin(self.yaw_err)
                f = 1.0 + k * self._scale
                self.est_xy[0] += f * (c * vx - s * vy) * dt
                self.est_xy[1] += f * (s * vx + c * vy) * dt
        self.prev = (t, pos[0], pos[1])

        q_true = tuple(quat)
        q_est = quat_multiply(quat_from_yaw(self.yaw_err), q_true)
        # linear: the estimated world velocity, expressed in the estimated body frame
        f = 1.0 + k * self._scale
        c, s = math.cos(self.yaw_err), math.sin(self.yaw_err)
        vw = quat_rotate(q_true, v_body)
        v_est_world = (f * (c * vw[0] - s * vw[1]), f * (s * vw[0] + c * vw[1]), vw[2])
        v_est_body = quat_rotate(quat_conjugate(q_est), v_est_world)
        # angular: the true body rates plus de/dt (incl. the gyro noise) about the world z axis
        e_dot = self.e_dot
        zb = quat_rotate(quat_conjugate(q_true), (0.0, 0.0, 1.0))
        w_est_body = (w_body[0] + e_dot * zb[0], w_body[1] + e_dot * zb[1],
                      w_body[2] + e_dot * zb[2])
        return (self.est_xy[0], self.est_xy[1], pos[2]), q_est, v_est_body, w_est_body


class OdomDegrader(Node):
    def __init__(self):
        super().__init__("odom_degrader")
        # 'seed' is accepted for launch compatibility only: the drift values never depend on it.
        self.declare_parameter("seed", 7)
        self.declare_parameter("ground_truth_file", "")
        gt = load_ground_truth(self.get_parameter("ground_truth_file").value)
        self.state = DriftState(gt_sand_polygon(gt))   # per-run values from os.urandom
        # Never log the per-run values: /rosout is readable by student nodes.
        self.get_logger().info("odom_degrader: drift model active (fresh random values for this "
                               "run inside the documented ranges; the values are not published)")
        self.last_ground = None
        self.pub_est = self.create_publisher(Odometry, T_SCOUT_ODOM_EST, 20)
        self.pub_status = self.create_publisher(String, T_SCOUT_NAV_STATUS, 10)
        self.create_subscription(Odometry, T_SCOUT_ODOM_PRIVATE, self.on_truth, 20)
        self.timer = self.create_timer(0.5, self.publish_status)

    def publish_status(self):
        self.pub_status.publish(String(data="FEATURE_POOR" if self.state.over_sand else "NOMINAL"))

    def on_truth(self, msg):
        t = stamp_to_sec(msg.header.stamp)
        p = msg.pose.pose.position
        q = msg.pose.pose.orientation
        lin = msg.twist.twist.linear
        ang = msg.twist.twist.angular
        est_p, est_q, est_v, est_w = self.state.step(
            t, (p.x, p.y, p.z), (q.x, q.y, q.z, q.w), (lin.x, lin.y, lin.z), (ang.x, ang.y, ang.z))
        # Every truth message is integrated; on the ground only one per GROUND_PERIOD_S is sent.
        if p.z <= AIRBORNE_Z_M:
            if (self.last_ground is not None
                    and 0.0 <= t - self.last_ground < GROUND_PERIOD_S - 1e-6):
                return
            self.last_ground = t
        else:
            self.last_ground = None
        out = Odometry()
        out.header = msg.header
        out.child_frame_id = msg.child_frame_id
        out.pose.pose.position.x, out.pose.pose.position.y, out.pose.pose.position.z = est_p
        (out.pose.pose.orientation.x, out.pose.pose.orientation.y,
         out.pose.pose.orientation.z, out.pose.pose.orientation.w) = est_q
        out.twist.twist.linear.x, out.twist.twist.linear.y, out.twist.twist.linear.z = est_v
        out.twist.twist.angular.x, out.twist.twist.angular.y, out.twist.twist.angular.z = est_w
        self.pub_est.publish(out)


def main(args=None):
    return run_node(OdomDegrader, args)


if __name__ == "__main__":
    main()
