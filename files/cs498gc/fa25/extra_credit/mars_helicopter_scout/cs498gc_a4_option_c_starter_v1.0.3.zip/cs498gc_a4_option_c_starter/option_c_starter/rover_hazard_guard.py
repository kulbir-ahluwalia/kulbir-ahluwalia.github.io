"""rover_hazard_guard (TA): the only node that commands the rover's wheels.

Students stream /option_c/rover/cmd_vel_request (geometry_msgs/Twist, body frame: linear.x forward
m/s, angular.z yaw rate rad/s) while driving. Every 1/20 s of sim time this node publishes
/option_c/rover/cmd_vel (bridged to the rover's DiffDrive) after:
  * caps: |linear.x| <= 1.0 m/s, |angular.z| <= 1.0 rad/s,
  * staleness: a request older than 0.5 s gives a zero command,
  * a request with any non-finite field (NaN, inf) is treated like a stale request: zero command
    (logged at most every 5 s). Without this, min(1.0, nan) = 1.0 drove the rover at full speed,
  * stop-and-hold: if the rover footprint circle (radius rover_footprint_radius_m), swept along
    the commanded direction (forward if linear.x > 0, backward if < 0) up to the lookahead
    distance L, overlaps a ground-truth hazard (boulder or rock disk, the sand polygon, or the
    landed scout as a 0.35 m disk), the guard holds the rover still for 10.0 s of sim time and
    publishes /option_c/rover/hazard_stop True at the start and False at the end. L depends on
    speed so the rover can stop before touching the hazard:
        L = max(0.60, v^2 / (2 a) + v t_lat + margin)
    with v the larger of the commanded and measured speed, a = 1.0 m/s^2 (the starter rover's
    DiffDrive deceleration), t_lat = 0.15 s (10 Hz odometry plus the 20 Hz guard tick) and
    margin = 0.25 m. At 1.0 m/s, L = 0.90 m; at or below about 0.4 m/s, L = 0.60 m.
    (A fixed 0.60 m let the rover stop about 0.05 m inside the rock at 1.0 m/s.)
  * after a hold it blocks (zeroes the linear part of) every command that would trigger again,
    WITHOUT counting a new stop. Turning in place is always allowed. The block ends once
    commands have passed without triggering for 1.0 s of sim time.

This models an onboard hazard-avoidance stop (like AutoNav's), not a measured NASA figure. It is
idealized: it knows the true hazard positions. Your rover_executive should replan around the
hazcam detections so the guard rarely fires.

The landed scout is placed at its TRUE position in every odom_mode (a safety device must protect
the real vehicle). In odom_mode:=drift a stop (or the 'landed_scout ahead' log line) near the
scout's landing spot is therefore a truth-derived signal: student code must not use it to
correct /ingenuity/odom_est (TOPICS.md, HANDOUT B1).
"""
import math

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from std_msgs.msg import Bool

from .common import (SCOUT_LANDED_HAZARD_RADIUS, T_ROVER_CMD, T_ROVER_CMD_REQUEST,
                     T_ROVER_HAZARD_STOP, T_ROVER_ODOM, T_SCOUT_ODOM_PRIVATE,
                     dist_point_polygon, gt_disk_hazards, gt_sand_polygon, load_ground_truth,
                     run_node, twist_is_finite, yaw_from_quat)


class RoverHazardGuard(Node):
    def __init__(self):
        super().__init__("rover_hazard_guard")
        p = self.declare_parameter
        p("ground_truth_file", "")
        p("rover_footprint_radius_m", 0.45)
        p("lookahead_m", 0.60)       # minimum lookahead (the spec's 0.60 m)
        p("brake_decel_m_s2", 1.0)   # starter rover DiffDrive min_linear_acceleration
        p("latency_s", 0.15)         # odometry period (0.1 s) + guard tick (0.05 s)
        p("margin_m", 0.25)
        p("sweep_step_m", 0.10)
        p("hold_s", 10.0)
        p("rate_hz", 20.0)
        p("stale_s", 0.5)
        p("v_max", 1.0)
        p("w_max", 1.0)
        p("unblock_s", 1.0)
        g = lambda n: self.get_parameter(n).value  # noqa: E731
        gt = load_ground_truth(g("ground_truth_file"))
        self.disks = gt_disk_hazards(gt)
        self.sand = gt_sand_polygon(gt)
        self.r_fp = float(g("rover_footprint_radius_m"))
        self.look = float(g("lookahead_m"))
        self.brake = max(0.1, float(g("brake_decel_m_s2")))
        self.latency = float(g("latency_s"))
        self.margin = float(g("margin_m"))
        self.sweep_step = max(0.02, float(g("sweep_step_m")))
        self.hold_s = float(g("hold_s"))
        self.stale_s = float(g("stale_s"))
        self.v_max = float(g("v_max"))
        self.w_max = float(g("w_max"))
        self.unblock_s = float(g("unblock_s"))
        self.pub_cmd = self.create_publisher(Twist, T_ROVER_CMD, 10)
        self.pub_stop = self.create_publisher(Bool, T_ROVER_HAZARD_STOP, 10)
        self.create_subscription(Twist, T_ROVER_CMD_REQUEST, self.on_req, 10)
        self.create_subscription(Odometry, T_ROVER_ODOM, self.on_odom, 10)
        self.create_subscription(Odometry, T_SCOUT_ODOM_PRIVATE, self.on_scout, 10)
        self.req = None
        self.t_req = None
        self.pose = None
        self.prev_odom = None        # (t, x, y) for the measured speed
        self.speed = 0.0
        self.scout_xy = None
        self.hold_until = None
        self.blocking = False
        self.t_clear_since = None
        self.stops = 0
        self.timer = self.create_timer(1.0 / float(g("rate_hz")), self.tick)

    def now(self):
        return self.get_clock().now().nanoseconds * 1e-9

    def on_req(self, msg):
        if not twist_is_finite(msg):
            # Same as a stale request: the rover stops (zero command) until a finite one arrives.
            self.req = None
            self.t_req = None
            self.get_logger().warn("non-finite /option_c/rover/cmd_vel_request ignored (rover "
                                   "stopped)", throttle_duration_sec=5.0)
            return
        self.req = msg
        self.t_req = self.now()

    def on_odom(self, msg):
        q = msg.pose.pose.orientation
        p = msg.pose.pose.position
        t = msg.header.stamp.sec + msg.header.stamp.nanosec * 1e-9
        if self.prev_odom is not None and t > self.prev_odom[0]:
            self.speed = (math.hypot(p.x - self.prev_odom[1], p.y - self.prev_odom[2])
                          / (t - self.prev_odom[0]))
        self.prev_odom = (t, p.x, p.y)
        self.pose = (p.x, p.y, yaw_from_quat(q.x, q.y, q.z, q.w))

    def lookahead(self, v_cmd):
        v = max(abs(v_cmd), self.speed)
        return max(self.look, v * v / (2.0 * self.brake) + v * self.latency + self.margin)

    def on_scout(self, msg):
        p = msg.pose.pose.position
        self.scout_xy = (p.x, p.y) if p.z < 0.3 else None

    def triggering_hazard(self, cx, cy):
        r = self.r_fp
        for hid, _typ, hx, hy, hr in self.disks:
            if abs(cx - hx) > r + hr or abs(cy - hy) > r + hr:
                continue
            if math.hypot(cx - hx, cy - hy) < r + hr:
                return hid
        if dist_point_polygon(cx, cy, self.sand) < r:
            return "sand_patch"
        if self.scout_xy is not None:
            if math.hypot(cx - self.scout_xy[0], cy - self.scout_xy[1]) < r + SCOUT_LANDED_HAZARD_RADIUS:
                return "landed_scout"
        return None

    def tick(self):
        t = self.now()
        out = Twist()
        if self.hold_until is not None:
            if t < self.hold_until:
                self.pub_cmd.publish(out)
                return
            self.hold_until = None
            self.blocking = True
            self.t_clear_since = None
            self.pub_stop.publish(Bool(data=False))
            self.get_logger().info("hazard hold ended at t=%.2f" % t)
        fresh = self.req is not None and self.t_req is not None and 0.0 <= t - self.t_req <= self.stale_s
        if not fresh or self.pose is None:
            self.pub_cmd.publish(out)
            return
        v = max(-self.v_max, min(self.v_max, self.req.linear.x))
        w = max(-self.w_max, min(self.w_max, self.req.angular.z))
        hazard = None
        if abs(v) > 0.02:
            x, y, yaw = self.pose
            sgn = 1.0 if v > 0 else -1.0
            look = self.lookahead(v)
            n = max(1, int(math.ceil(look / self.sweep_step)))
            c, s = math.cos(yaw), math.sin(yaw)
            for k in range(1, n + 1):
                d = sgn * look * k / n
                hazard = self.triggering_hazard(x + d * c, y + d * s)
                if hazard is not None:
                    break
        if hazard is not None:
            if self.blocking:
                v = 0.0
                self.t_clear_since = None
            else:
                self.stops += 1
                self.hold_until = t + self.hold_s
                self.pub_stop.publish(Bool(data=True))
                self.get_logger().warn("hazard stop #%d at t=%.2f: %s ahead (speed %.2f m/s, "
                                       "lookahead %.2f m)" % (self.stops, t, hazard, self.speed,
                                                              self.lookahead(v)))
                self.pub_cmd.publish(Twist())
                return
        elif self.blocking and abs(v) > 0.02:
            if self.t_clear_since is None:
                self.t_clear_since = t
            elif t - self.t_clear_since >= self.unblock_s:
                self.blocking = False
        out.linear.x = v
        out.angular.z = w
        self.pub_cmd.publish(out)


def main(args=None):
    return run_node(RoverHazardGuard, args)


if __name__ == "__main__":
    main()
