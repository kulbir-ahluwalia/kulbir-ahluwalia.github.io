"""run_info_publisher (TA): publish /option_c/run_info (std_msgs/String, JSON, transient_local).

Keys: seed, condition, world_sha256, src_sha256, starter_version, odom_mode, scout_dynamics, rover,
rover_footprint_radius_m, S, G, helipad, ros_distro, gz_sim_version, plus informational keys
(loaded_world_sha256, world_variant, src_files, src_note, generator_version,
first_orbital_t_sim). No file paths are published: run_info is readable by students and recorded
in submitted bags, and the world-file and ground-truth paths would point at the hazard list (and
put the student's home directory into the bag).

world_sha256 is the sha256 of the canonical generated SDF bytes for the seed (what the grader
regenerates with gen_option_c_world.py --seed N). If the launch loaded a display variant
(shadows:=false), the variant's own hash is reported separately as loaded_world_sha256.

src_sha256 hashes the student package directory given by launch argument student_pkg_src; see
common.src_tree_sha256 for the exact definition (AG-06).

first_orbital_t_sim is null until the first /orbiter/bev_cam/camera_info arrives; then it holds
that message's header stamp (sim seconds) and run_info is republished at once. local_check M0
uses it for the "first orbital frame within 15 s of sim start" criterion, which a bag that starts
recording late cannot show by itself.

The message is published once at startup (transient_local, so late subscribers such as
ros2 bag record receive it) and again every `republish_period_s` of sim time.
"""
import json

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, DurabilityPolicy, ReliabilityPolicy
from sensor_msgs.msg import CameraInfo
from std_msgs.msg import String

from .common import (STARTER_VERSION, T_RUN_INFO, load_ground_truth, run_node, sha256_file,
                     src_tree_sha256, stamp_to_sec)

T_ORBITER_CAMINFO = "/orbiter/bev_cam/camera_info"


class RunInfoPublisher(Node):
    def __init__(self):
        super().__init__("run_info_publisher")
        p = self.declare_parameter
        p("seed", 7)
        p("condition", "orbit_scout")
        p("world_file", "")
        p("loaded_world_file", "")
        p("world_variant", "canonical")
        p("ground_truth_file", "")
        p("student_pkg_src", "")
        p("odom_mode", "truth")
        p("scout_dynamics", "multicopter")
        p("rover", "starter")
        p("rover_footprint_radius_m", 0.45)
        p("ros_distro", "")
        p("gz_sim_version", "")
        p("republish_period_s", 10.0)
        g = lambda n: self.get_parameter(n).value  # noqa: E731

        world = g("world_file")
        loaded = g("loaded_world_file") or world
        gt = load_ground_truth(g("ground_truth_file"))
        info = {
            "seed": int(g("seed")),
            "condition": g("condition"),
            "world_sha256": sha256_file(world) if world else "",
            "src_sha256": "",
            "starter_version": STARTER_VERSION,
            "odom_mode": g("odom_mode"),
            "scout_dynamics": g("scout_dynamics"),
            "rover": g("rover"),
            "rover_footprint_radius_m": float(g("rover_footprint_radius_m")),
            "S": gt["S"],
            "G": gt["G"],
            "helipad": gt["helipad"],
            "ros_distro": g("ros_distro"),
            "gz_sim_version": g("gz_sim_version"),
            "loaded_world_sha256": sha256_file(loaded) if loaded else "",
            "world_variant": g("world_variant"),
            "generator_version": gt.get("generator_version", ""),
            "first_orbital_t_sim": None,
        }
        src = g("student_pkg_src")
        if src:
            try:
                digest, nfiles = src_tree_sha256(src)
                info["src_sha256"] = digest
                info["src_files"] = nfiles
                info["src_note"] = "hashed student_pkg_src (%d files)" % nfiles
            except OSError as e:
                info["src_note"] = "could not hash student_pkg_src: %s" % type(e).__name__
        else:
            info["src_note"] = ("student_pkg_src not set: pass student_pkg_src:=<path to "
                                "src/option_c_scout> when you record graded bags")
        self.info = info
        self.text = json.dumps(info, sort_keys=True)
        qos = QoSProfile(depth=1, durability=DurabilityPolicy.TRANSIENT_LOCAL,
                         reliability=ReliabilityPolicy.RELIABLE)
        self.pub = self.create_publisher(String, T_RUN_INFO, qos)
        self.cam_sub = self.create_subscription(CameraInfo, T_ORBITER_CAMINFO, self.on_orbital, 5)
        self.publish_once()
        self.timer = self.create_timer(float(g("republish_period_s")), self.publish_once)
        self.get_logger().info("run_info: %s" % self.text)

    def on_orbital(self, msg):
        if self.info["first_orbital_t_sim"] is not None:
            return
        self.info["first_orbital_t_sim"] = round(stamp_to_sec(msg.header.stamp), 3)
        self.text = json.dumps(self.info, sort_keys=True)
        self.publish_once()
        self.get_logger().info("first orbital camera_info at t_sim %.3f s"
                               % self.info["first_orbital_t_sim"])
        # The subscription stays (0.5 Hz, cheap): destroying it inside its own callback is not
        # safe with every rclpy executor.

    def publish_once(self):
        self.pub.publish(String(data=self.text))


def main(args=None):
    return run_node(RunInfoPublisher, args)


if __name__ == "__main__":
    main()
