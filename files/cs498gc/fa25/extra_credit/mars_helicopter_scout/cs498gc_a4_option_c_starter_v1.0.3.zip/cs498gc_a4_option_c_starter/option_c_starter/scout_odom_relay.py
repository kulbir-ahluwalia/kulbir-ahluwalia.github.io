"""scout_odom_relay (TA): truth scout odometry for the grader.

Input:  /option_c/grader/_private/scout_odom_truth  (bridge of gz
        /model/ingenuity_quad_approx/odometry, 20 Hz, in every odom_mode)
Output: /option_c/grader/scout_odom          every message while z > 0.3 m (20 Hz airborne),
        one message per sim second while z <= 0.3 m (1 Hz on the ground)

Student nodes must never subscribe to /option_c/grader/* (source check AG-26).
"""
import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry

from .common import T_SCOUT_ODOM_PRIVATE, T_SCOUT_ODOM_GRADER, run_node, stamp_to_sec


class ScoutOdomRelay(Node):
    def __init__(self):
        super().__init__("scout_odom_relay")
        self.declare_parameter("airborne_z_m", 0.3)
        self.declare_parameter("ground_period_s", 1.0)
        self.z_air = float(self.get_parameter("airborne_z_m").value)
        self.ground_period = float(self.get_parameter("ground_period_s").value)
        self.last_ground = None
        self.pub = self.create_publisher(Odometry, T_SCOUT_ODOM_GRADER, 20)
        self.sub = self.create_subscription(Odometry, T_SCOUT_ODOM_PRIVATE, self.on_odom, 20)

    def on_odom(self, msg):
        t = stamp_to_sec(msg.header.stamp)
        if msg.pose.pose.position.z > self.z_air:
            self.pub.publish(msg)
            self.last_ground = None
            return
        if (self.last_ground is None or t - self.last_ground >= self.ground_period - 1e-6
                or t < self.last_ground):
            self.last_ground = t
            self.pub.publish(msg)


def main(args=None):
    return run_node(ScoutOdomRelay, args)


if __name__ == "__main__":
    main()
