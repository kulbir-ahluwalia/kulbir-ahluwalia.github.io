"""scout_safety_watchdog (TA): the only node that commands the scout's flight controller.

Students publish WORLD-FRAME ENU velocity on /option_c/scout/cmd_vel (geometry_msgs/Twist:
linear.x east, linear.y north, linear.z up, angular.z yaw rate), at >= 10 Hz while airborne.
Every 1/20 s of sim time this node:
  * replaces a command with any non-finite field (NaN or inf, for example from dividing by a zero
    vector length) by a zero twist, i.e. hover in place (event invalid_cmd, at most once per
    second). Without this a single NaN reached the rotor controller and the scout fell,
  * rotates the command into the vehicle heading frame using the scout yaw (truth yaw, or the
    /ingenuity/odom_est yaw when odom_mode:=drift, so drift mode flies in the estimated frame),
  * clamps |v_xy| <= 3.0 m/s, v_z to [-1.0, 1.0] m/s and the yaw rate to [-1.0, 1.0] rad/s
    (event speed_clamped, at most once per second). The horizontal clamp keeps the direction and
    is overflow-safe (common.clamp_xy): a huge finite command such as 1e308 flies at 3 m/s,
    where v x 3 / |v| used to overflow to inf and give a hover instead,
  * slew-limits the horizontal velocity setpoint (world frame) to accel_xy_max = 1.0 m/s^2:
    a step from hover to 3 m/s becomes a 3 s ramp (about 4.5 m), and stopping from 3 m/s takes
    3 s and about 4.5 m. This applies to the watchdog's own stops too (cmd_timeout, invalid_cmd,
    geofence, ceiling, forced descent). Without it a 3 m/s step made the quadrotor pitch to
    about 49 deg and sink about 2.5 m at 10 m cruise even with v_z = 0, and it could not climb
    while braking,
  * odom_mode:=drift only, while airborne (z > 0.5 m): holds the ESTIMATED heading. The yaw-rate
    command becomes your yaw rate plus est_heading_gain x (psi_c - odom_est yaw) plus a yaw-rate
    disturbance, where psi_c starts at the odom_est yaw at takeoff and integrates your (clamped)
    yaw rate. So the odom_est yaw follows your yaw-rate commands, and the true heading drifts by
    minus the yaw error, as for a real vehicle whose heading control uses a drifting estimate.
    The disturbance is a zero-mean random process drawn fresh for every run from os.urandom
    (about 0.02 rad/s, correlation time about 3 s, like the yaw disturbances a real vehicle
    meets); the hold rejects its effect on the heading within seconds. Why both: without the
    hold the true heading stayed constant (the controller holds it while the yaw-rate command is
    zero), so dead reckoning with odom_est's body velocity at the start heading undid the yaw
    drift; with the hold alone the true heading followed exactly from the documented hold law,
    odom_est and your own commands, which undid it too (both found in the course staff's tests),
  * the published twist (/ingenuity/gazebo/command/twist) is this node's output to the
    controller: in drift mode it contains the disturbance and therefore the true heading's
    history. It is a TA-internal topic; student code must not subscribe to it (AG-26 flags
    'gazebo/command' in student source),
  * sends a zero twist if the newest student command is older than 0.5 s (event cmd_timeout,
    once per timeout episode, only while airborne),
  * geofence: |x| or |y| > 78 m logs one 'geofence' event per excursion. While outside, the
    outward parts of the command are removed; a command that still points inward is passed
    through (no climbing above 3 m) so the scout can fly back in; with no inward command the
    scout hovers for 2 s, then descends at 1 m/s to touchdown. The excursion (and the event
    latch) ends when the scout is back inside, so a scout that landed outside can take off
    toward the inside without logging new events,
  * ceiling: z > 20 m gives descent at 1 m/s until z < 19 m,
  * 120 s airborne (z > 0.5 m) gives a forced descent at 1 m/s to touchdown,
  * condition orbit_only: always a zero twist; any takeoff attempt (nonzero command or
    /ingenuity/enable true) gives event takeoff_rejected (at most once per 2 s),
and publishes the result on /ingenuity/gazebo/command/twist.

Enable: students publish /ingenuity/enable (std_msgs/Bool). Since v1.0.2 the bridge no longer
sends that topic to Gazebo; this node forwards it to the TA-only /ingenuity/gazebo/command/enable
(bridged to the multicopter controller's enable input). true is always forwarded. false is
forwarded only while the scout is not airborne (truth z <= landed_z_m, 0.3 m, or no pose yet);
while airborne it is ignored and logged as event enable_ignored (at most once per second), so the
scout keeps flying. Reason: false disables MulticopterVelocityControl, the rotors stop and the
scout fell from 1.48 m to 0.07 m in 4 s in a staff test (teleop's 'g' did that at any altitude).
With scout_dynamics:=kinematic nothing in gz reads the enable topic; there a forwarded false makes
this node send a zero twist until the next true, as before.

With scout_dynamics:=kinematic this node publishes the same twist on
/model/ingenuity_quad_approx/cmd_vel too (the VelocityControl input
of the kinematic model); nothing in gz listens to /ingenuity/gazebo/command/twist in that mode,
but the recorded command topic is the same in both modes, so a kinematic bag passes AG-04/AG-05.
Every published twist is checked to be finite (a non-finite result is replaced by zero).
Ground idle rate: while the scout is landed (z < 0.3 m), the twist to send is zero, no nonzero
student command is fresh and /ingenuity/enable was not set true in the last second, the zero twist
is repeated at ground_idle_rate_hz (default 1 Hz) instead of 20 Hz. The controllers latch the last
twist, so nothing changes in flight; the graded rate rule (>= 10 Hz) is checked over airborne
intervals only, and the bag saves about 2.2 KB per second of ground time.
A fresh nonzero command or an enable switches back to 20 Hz on the next tick.

Why: MulticopterVelocityControl latches the last twist forever (no timeout), so a crashed node
would let the scout fly away (found in the course staff's simulator tests).

Events go to /option_c/scout/watchdog_events as JSON {"t_sim": .., "event": .., "x": .., "y": ..,
"z": .., "pose_source": ..}. Event names: cmd_timeout, geofence, ceiling, forced_descent,
speed_clamped, takeoff_rejected, invalid_cmd, enable_ignored. Safety checks (geofence, ceiling, airborne time)
always use truth odometry, but the position written into an event (and into its /rosout log line)
never is truth in odom_mode:=drift: there it is the /ingenuity/odom_est position (pose_source
"odom_est"), or no position at all before the first estimate (pose_source "none"). In truth mode it
is the truth position (pose_source "truth"), which students may read on
/model/ingenuity_quad_approx/odometry anyway. Without this, drift mode would leak a truth fix
with every event, for example once per second through speed_clamped.
The TIME of a geofence event (and the scout's reaction to the fence) still follows the truth: it
marks the moment the true x or y crossed +/-78 m. In drift mode that is a truth-derived signal that
student code must not use to correct odom_est (TOPICS.md, HANDOUT B1). The ceiling uses the
altitude, which odom_est reports without error, and forced_descent the airborne time.
"""
import json
import math
import os
import random

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from std_msgs.msg import Bool, String

from .common import (T_SCOUT_CMD_KINEMATIC, T_SCOUT_CMD_MULTICOPTER, T_SCOUT_CMD_STUDENT,
                     T_SCOUT_ENABLE, T_SCOUT_ENABLE_GZ, T_SCOUT_ODOM_EST, T_SCOUT_ODOM_PRIVATE,
                     T_WATCHDOG_EVENTS, clamp_xy, run_node, twist_is_finite, yaw_from_quat)


def ou_step(x, dt, std, tau, gauss):
    """One step of a zero-mean Ornstein-Uhlenbeck process with stationary std `std` and
    correlation time `tau` (the drift-mode yaw-rate disturbance). x None starts it from its
    stationary distribution. std <= 0 gives 0. gauss(mu, sigma) is the random source."""
    if std <= 0.0:
        return 0.0
    if x is None:
        return gauss(0.0, std)
    a = math.exp(-max(dt, 0.0) / tau) if tau > 0.0 else 0.0
    return a * x + std * math.sqrt(max(0.0, 1.0 - a * a)) * gauss(0.0, 1.0)


def event_payload(name, t, truth_xyz, est_xyz, drift):
    """JSON-ready dict for one watchdog event.

    truth_xyz / est_xyz: (x, y, z) or None. In drift mode the truth position is never used: the
    event carries the odom_est position, or none. Unit-tested in test/test_drift_integrity.py."""
    payload = {"t_sim": round(float(t), 3), "event": str(name)}
    if drift:
        xyz, src = est_xyz, "odom_est"
    else:
        xyz, src = truth_xyz, "truth"
    if xyz is None or not all(math.isfinite(v) for v in xyz):
        payload["pose_source"] = "none"
        return payload
    payload.update({"x": round(xyz[0], 3), "y": round(xyz[1], 3), "z": round(xyz[2], 3),
                    "pose_source": src})
    return payload


class ScoutSafetyWatchdog(Node):
    def __init__(self):
        super().__init__("scout_safety_watchdog")
        p = self.declare_parameter
        p("condition", "orbit_scout")
        p("scout_dynamics", "multicopter")
        p("odom_mode", "truth")
        p("rate_hz", 20.0)
        p("cmd_timeout_s", 0.5)
        p("vxy_max", 3.0)
        p("vz_max", 1.0)
        p("wz_max", 1.0)
        p("accel_xy_max", 1.0)          # horizontal setpoint slew limit (m/s^2); <= 0 disables
        p("est_heading_gain", 0.5)      # drift mode: estimated-heading hold gain (1/s); <= 0 disables
        p("est_heading_corr_max", 0.2)  # drift mode: largest heading-hold correction (rad/s)
        p("yaw_disturbance_std", 0.02)   # drift mode: std of the yaw-rate disturbance (rad/s); <= 0 off
        p("yaw_disturbance_tau_s", 3.0)  # drift mode: its correlation time (s)
        p("geofence_m", 78.0)
        p("ceiling_m", 20.0)
        p("ceiling_release_m", 19.0)
        p("max_airborne_s", 120.0)
        p("descent_speed", 1.0)
        p("geofence_hover_s", 2.0)
        p("airborne_z_m", 0.5)
        p("landed_z_m", 0.3)
        p("ground_idle_rate_hz", 1.0)   # <= 0 or >= rate_hz: always publish at rate_hz
        g = lambda n: self.get_parameter(n).value  # noqa: E731
        self.condition = g("condition")
        self.kinematic = g("scout_dynamics") == "kinematic"
        self.drift = g("odom_mode") == "drift"
        self.cfg = {n: float(g(n)) for n in (
            "cmd_timeout_s", "vxy_max", "vz_max", "wz_max", "accel_xy_max", "est_heading_gain",
            "est_heading_corr_max", "yaw_disturbance_std", "yaw_disturbance_tau_s",
            "geofence_m", "ceiling_m",
            "ceiling_release_m", "max_airborne_s", "descent_speed", "geofence_hover_s",
            "airborne_z_m", "landed_z_m")}

        # The command topic recorded in the bags is /ingenuity/gazebo/command/twist in both modes;
        # the kinematic model's VelocityControl input gets the same twist in addition.
        out_topic = T_SCOUT_CMD_MULTICOPTER
        self.pub_cmd_main = self.create_publisher(Twist, T_SCOUT_CMD_MULTICOPTER, 10)
        self.pub_cmd_kin = (self.create_publisher(Twist, T_SCOUT_CMD_KINEMATIC, 10)
                            if self.kinematic else None)
        if self.kinematic:
            out_topic = "%s + %s" % (T_SCOUT_CMD_MULTICOPTER, T_SCOUT_CMD_KINEMATIC)
        self.pub_enable_gz = self.create_publisher(Bool, T_SCOUT_ENABLE_GZ, 10)
        self.pub_evt = self.create_publisher(String, T_WATCHDOG_EVENTS, 50)
        self.create_subscription(Twist, T_SCOUT_CMD_STUDENT, self.on_cmd, 10)
        self.create_subscription(Bool, T_SCOUT_ENABLE, self.on_enable, 10)
        self.create_subscription(Odometry, T_SCOUT_ODOM_PRIVATE, self.on_truth, 20)
        if self.drift:
            self.create_subscription(Odometry, T_SCOUT_ODOM_EST, self.on_est, 20)

        self.cmd = None
        self.t_cmd = None
        self.invalid_pending = False  # a non-finite command arrived since the last tick
        self.n_invalid = 0
        self.enabled = True          # the gz controller is active at start without an enable
        self.t_enable_true = None
        self.truth = None            # (x, y, z, yaw)
        self.est_yaw = None
        self.est_xyz = None          # drift mode: odom_est position (the only one events report)
        self.air_start = None
        self.override = None          # None | 'ceiling' | 'forced_descent'
        self.fence_out = False        # True during an excursion outside the geofence
        self.geofence_t0 = None
        self.t_inward = None
        self.prev_fresh = False
        self.last_evt_t = {}
        idle = float(g("ground_idle_rate_hz"))
        self.idle_period = 1.0 / idle if 0.0 < idle < float(g("rate_hz")) else 0.0
        self.idle_ok = False          # set every tick: landed, no fresh nonzero command, no enable
        self.t_last_send = None
        self.sp_xy = [0.0, 0.0]       # slew-limited world-frame horizontal setpoint (m/s)
        self.t_slew = None
        self.psi_c = None             # drift mode: commanded estimated heading (rad), airborne only
        self.t_psi = None
        self.t_est = None             # receive time of the newest odom_est message
        self.yaw_dist = None          # drift mode: current yaw-rate disturbance (rad/s), airborne only
        # drift mode: the disturbance's random source, fresh for every run (never the seed)
        self.rng = random.Random(int.from_bytes(os.urandom(32), "big"))
        self.period = 1.0 / float(g("rate_hz"))
        self.timer = self.create_timer(1.0 / float(g("rate_hz")), self.tick)
        self.get_logger().info("watchdog: condition=%s dynamics=%s odom_mode=%s -> %s"
                               % (self.condition, g("scout_dynamics"), g("odom_mode"), out_topic))

    # -- inputs -------------------------------------------------------------------------------
    def now(self):
        return self.get_clock().now().nanoseconds * 1e-9

    def on_cmd(self, msg):
        if not twist_is_finite(msg):
            # A non-finite command counts as a fresh ZERO command (hover in place), not as a
            # missing one, so it does not also trigger cmd_timeout.
            self.n_invalid += 1
            self.invalid_pending = True
            msg = Twist()
        self.cmd = msg
        self.t_cmd = self.now()

    def on_enable(self, msg):
        """Forward /ingenuity/enable to the TA-only gz enable topic; false only when the scout is
        not airborne (module docstring)."""
        want = bool(msg.data)
        t = self.now()
        if want:
            self.t_enable_true = t
        elif (self.truth is not None and math.isfinite(self.truth[2])
              and self.truth[2] > self.cfg["landed_z_m"]):
            self.event("enable_ignored", t, min_interval=1.0)
            return
        self.enabled = want
        self.pub_enable_gz.publish(Bool(data=want))

    def on_truth(self, msg):
        q = msg.pose.pose.orientation
        p = msg.pose.pose.position
        self.truth = (p.x, p.y, p.z, yaw_from_quat(q.x, q.y, q.z, q.w))

    def on_est(self, msg):
        q = msg.pose.pose.orientation
        p = msg.pose.pose.position
        self.est_yaw = yaw_from_quat(q.x, q.y, q.z, q.w)
        self.est_xyz = (p.x, p.y, p.z)
        self.t_est = self.now()

    # -- helpers ------------------------------------------------------------------------------
    def event(self, name, t, min_interval=0.0):
        last = self.last_evt_t.get(name)
        if min_interval > 0.0 and last is not None and 0.0 <= t - last < min_interval:
            return
        self.last_evt_t[name] = t
        truth_xyz = tuple(self.truth[:3]) if self.truth else None
        payload = event_payload(name, t, truth_xyz, self.est_xyz, self.drift)
        text = json.dumps(payload, sort_keys=True)
        self.pub_evt.publish(String(data=text))
        # the log line goes to /rosout: it repeats the published payload, never more
        self.get_logger().warn("watchdog event: %s" % text)

    def send(self, out):
        """Publish one twist to the controller topic(s); never a non-finite value. A zero twist
        while idle on the ground is repeated only every idle_period seconds (module docstring)."""
        if not twist_is_finite(out):
            self.event("invalid_cmd", self.now(), min_interval=1.0)
            out = Twist()
        t = self.now()
        zero = not any((out.linear.x, out.linear.y, out.linear.z,
                        out.angular.x, out.angular.y, out.angular.z))
        if (self.idle_ok and zero and self.idle_period > 0.0 and self.t_last_send is not None
                and 0.0 <= t - self.t_last_send < self.idle_period - 1e-6):
            return
        self.t_last_send = t
        self.pub_cmd_main.publish(out)
        if self.pub_cmd_kin is not None:
            self.pub_cmd_kin.publish(out)

    def reset_slew(self):
        self.sp_xy = [0.0, 0.0]
        self.t_slew = None

    def slew(self, vx_w, vy_w):
        """Move the world-frame horizontal setpoint toward (vx_w, vy_w) by at most
        accel_xy_max * dt (module docstring). Non-finite targets were already replaced by zero."""
        a = self.cfg["accel_xy_max"]
        t = self.now()
        dt = self.period if self.t_slew is None else min(max(t - self.t_slew, 0.0), 5.0 * self.period)
        self.t_slew = t
        if a <= 0.0 or not (math.isfinite(vx_w) and math.isfinite(vy_w)):
            self.sp_xy = [vx_w, vy_w] if math.isfinite(vx_w) and math.isfinite(vy_w) else [0.0, 0.0]
            return self.sp_xy[0], self.sp_xy[1]
        dvx, dvy = vx_w - self.sp_xy[0], vy_w - self.sp_xy[1]
        dv = math.hypot(dvx, dvy)
        step = a * dt
        if dv > step:
            dvx, dvy = dvx * step / dv, dvy * step / dv
        self.sp_xy = [self.sp_xy[0] + dvx, self.sp_xy[1] + dvy]
        return self.sp_xy[0], self.sp_xy[1]

    def est_heading_hold(self, wz):
        """Drift mode, airborne: yaw-rate command that makes the odom_est yaw follow the commanded
        heading psi_c (module docstring). Elsewhere: wz unchanged and psi_c reset."""
        t = self.now()
        gain = self.cfg["est_heading_gain"]
        airborne = self.truth is not None and self.truth[2] > self.cfg["airborne_z_m"]
        fresh = self.t_est is not None and 0.0 <= t - self.t_est <= 1.0
        if (not self.drift or gain <= 0.0 or not airborne or not fresh or self.est_yaw is None
                or not math.isfinite(self.est_yaw)):
            self.psi_c = self.t_psi = None
            self.yaw_dist = None
            return wz
        if self.psi_c is None:
            self.psi_c = self.est_yaw
            dt = self.period
        else:
            dt = min(max(t - self.t_psi, 0.0), 5.0 * self.period)
            self.psi_c = math.atan2(math.sin(self.psi_c + wz * dt), math.cos(self.psi_c + wz * dt))
        self.t_psi = t
        err = math.atan2(math.sin(self.psi_c - self.est_yaw), math.cos(self.psi_c - self.est_yaw))
        cmax = self.cfg["est_heading_corr_max"]
        corr = max(-cmax, min(cmax, gain * err))
        self.yaw_dist = ou_step(self.yaw_dist, dt, self.cfg["yaw_disturbance_std"],
                                self.cfg["yaw_disturbance_tau_s"], self.rng.gauss)
        return max(-self.cfg["wz_max"], min(self.cfg["wz_max"], wz + corr + self.yaw_dist))

    def publish(self, vx_w, vy_w, vz, wz):
        if self.kinematic and not self.enabled:
            self.reset_slew()
            self.psi_c = self.t_psi = None
            self.send(Twist())
            return
        vx_w, vy_w = self.slew(vx_w, vy_w)
        wz = self.est_heading_hold(wz)
        yaw = self.truth[3] if self.truth else 0.0
        if self.drift and self.est_yaw is not None and math.isfinite(self.est_yaw):
            yaw = self.est_yaw
        if not math.isfinite(yaw):
            yaw = 0.0
        c, s = math.cos(yaw), math.sin(yaw)
        out = Twist()
        out.linear.x = c * vx_w + s * vy_w
        out.linear.y = -s * vx_w + c * vy_w
        out.linear.z = vz
        out.angular.z = wz
        self.send(out)

    # -- main loop ----------------------------------------------------------------------------
    def tick(self):
        t = self.now()
        cfg = self.cfg
        if self.invalid_pending:
            self.invalid_pending = False
            self.event("invalid_cmd", t, min_interval=1.0)
            self.get_logger().warn("watchdog: non-finite /option_c/scout/cmd_vel replaced by a zero "
                                   "twist (%d so far)" % self.n_invalid, throttle_duration_sec=5.0)
        if self.truth is None or not all(math.isfinite(v) for v in self.truth):
            self.idle_ok = False
            self.reset_slew()
            self.send(Twist())
            return
        x, y, z, _ = self.truth
        airborne = z > cfg["airborne_z_m"]
        landed = z < cfg["landed_z_m"]
        if airborne and self.air_start is None:
            self.air_start = t
        if landed:
            self.air_start = None
            if self.override is not None:
                self.get_logger().info("watchdog: override %s ended at touchdown" % self.override)
            self.override = None
        fresh = self.t_cmd is not None and 0.0 <= t - self.t_cmd <= cfg["cmd_timeout_s"]
        nonzero_fresh = fresh and self.cmd is not None and (
            abs(self.cmd.linear.x) + abs(self.cmd.linear.y) + abs(self.cmd.linear.z)
            + abs(self.cmd.angular.z) > 1e-3)
        enable_recent = self.t_enable_true is not None and 0.0 <= t - self.t_enable_true <= 1.0
        self.idle_ok = landed and not nonzero_fresh and not enable_recent

        if self.condition == "orbit_only":
            nonzero = fresh and self.cmd is not None and (
                abs(self.cmd.linear.x) + abs(self.cmd.linear.y) + abs(self.cmd.linear.z)
                + abs(self.cmd.angular.z) > 1e-3)
            enable_attempt = self.t_enable_true is not None and 0.0 <= t - self.t_enable_true <= 1.0
            if nonzero or enable_attempt:
                self.event("takeoff_rejected", t, min_interval=2.0)
            self.send(Twist())
            return

        # Geofence bookkeeping: one 'geofence' event per excursion outside [-f, f]^2. The
        # excursion ends only when the scout is back inside, so landing outside and taking off
        # again does not log new events.
        fence = cfg["geofence_m"]
        outside = abs(x) > fence or abs(y) > fence
        if outside and not self.fence_out:
            self.fence_out = True
            self.geofence_t0 = t
            self.t_inward = None
            if not landed:
                self.event("geofence", t)
        elif not outside and self.fence_out:
            self.fence_out = False
            self.get_logger().info("watchdog: back inside the geofence at t=%.2f" % t)

        # Forced descent and ceiling (truth based)
        if (self.air_start is not None and t - self.air_start >= cfg["max_airborne_s"]
                and self.override != "forced_descent"):
            self.override = "forced_descent"
            self.event("forced_descent", t)
        if z > cfg["ceiling_m"] and self.override is None:
            self.override = "ceiling"
            self.event("ceiling", t)
        if self.override == "ceiling" and z < cfg["ceiling_release_m"]:
            self.override = None
        if self.override in ("forced_descent", "ceiling"):
            self.publish(0.0, 0.0, -cfg["descent_speed"], 0.0)
            return

        # Student command (zero if stale), clamped
        if not fresh:
            if airborne and self.prev_fresh:
                self.event("cmd_timeout", t)
            self.prev_fresh = False
            vx = vy = vz = wz = 0.0
        else:
            self.prev_fresh = True
            vx, vy = float(self.cmd.linear.x), float(self.cmd.linear.y)
            vz, wz = float(self.cmd.linear.z), float(self.cmd.angular.z)
            vx, vy, clamped = clamp_xy(vx, vy, cfg["vxy_max"])
            if abs(vz) > cfg["vz_max"]:
                vz = math.copysign(cfg["vz_max"], vz)
                clamped = True
            if abs(wz) > cfg["wz_max"]:
                wz = math.copysign(cfg["wz_max"], wz)
                clamped = True
            if clamped:
                self.event("speed_clamped", t, min_interval=1.0)

        # Outside the geofence: outward velocity components are removed. An inward command is
        # passed through (no climbing above 3 m), so the scout can fly back in. With no inward
        # command it hovers for geofence_hover_s, then descends at descent_speed.
        if self.fence_out:
            if (x > fence and vx > 0.0) or (x < -fence and vx < 0.0):
                vx = 0.0
            if (y > fence and vy > 0.0) or (y < -fence and vy < 0.0):
                vy = 0.0
            if math.hypot(vx, vy) > 0.05:
                self.t_inward = t
                if z > 3.0:
                    vz = min(vz, 0.0)
                self.publish(vx, vy, vz, wz)
                return
            if landed:
                self.publish(0.0, 0.0, 0.0, 0.0)
                return
            t_ref = self.geofence_t0 if self.t_inward is None else max(self.geofence_t0, self.t_inward)
            if t - t_ref < cfg["geofence_hover_s"]:
                self.publish(0.0, 0.0, 0.0, 0.0)
            else:
                self.publish(0.0, 0.0, -cfg["descent_speed"], 0.0)
            return

        self.publish(vx, vy, vz, wz)


def main(args=None):
    return run_node(ScoutSafetyWatchdog, args)


if __name__ == "__main__":
    main()
