"""teleop_scout: keyboard teleop for the scout (default) or the rover (--rover).

Scout mode publishes WORLD-FRAME ENU velocity on /option_c/scout/cmd_vel at 10 Hz (the watchdog
rotates it into the vehicle frame) and /ingenuity/enable:
    i / k   north / south (+y / -y)        j / l   west / east (-x / +x)
    r / f   climb / descend                 u / o   yaw left / right
    space   zero velocity (hover)           t / g   enable true / enable false (only on the ground)
    + / -   speed step up / down            q       quit (sends a zero command first)
    'g' is refused while the scout is above 0.3 m (altitude from /model/ingenuity_quad_approx/odometry,
    or /ingenuity/odom_est in drift mode); the watchdog ignores enable false in the air as well.
Rover mode (--rover) publishes /option_c/rover/cmd_vel_request at 10 Hz (body frame):
    w / s   forward / backward              a / d   turn left / right
    space   stop                            q       quit
Keys set a velocity that is held until changed. Needs an interactive terminal:
    ros2 run cs498gc_a4_option_c_starter teleop_scout [--rover]
"""
import argparse
import math
import select
import sys
import termios
import tty

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from std_msgs.msg import Bool

from .common import (T_ROVER_CMD_REQUEST, T_SCOUT_CMD_STUDENT, T_SCOUT_ENABLE, T_SCOUT_ODOM_EST,
                     T_SCOUT_ODOM_PUBLIC)

AIRBORNE_Z_M = 0.3   # the watchdog's landed_z_m: above it enable false is ignored


def enable_false_allowed(z):
    """'g' (enable false) is sent only when the scout altitude is unknown or <= 0.3 m."""
    return z is None or not math.isfinite(z) or z <= AIRBORNE_Z_M


def twist_for_key(c, step, rover):
    """Twist for a movement key, or None if c is not a movement key.

    Every field is a float: rclpy (Jazzy) does not type-check Twist fields on assignment, and an
    int in a float64 field aborts the whole process inside the C message converter.
    """
    s = float(step)
    if rover:
        table = {"w": (s, 0.0), "s": (-s, 0.0), "a": (0.0, 0.5), "d": (0.0, -0.5), " ": (0.0, 0.0)}
        if c not in table:
            return None
        t = Twist()
        t.linear.x, t.angular.z = (float(v) for v in table[c])
        return t
    table = {"i": (0.0, s, 0.0, 0.0), "k": (0.0, -s, 0.0, 0.0), "j": (-s, 0.0, 0.0, 0.0),
             "l": (s, 0.0, 0.0, 0.0), "r": (0.0, 0.0, 0.5, 0.0), "f": (0.0, 0.0, -0.5, 0.0),
             "u": (0.0, 0.0, 0.0, 0.3), "o": (0.0, 0.0, 0.0, -0.3), " ": (0.0, 0.0, 0.0, 0.0)}
    if c not in table:
        return None
    t = Twist()
    t.linear.x, t.linear.y, t.linear.z, t.angular.z = (float(v) for v in table[c])
    return t


class Teleop(Node):
    def __init__(self, rover):
        super().__init__("teleop_scout")
        self.rover = rover
        self.pub = self.create_publisher(Twist, T_ROVER_CMD_REQUEST if rover else T_SCOUT_CMD_STUDENT, 10)
        self.pub_en = self.create_publisher(Bool, T_SCOUT_ENABLE, 10)
        self.cmd = Twist()
        self.step = 0.5 if rover else 1.0
        self.z = None          # scout altitude from either odometry topic (None until one arrives)
        if not rover:
            for topic in (T_SCOUT_ODOM_PUBLIC, T_SCOUT_ODOM_EST):   # truth mode / drift mode
                self.create_subscription(Odometry, topic, self.on_odom, 10)
        self.timer = self.create_timer(0.1, lambda: self.pub.publish(self.cmd))

    def on_odom(self, msg):
        self.z = float(msg.pose.pose.position.z)

    def key(self, c):
        t = twist_for_key(c, self.step, self.rover)
        if t is not None:
            self.cmd = t
            return
        if self.rover:
            return
        if c == "t":
            self.pub_en.publish(Bool(data=True))
        elif c == "g":
            if enable_false_allowed(self.z):
                self.pub_en.publish(Bool(data=False))
            else:
                print("'g' ignored: the scout is airborne (z = %.1f m); land first" % self.z, flush=True)
        elif c == "+":
            self.step = min(3.0, self.step + 0.5)
        elif c == "-":
            self.step = max(0.5, self.step - 0.5)


def main(args=None):
    ap = argparse.ArgumentParser(description="keyboard teleop for the Option C scout or rover")
    ap.add_argument("--rover", action="store_true")
    a, ros_args = ap.parse_known_args()
    if not sys.stdin.isatty():
        print("teleop_scout needs an interactive terminal (stdin is not a tty).", file=sys.stderr)
        return 2
    rclpy.init(args=ros_args)
    node = Teleop(a.rover)
    print(__doc__)
    old = termios.tcgetattr(sys.stdin)
    try:
        tty.setcbreak(sys.stdin.fileno())
        while rclpy.ok():
            rclpy.spin_once(node, timeout_sec=0.02)
            if select.select([sys.stdin], [], [], 0.0)[0]:
                c = sys.stdin.read(1)
                if c == "q":
                    break
                node.key(c)
    finally:
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, old)
        node.pub.publish(Twist())
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()
    return 0


if __name__ == "__main__":
    sys.exit(main())
