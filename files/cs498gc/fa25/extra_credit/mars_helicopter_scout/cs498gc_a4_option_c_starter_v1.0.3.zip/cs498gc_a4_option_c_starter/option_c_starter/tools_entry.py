"""Console-script wrappers that run the stdlib tools and the example from the installed share/.

  ros2 run cs498gc_a4_option_c_starter option_c_seed --netid yournetid
  ros2 run cs498gc_a4_option_c_starter gen_option_c_world --seed 7
  ros2 run cs498gc_a4_option_c_starter hello_sortie
  ros2 run cs498gc_a4_option_c_starter check_projection --func mod:fn --module-path DIR --fly
  ros2 run cs498gc_a4_option_c_starter local_check --stage M0 --bag bags/seed7_orbit_scout
  ros2 run cs498gc_a4_option_c_starter record_option_c_bag 7 orbit_scout
  ros2 run cs498gc_a4_option_c_starter record_images_debug my_flight
  ros2 run cs498gc_a4_option_c_starter make_submission ~/option_c
"""
import os
import runpy
import sys

from ament_index_python.packages import get_package_share_directory

from .common import PKG


def _run(rel):
    path = os.path.join(get_package_share_directory(PKG), rel)
    sys.argv[0] = path
    runpy.run_path(path, run_name="__main__")


def option_c_seed():
    _run("tools/option_c_seed.py")


def gen_option_c_world():
    _run("tools/gen_option_c_world.py")


def hello_sortie():
    _run("examples/hello_sortie.py")


def check_projection():
    _run("tools/check_projection.py")


def local_check():
    _run("tools/local_check.py")


def _bash(rel):
    path = os.path.join(get_package_share_directory(PKG), rel)
    os.execvp("bash", ["bash", path] + sys.argv[1:])


def record_option_c_bag():
    _bash("tools/record_option_c_bag.sh")


def record_images_debug():
    _bash("tools/record_images_debug.sh")


def make_submission():
    _bash("tools/make_submission.sh")
