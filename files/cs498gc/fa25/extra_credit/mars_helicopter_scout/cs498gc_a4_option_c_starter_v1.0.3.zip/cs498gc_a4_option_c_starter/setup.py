import os
from glob import glob

from setuptools import setup

package_name = "cs498gc_a4_option_c_starter"


def tree(top):
    """data_files entries for every file under `top` (skipping generated and cache folders)."""
    out = []
    for dirpath, dirnames, filenames in os.walk(top):
        dirnames[:] = sorted(d for d in dirnames if d not in ("generated", "__pycache__"))
        files = sorted(os.path.join(dirpath, f) for f in filenames
                       if not f.endswith(".pyc") and f != ".gitkeep")
        if files:
            out.append((os.path.join("share", package_name, dirpath), files))
    return out


setup(
    name=package_name,
    version="1.0.3",
    packages=["option_c_starter"],
    data_files=[
        ("share/ament_index/resource_index/packages", ["resource/" + package_name]),
        ("share/" + package_name, ["package.xml", "README.md"]),
        ("share/" + package_name + "/launch", glob("launch/*.launch.py")),
        ("share/" + package_name + "/config", glob("config/*.yaml")),
        ("share/" + package_name + "/worlds", glob("worlds/*.sdf")),
        ("share/" + package_name + "/xacro", glob("xacro/*.xacro")),
        ("share/" + package_name + "/examples", glob("examples/*.py")),
        ("share/" + package_name + "/docs", glob("docs/*.md")),
        ("share/" + package_name + "/tools", glob("tools/*.py") + glob("tools/*.sh")),
    # tools/option_c_grading/ (the grader code local_check runs) is installed too, so local_check
    # works with or without --symlink-install
    ] + tree("models") + tree("tools/option_c_grading"),
    install_requires=["setuptools"],
    zip_safe=True,
    maintainer="CS 498 GC course staff",
    maintainer_email="cs498gc-staff@illinois.edu",
    description="CS 498 GC A4 Option C (Mars Helicopter Scout) starter package",
    license="BSD-3-Clause",
    tests_require=["pytest"],
    entry_points={
        "console_scripts": [
            "run_info_publisher = option_c_starter.run_info_publisher:main",
            "scout_safety_watchdog = option_c_starter.scout_safety_watchdog:main",
            "scout_odom_relay = option_c_starter.scout_odom_relay:main",
            "clock_decimator = option_c_starter.clock_decimator:main",
            "rover_hazard_guard = option_c_starter.rover_hazard_guard:main",
            "hazcam_sim = option_c_starter.hazcam_sim:main",
            "odom_degrader = option_c_starter.odom_degrader:main",
            "teleop_scout = option_c_starter.teleop_scout:main",
            "option_c_seed = option_c_starter.tools_entry:option_c_seed",
            "gen_option_c_world = option_c_starter.tools_entry:gen_option_c_world",
            "hello_sortie = option_c_starter.tools_entry:hello_sortie",
            "check_projection = option_c_starter.tools_entry:check_projection",
            "local_check = option_c_starter.tools_entry:local_check",
            "record_option_c_bag = option_c_starter.tools_entry:record_option_c_bag",
            "record_images_debug = option_c_starter.tools_entry:record_images_debug",
            "make_submission = option_c_starter.tools_entry:make_submission",
        ],
    },
)
