"""Bridge configuration and (opt-in) live bridge smoke test.

The static tests always run: every bridge string the spec requires is in config/option_c_bridge.yaml
with the exact ROS type, gz type and direction, and the drift config does not bridge the scout
truth odometry under its public name.

The live test starts the world headless for about 45 s of wall time and checks that the starter
topics appear with the right types. It is skipped unless OPTION_C_LIVE_SMOKE=1 (it needs a sourced
ROS 2 Jazzy + Gazebo Harmonic environment and an installed workspace):
    OPTION_C_LIVE_SMOKE=1 python3 -m pytest -q test/test_bridge_smoke.py
"""
import os
import re
import signal
import subprocess
import time
from pathlib import Path

import pytest

PKG = Path(__file__).resolve().parents[1]

REQUIRED = [
    # (ros topic, gz topic, ros type, gz type, direction)
    ("/clock", "/clock", "rosgraph_msgs/msg/Clock", "gz.msgs.Clock", "GZ_TO_ROS"),
    ("/ingenuity/gazebo/command/twist", "/ingenuity/gazebo/command/twist",
     "geometry_msgs/msg/Twist", "gz.msgs.Twist", "ROS_TO_GZ"),
    # enable: the watchdog forwards the students' /ingenuity/enable here (v1.0.2)
    ("/ingenuity/gazebo/command/enable", "/ingenuity/gazebo/command/enable", "std_msgs/msg/Bool",
     "gz.msgs.Boolean", "ROS_TO_GZ"),
    ("/ingenuity/nadir_cam/image", "/ingenuity/nadir_cam/image", "sensor_msgs/msg/Image",
     "gz.msgs.Image", "GZ_TO_ROS"),
    ("/ingenuity/nadir_cam/camera_info", "/ingenuity/nadir_cam/camera_info",
     "sensor_msgs/msg/CameraInfo", "gz.msgs.CameraInfo", "GZ_TO_ROS"),
    ("/orbiter/bev_cam/image", "/orbiter/bev_cam/image", "sensor_msgs/msg/Image", "gz.msgs.Image",
     "GZ_TO_ROS"),
    ("/orbiter/bev_cam/camera_info", "/orbiter/bev_cam/camera_info", "sensor_msgs/msg/CameraInfo",
     "gz.msgs.CameraInfo", "GZ_TO_ROS"),
    ("/option_c/rover/odom_truth", "/model/rover/odometry", "nav_msgs/msg/Odometry",
     "gz.msgs.Odometry", "GZ_TO_ROS"),
    ("/option_c/rover/cmd_vel", "/model/rover/cmd_vel", "geometry_msgs/msg/Twist", "gz.msgs.Twist",
     "ROS_TO_GZ"),
    ("/option_c/grader/_private/scout_odom_truth", "/model/ingenuity_quad_approx/odometry",
     "nav_msgs/msg/Odometry", "gz.msgs.Odometry", "GZ_TO_ROS"),
]
PUBLIC_SCOUT_ODOM = ("/model/ingenuity_quad_approx/odometry", "/model/ingenuity_quad_approx/odometry",
                     "nav_msgs/msg/Odometry", "gz.msgs.Odometry", "GZ_TO_ROS")


def parse_bridge(path):
    """Minimal parser for the flat list-of-maps bridge YAML (no PyYAML needed)."""
    entries, cur = [], None
    for raw in Path(path).read_text(encoding="utf-8").splitlines():
        line = raw.split("#", 1)[0].rstrip()
        if not line.strip():
            continue
        m = re.match(r'^\s*(-\s+)?(\w+):\s*"?([^"]*)"?\s*$', line)
        if not m:
            continue
        if m.group(1):
            cur = {}
            entries.append(cur)
        cur[m.group(2)] = m.group(3)
    return [(e.get("ros_topic_name"), e.get("gz_topic_name"), e.get("ros_type_name"),
             e.get("gz_type_name"), e.get("direction")) for e in entries]


def test_truth_bridge_has_every_required_mapping():
    got = set(parse_bridge(PKG / "config" / "option_c_bridge.yaml"))
    for r in REQUIRED + [PUBLIC_SCOUT_ODOM]:
        assert r in got, r


def test_drift_bridge_hides_public_scout_odometry():
    got = set(parse_bridge(PKG / "config" / "option_c_bridge_drift.yaml"))
    for r in REQUIRED:
        assert r in got, r
    assert PUBLIC_SCOUT_ODOM not in got
    assert not any(e[0] == "/model/ingenuity_quad_approx/odometry" for e in got)


def test_student_enable_goes_through_the_watchdog():
    """/ingenuity/enable is not bridged (enable false in the air would stop the rotors): the
    watchdog forwards it to the TA-only gz topic the multicopter controller listens to."""
    for name in ("option_c_bridge.yaml", "option_c_bridge_drift.yaml"):
        got = parse_bridge(PKG / "config" / name)
        assert not any(e[0] == "/ingenuity/enable" or e[1] == "/ingenuity/enable" for e in got), name
    sdf = (PKG / "models" / "ingenuity_quad_approx" / "model.sdf").read_text(encoding="utf-8")
    assert "<robotNamespace>ingenuity</robotNamespace>" in sdf
    assert "<enableSubTopic>gazebo/command/enable</enableSubTopic>" in sdf
    common = (PKG / "option_c_starter" / "common.py").read_text(encoding="utf-8")
    assert 'T_SCOUT_ENABLE_GZ = "/ingenuity/gazebo/command/enable"' in common
    kin = (PKG / "models" / "ingenuity_quad_approx_kinematic" / "model.sdf").read_text(encoding="utf-8")
    assert "enableSubTopic" not in kin


def test_private_truth_topic_is_under_grader_namespace():
    for name in ("option_c_bridge.yaml", "option_c_bridge_drift.yaml"):
        text = (PKG / "config" / name).read_text(encoding="utf-8")
        assert "/option_c/_private" not in text
    common = (PKG / "option_c_starter" / "common.py").read_text(encoding="utf-8")
    assert 'T_SCOUT_ODOM_PRIVATE = "/option_c/grader/_private/scout_odom_truth"' in common


@pytest.mark.skipif(os.environ.get("OPTION_C_LIVE_SMOKE") != "1",
                    reason="live smoke test: set OPTION_C_LIVE_SMOKE=1 in a sourced Jazzy workspace")
def test_live_bridge_topics(tmp_path):
    env = dict(os.environ, OPTION_C_WORK_DIR=str(tmp_path))
    proc = subprocess.Popen(["ros2", "launch", "cs498gc_a4_option_c_starter",
                             "option_c_world.launch.py", "seed:=7", "headless:=true"],
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, env=env,
                            start_new_session=True)
    try:
        want = {"/option_c/clock_20hz": "rosgraph_msgs/msg/Clock",
                "/option_c/run_info": "std_msgs/msg/String",
                "/orbiter/bev_cam/camera_info": "sensor_msgs/msg/CameraInfo",
                "/ingenuity/nadir_cam/camera_info": "sensor_msgs/msg/CameraInfo",
                "/model/ingenuity_quad_approx/odometry": "nav_msgs/msg/Odometry",
                "/option_c/rover/odom_truth": "nav_msgs/msg/Odometry",
                "/option_c/rover/hazcam": "geometry_msgs/msg/PoseArray",
                "/option_c/grader/scout_odom": "nav_msgs/msg/Odometry"}
        seen = {}
        deadline = time.time() + 45.0
        while time.time() < deadline and len(seen) < len(want):
            time.sleep(3.0)
            out = subprocess.run(["ros2", "topic", "list", "-t", "--no-daemon"],
                                 capture_output=True, text=True, timeout=30, env=env).stdout
            for line in out.splitlines():
                parts = line.split()
                if len(parts) == 2 and parts[0] in want:
                    seen[parts[0]] = parts[1].strip("[]")
        for topic, typ in want.items():
            assert seen.get(topic) == typ, (topic, seen.get(topic))
    finally:
        os.killpg(proc.pid, signal.SIGINT)
        try:
            proc.wait(timeout=20)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid, signal.SIGKILL)
            proc.wait(timeout=10)
