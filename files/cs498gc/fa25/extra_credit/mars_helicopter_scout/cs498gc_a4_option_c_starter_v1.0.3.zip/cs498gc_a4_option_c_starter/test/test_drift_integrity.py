"""Drift-mode integrity and M0b interface tests.

* in odom_mode:=drift the watchdog's events (topic and /rosout line) never carry the truth scout
  position; they carry the odom_est position, or none before the first estimate
* odom_degrader never logs the drift values, and AG-26 flags the drift model names and the
  watchdog's output topic in student source
* the drift values are fresh for every run (os.urandom, not the seed), random-walk, and the gyro
  is noisy: while the scout holds its true heading in the air, the gyro does not read the bias
* odom_est's twist is consistent with odom_est's pose: integrating its gyro and body velocity
  reproduces the drifting estimate, not the truth; odom_est is 1 Hz on the ground, 20 Hz airborne
* the M0b skeleton has the documented interface and check_projection --help prints it
"""
import ast
import importlib.util
import json
import math
import subprocess
import sys
from pathlib import Path

PKG = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PKG))

TRUTH = (10.0, 20.0, 9.5)
EST = (11.25, 18.5, 9.5)       # odom_est keeps the true altitude, like the TA degrader


def _odom(xyz):
    from nav_msgs.msg import Odometry
    m = Odometry()
    m.pose.pose.position.x, m.pose.pose.position.y, m.pose.pose.position.z = xyz
    m.pose.pose.orientation.w = 1.0
    return m


class _Pub:
    def __init__(self):
        self.msgs = []

    def publish(self, m):
        self.msgs.append(m)


class _Log:
    def __init__(self):
        self.lines = []

    def _add(self, text, **_kw):
        self.lines.append(str(text))

    debug = info = warn = warning = error = fatal = _add


def _watchdog(odom_mode):
    import rclpy
    from option_c_starter.scout_safety_watchdog import ScoutSafetyWatchdog
    rclpy.init(args=["--ros-args", "-p", "odom_mode:=%s" % odom_mode])
    node = ScoutSafetyWatchdog()
    pub, log = _Pub(), _Log()
    node.pub_evt = pub
    node.pub_cmd_main = _Pub()
    node.get_logger = lambda: log
    return rclpy, node, pub, log


def _payloads(pub):
    return [json.loads(m.data) for m in pub.msgs]


def test_event_payload_function():
    from option_c_starter.scout_safety_watchdog import event_payload
    p = event_payload("speed_clamped", 12.3456, TRUTH, EST, True)
    assert (p["x"], p["y"], p["z"]) == EST and p["pose_source"] == "odom_est"
    assert p["t_sim"] == 12.346 and p["event"] == "speed_clamped"
    p = event_payload("cmd_timeout", 1.0, TRUTH, None, True)
    assert p == {"t_sim": 1.0, "event": "cmd_timeout", "pose_source": "none"}
    p = event_payload("geofence", 2.0, TRUTH, EST, False)
    assert (p["x"], p["y"], p["z"]) == TRUTH and p["pose_source"] == "truth"
    p = event_payload("ceiling", 2.0, (float("nan"), 0.0, 0.0), None, False)
    assert p["pose_source"] == "none" and "x" not in p


def test_watchdog_drift_events_never_carry_truth():
    from geometry_msgs.msg import Twist
    rclpy, node, pub, log = _watchdog("drift")
    try:
        assert node.drift
        node.on_truth(_odom(TRUTH))
        # an event before the first estimate: no position at all
        node.event("cmd_timeout", 1.0)
        node.on_est(_odom(EST))
        cmd = Twist()
        cmd.linear.x = 3.05            # just above the 3.0 m/s clamp: speed_clamped, airborne
        node.on_cmd(cmd)
        node.tick()
        node.event("geofence", 3.0)
        ps = _payloads(pub)
        names = [p["event"] for p in ps]
        assert names == ["cmd_timeout", "speed_clamped", "geofence"], names
        assert ps[0]["pose_source"] == "none" and "x" not in ps[0]
        for p in ps[1:]:
            assert p["pose_source"] == "odom_est"
            assert (p["x"], p["y"]) == (EST[0], EST[1])
        # the /rosout line repeats the published text and nothing else
        texts = [m.data for m in pub.msgs]
        event_lines = [ln for ln in log.lines if ln.startswith("watchdog event: ")]
        assert [ln[len("watchdog event: "):] for ln in event_lines] == texts
        for ln in log.lines:
            assert '"x": 10.0' not in ln and '"y": 20.0' not in ln, ln
    finally:
        node.destroy_node()
        rclpy.shutdown()


def test_watchdog_truth_mode_events_carry_truth():
    rclpy, node, pub, _log = _watchdog("truth")
    try:
        assert not node.drift
        node.on_truth(_odom(TRUTH))
        node.event("ceiling", 4.0)
        p = _payloads(pub)[0]
        assert (p["x"], p["y"], p["z"]) == TRUTH and p["pose_source"] == "truth"
    finally:
        node.destroy_node()
        rclpy.shutdown()


def test_odom_degrader_logs_no_drift_values():
    tree = ast.parse((PKG / "option_c_starter" / "odom_degrader.py").read_text())
    log_calls = 0
    for call in ast.walk(tree):
        if (isinstance(call, ast.Call) and isinstance(call.func, ast.Attribute)
                and call.func.attr in ("debug", "info", "warn", "warning", "error", "fatal")):
            log_calls += 1
            nodes = [n for a in list(call.args) + [k.value for k in call.keywords] for n in ast.walk(a)]
            assert not {n.id for n in nodes if isinstance(n, ast.Name)} & {"d", "seed"}
            assert not {n.attr for n in nodes if isinstance(n, ast.Attribute)} & {"bias", "scale", "mult"}
        if isinstance(call, ast.Call) and isinstance(call.func, ast.Attribute) \
                and call.func.attr == "declare_parameter":
            assert call.args[0].value in ("seed", "ground_truth_file")
    assert log_calls >= 1


def test_ag26_flags_drift_model_names(tmp_path):
    import yaml
    sys.path.insert(0, str(PKG / "tools"))
    from option_c_grading.submission import scan_source
    spec = yaml.safe_load((PKG / "tools" / "option_c_grading" / "spec_option_c_v1.yaml").read_text())
    t = next(x for x in spec["auto_tests"] if x["id"] == "AG-26")
    for name in ("drift_parameters", "odom_degrader", "gazebo/command"):
        assert name in t["source_patterns"], name
    pkg = tmp_path / "option_c_scout" / "option_c_scout"
    pkg.mkdir(parents=True)
    (pkg / "reg.py").write_text("from option_c_starter.common import drift_parameters\n")
    (pkg / "yaw.py").write_text("TOPIC = '/ingenuity/gazebo/command/twist'\n")
    (pkg / "clean.py").write_text("print('odom_est only')\n")
    hits = scan_source(tmp_path / "option_c_scout", list(t["source_patterns"]), list(t["source_regex"]))
    assert {h[2] for h in hits} == {"drift_parameters", "gazebo/command"}
    assert {Path(h[0]).name for h in hits} == {"reg.py", "yaw.py"}


def test_ag26_flags_gazebo_transport_and_student_bridges(tmp_path):
    """v1.0.2: a student bridge of the gz truth odometry (launch file or ros2 run), gz transport in
    Python and the gz command-line tools are flagged; a clean package is not."""
    import yaml
    sys.path.insert(0, str(PKG / "tools"))
    from option_c_grading.submission import scan_source
    spec = yaml.safe_load((PKG / "tools" / "option_c_grading" / "spec_option_c_v1.yaml").read_text())
    t = next(x for x in spec["auto_tests"] if x["id"] == "AG-26")
    for name in ("ros_gz_bridge", "parameter_bridge", "gz.transport", "gz_transport", "gz.msgs",
                 "gz topic", "gz service", "gz model", "GZ_PARTITION"):
        assert name in t["source_patterns"], name
    cheat = tmp_path / "cheat" / "option_c_scout"
    (cheat / "launch").mkdir(parents=True)
    (cheat / "option_c_scout").mkdir()
    (cheat / "launch" / "mission.launch.py").write_text(
        "Node(package='ros_gz_bridge', executable='parameter_bridge',\n"
        "     arguments=['/model/ingenuity_quad_approx/odometry@nav_msgs/msg/Odometry[gz.msgs.Odometry'])\n")
    (cheat / "option_c_scout" / "reg.py").write_text("from gz.transport13 import Node\n")
    (cheat / "option_c_scout" / "cli.py").write_text("subprocess.run(['gz', 'topic', '-e', '-t', T])\n")
    (cheat / "run.sh").write_text("export GZ_PARTITION=mine\ngz model -m ingenuity_quad_approx -p\n")
    hits = scan_source(cheat, list(t["source_patterns"]), list(t["source_regex"]))
    assert {Path(h[0]).name for h in hits} == {"mission.launch.py", "reg.py", "cli.py", "run.sh"}
    clean = tmp_path / "clean" / "option_c_scout"
    (clean / "launch").mkdir(parents=True)
    (clean / "launch" / "mission.launch.py").write_text(
        "IncludeLaunchDescription(... 'cs498gc_a4_option_c_starter', 'option_c_world.launch.py' ...)\n"
        "Node(package='option_c_scout', executable='registration_node')\n")
    (clean / "reg.py").write_text("ODOM = '/ingenuity/odom_est'\nSTATUS = '/ingenuity/nav_status'\n")
    assert scan_source(clean, list(t["source_patterns"]), list(t["source_regex"])) == []


def test_m0b_stub_interface():
    spec = importlib.util.spec_from_file_location("stub", str(PKG / "examples" / "pixel_to_ground_stub.py"))
    stub = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(stub)
    R = stub.rotation_matrix(0.0, 0.0, 0.0, 1.0)
    assert R == ((1.0, 0.0, 0.0), (0.0, 1.0, 0.0), (0.0, 0.0, 1.0))
    K = [233.87, 0.0, 160.0, 0.0, 233.87, 120.0, 0.0, 0.0, 1.0]
    pose = {"x": 0.0, "y": 0.0, "z": 12.0, "qx": 0.0, "qy": 0.0, "qz": 0.0, "qw": 1.0}
    try:
        stub.pixel_to_ground(160.0, 120.0, K, pose)
        raise AssertionError("the stub must ask the student to write the projection")
    except NotImplementedError:
        pass


def test_check_projection_help_documents_interface():
    out = subprocess.run([sys.executable, str(PKG / "tools" / "check_projection.py"), "--help"],
                         capture_output=True, text=True, timeout=60)
    assert out.returncode == 0, out.stderr
    for s in ("CameraInfo.k", "qx, qy, qz, qw", "--module-path is the FOLDER", "pixel_to_ground_stub.py"):
        assert s in out.stdout, s


# ---------------------------------------------------------------------------------- odom_est twist
SAND = [(15.0, -5.0), (25.0, -5.0), (25.0, 5.0), (15.0, 5.0)]


def _qmul(a, b):
    ax, ay, az, aw = a
    bx, by, bz, bw = b
    return (aw * bx + ax * bw + ay * bz - az * by, aw * by - ax * bz + ay * bw + az * bx,
            aw * bz + ax * by - ay * bx + az * bw, aw * bw - ax * bx - ay * by - az * bz)


def _qexp(w, dt):
    n = math.sqrt(sum(c * c for c in w))
    if n * dt < 1e-12:
        return (0.0, 0.0, 0.0, 1.0)
    s = math.sin(n * dt / 2.0) / n
    return (w[0] * s, w[1] * s, w[2] * s, math.cos(n * dt / 2.0))


def _yaw(q):
    x, y, z, w = q
    return math.atan2(2.0 * (w * z + x * y), 1.0 - 2.0 * (y * y + z * z))


def _wrap(a):
    return math.atan2(math.sin(a), math.cos(a))


def _truth_stream(dt=0.05):
    """3 s landed, then 70 s at 10 m on a circle (2 m/s, 0.06 rad/s) with a constant 6 deg
    body pitch; the circle crosses the SAND square. Yields (t, pos, quat, v_body, w_body)."""
    from option_c_starter.odom_degrader import quat_conjugate, quat_rotate
    pitch = math.radians(6.0)
    qp = (0.0, math.sin(pitch / 2.0), 0.0, math.cos(pitch / 2.0))
    wz, v = 0.06, 2.0
    r = v / wz
    n_ground, n_air = int(3.0 / dt), int(70.0 / dt)
    for i in range(n_ground + n_air):
        t = i * dt
        if i < n_ground:
            yield t, (0.0, 0.0, 0.08), (0.0, 0.0, 0.0, 1.0), (0.0, 0.0, 0.0), (0.0, 0.0, 0.0)
            continue
        yaw = wz * (t - n_ground * dt)
        pos = (r * math.sin(yaw), r * (1.0 - math.cos(yaw)), 10.0)
        q = _qmul((0.0, 0.0, math.sin(yaw / 2.0), math.cos(yaw / 2.0)), qp)
        qc = quat_conjugate(q)
        vw = (v * math.cos(yaw), v * math.sin(yaw), 0.0)
        yield t, pos, q, quat_rotate(qc, vw), quat_rotate(qc, (0.0, 0.0, wz))


def test_odom_est_twist_reproduces_the_estimate_not_the_truth():
    """Dead reckoning with odom_est's own twist (gyro + body velocity) must follow odom_est's
    drifting pose, not the truth: the gyro carries the yaw-rate bias and the gyro noise, the
    velocity the scale error. (A gyro with the true rates would recover the true yaw and most of
    the position.) Fixed bias and scale (no random walk) so the thresholds are not left to chance;
    the gyro noise stays on."""
    import random
    from option_c_starter.odom_degrader import DriftState, quat_rotate
    st = DriftState(SAND, rng=random.Random(3), bias_rad_s=math.radians(0.2), scale=0.03,
                    bias_walk_deg_s=0.0, scale_walk=0.0)
    q_int = p_int = prev = last = None
    worst_yaw_vs_est = worst_pos_vs_est = 0.0
    entered_sand = False
    for t, pos, q, vb, wb in _truth_stream():
        ep, eq, ev, ew = st.step(t, pos, q, vb, wb)
        entered_sand = entered_sand or st.over_sand
        if pos[2] < 1.0:
            continue                   # the synthetic stream jumps to 10 m: start at liftoff
        if q_int is None:
            q_int, p_int = eq, [ep[0], ep[1]]
        else:
            dt = t - prev[0]
            q_int = _qmul(q_int, _qexp(prev[2], dt))
            vw = quat_rotate(q_int, prev[1])
            p_int[0] += vw[0] * dt
            p_int[1] += vw[1] * dt
            worst_yaw_vs_est = max(worst_yaw_vs_est, abs(_wrap(_yaw(q_int) - _yaw(eq))))
            worst_pos_vs_est = max(worst_pos_vs_est, math.hypot(p_int[0] - ep[0], p_int[1] - ep[1]))
        prev = (t, ev, ew)
        last = (pos, q, ep, eq)
    pos, q, ep, eq = last
    assert entered_sand
    yaw_drift = abs(_wrap(_yaw(eq) - _yaw(q)))
    pos_drift = math.hypot(ep[0] - pos[0], ep[1] - pos[1])
    assert yaw_drift > math.radians(10.0), math.degrees(yaw_drift)   # the estimate drifted
    assert pos_drift > 5.0, pos_drift
    # integrating the twist follows the estimate (0.04 deg, 0.1 m here), not the truth
    assert worst_yaw_vs_est < math.radians(0.3), math.degrees(worst_yaw_vs_est)
    assert worst_pos_vs_est < 0.15 * pos_drift, (worst_pos_vs_est, pos_drift)
    assert abs(_wrap(_yaw(q_int) - _yaw(q))) > math.radians(10.0)
    assert math.hypot(p_int[0] - pos[0], p_int[1] - pos[1]) > 0.5 * pos_drift


def test_odom_est_gyro_has_no_bias_on_the_ground():
    from option_c_starter.odom_degrader import DriftState
    st = DriftState(SAND)
    for k in range(80):                        # landed 2 s, then climbing below 0.5 m 2 s
        z = 0.08 if k < 40 else 0.45
        _p, _q, _v, w = st.step(0.05 * k, (0.0, 0.0, z), (0.0, 0.0, 0.0, 1.0),
                                (0.0, 0.0, 0.0), (0.0, 0.0, 0.0))
        assert w == (0.0, 0.0, 0.0)
    assert st.yaw_err == 0.0


def test_drift_values_fresh_for_every_run():
    """The drift values come from os.urandom, not from the seed: two runs differ, both signs of the
    bias occur, and the values stay inside the documented ranges."""
    import inspect
    from option_c_starter.common import drift_parameters
    from option_c_starter.odom_degrader import DriftState
    assert "seed" not in inspect.signature(drift_parameters).parameters
    draws = [drift_parameters() for _ in range(200)]
    assert len({d["yaw_rate_bias_deg_s"] for d in draws}) == 200
    assert {d["yaw_rate_bias_deg_s"] > 0 for d in draws} == {True, False}
    assert all(0.02 <= abs(d["yaw_rate_bias_deg_s"]) <= 0.05 for d in draws)
    assert all(-0.03 <= d["velocity_scale_error"] <= 0.03 for d in draws)
    a, b = DriftState(SAND), DriftState(SAND)
    assert (a.bias, a.scale) != (b.bias, b.scale)


def test_drift_values_random_walk_inside_the_ranges():
    import random
    from option_c_starter.odom_degrader import DriftState
    st = DriftState(SAND, rng=random.Random(11))
    bs, ss = [], []
    for k in range(1200):                      # 60 s hovering at 10 m
        st.step(0.05 * k, (0.0, 0.0, 10.0), (0.0, 0.0, 0.0, 1.0), (0.0, 0.0, 0.0), (0.0, 0.0, 0.0))
        bs.append(abs(math.degrees(st.bias)))
        ss.append(st.scale)
    assert all(0.02 - 1e-12 <= b <= 0.05 + 1e-12 for b in bs)
    assert all(-0.03 - 1e-12 <= s <= 0.03 + 1e-12 for s in ss)
    assert max(bs) - min(bs) > 0.01, (min(bs), max(bs))       # a third of the range or more
    assert max(ss) - min(ss) > 0.01, (min(ss), max(ss))


def test_hover_gyro_does_not_reveal_the_bias():
    """The scout often holds its TRUE heading exactly for seconds in the air. The published
    gyro z must then not sit on k b (it used to, and the mode of the airborne gyro gave b exactly):
    every reading differs, the noise is much larger than the bias, and the mean of a 4 s window
    misses the bias by more than the bias itself in most windows."""
    import random
    from option_c_starter.odom_degrader import DriftState
    misses = 0
    for trial in range(20):
        st = DriftState(SAND, rng=random.Random(100 + trial))
        g, bs = [], []
        for k in range(80):                    # 4 s at 10 m, true rates exactly 0
            _p, _q, _v, w = st.step(0.05 * k, (0.0, 0.0, 10.0), (0.0, 0.0, 0.0, 1.0),
                                    (0.0, 0.0, 0.0), (0.0, 0.0, 0.0))
            if k:
                g.append(w[2])
                bs.append(st.bias)
        assert len({round(v, 12) for v in g}) == len(g)     # no constant value to read off
        assert all(abs(v - b) > 1e-9 for v, b in zip(g, bs))
        mean = sum(g) / len(g)
        sd = math.sqrt(sum((v - mean) ** 2 for v in g) / len(g))
        assert sd > 5.0 * abs(st.bias), (sd, st.bias)
        if abs(mean - st.bias) > 0.5 * abs(st.bias):
            misses += 1
    assert misses >= 10, misses


def test_odom_est_rate_1hz_on_the_ground_20hz_airborne(tmp_path):
    import rclpy
    from nav_msgs.msg import Odometry
    from option_c_starter.odom_degrader import OdomDegrader
    gt = tmp_path / "gt.json"
    gt.write_text(json.dumps({"sand_patch": {"polygon": [list(p) for p in SAND]}}))
    rclpy.init(args=["--ros-args", "-p", "ground_truth_file:=%s" % gt, "-p", "seed:=7"])
    node = OdomDegrader()
    pub = _Pub()
    node.pub_est = pub
    try:
        def feed(k, z):
            m = Odometry()
            ns = k * 50_000_000
            m.header.stamp.sec, m.header.stamp.nanosec = ns // 1_000_000_000, ns % 1_000_000_000
            m.pose.pose.position.z = z
            m.pose.pose.orientation.w = 1.0
            node.on_truth(m)
        for k in range(60):            # 3 s on the ground at 20 Hz
            feed(k, 0.08)
        n_ground = len(pub.msgs)
        for k in range(60, 80):        # 1 s airborne
            feed(k, 2.0)
        n_air = len(pub.msgs) - n_ground
        assert n_ground == 3, n_ground
        assert n_air == 20, n_air
    finally:
        node.destroy_node()
        rclpy.shutdown()
