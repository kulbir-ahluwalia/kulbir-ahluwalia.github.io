"""Unit test: run_node (common.py) exits with 0 when a stop signal surfaces inside rclpy
as a RuntimeError (pybind11 turns a KeyboardInterrupt raised during a C++ call into
'Unable to convert call argument ...'), and still raises real errors when no signal came."""
import signal
import sys
from pathlib import Path

import pytest

PKG = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PKG))


def _factory(raise_signal):
    from rclpy.node import Node

    class _N(Node):
        def __init__(self):
            super().__init__("t_run_node_shutdown")
            self.create_timer(0.01, self.cb)

        def cb(self):
            if raise_signal:
                try:
                    signal.raise_signal(signal.SIGINT)   # run_node's handler records it
                except KeyboardInterrupt:
                    pass
            raise RuntimeError("Unable to convert call argument '0' to Python object")
    return _N


def _with_saved_handlers(fn):
    old = (signal.getsignal(signal.SIGINT), signal.getsignal(signal.SIGTERM))
    try:
        return fn()
    finally:
        signal.signal(signal.SIGINT, old[0])
        signal.signal(signal.SIGTERM, old[1])


def test_signal_inside_rclpy_is_a_clean_exit():
    from option_c_starter.common import run_node
    assert _with_saved_handlers(lambda: run_node(_factory(True), args=[])) == 0


def test_error_without_signal_still_raises():
    from option_c_starter.common import run_node
    with pytest.raises(RuntimeError):
        _with_saved_handlers(lambda: run_node(_factory(False), args=[]))
