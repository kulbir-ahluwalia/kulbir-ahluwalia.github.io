"""Unit tests for small starter pieces that crashed or were wrong in earlier versions.

* teleop_scout key table: every Twist field is a float (an int aborted rclpy in C)
* option_c_seed: the seed formula of the spec
* local_check: the stdlib CDR decoder on hand-built payloads
* src hash: local_check and option_c_starter.common agree (AG-06)
* twist_is_finite (watchdog and guard reject NaN/inf commands)
* local_check AG-05 airborne rates over several sorties (ground time excluded)
* local_check config parser: flow and block seed lists, with and without PyYAML
* recorder_ready_watch (v1.0.3): the READY decision, and the pipe copy that ignores Ctrl-C
"""
import hashlib
import importlib.util
import os
import signal
import struct
import subprocess
import sys
import time
from pathlib import Path

PKG = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PKG))


def _load(rel, name):
    spec = importlib.util.spec_from_file_location(name, str(PKG / rel))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def test_teleop_keys_are_floats():
    from option_c_starter.teleop_scout import twist_for_key
    for rover, keys in ((False, "ikjlrfuo "), (True, "wsad ")):
        for step in (0.5, 1, 3):
            for c in keys:
                t = twist_for_key(c, step, rover)
                for v in (t.linear.x, t.linear.y, t.linear.z, t.angular.z):
                    assert type(v) is float
    assert twist_for_key("x", 1.0, False) is None


def test_teleop_twist_serializes():
    from rclpy.serialization import serialize_message
    from option_c_starter.teleop_scout import twist_for_key
    for c in "ikjlrfuo ":
        serialize_message(twist_for_key(c, 1, False))   # an int field used to abort the process


def test_seed_formula():
    seed = _load("tools/option_c_seed.py", "option_c_seed")
    want = [int(hashlib.sha256(("cs498gc-a4c:abc123:%d" % k).encode()).hexdigest()[:8], 16)
            for k in range(3)]
    assert seed.seeds_for(" ABC123 ") == want


def _cdr_string(s):
    b = s.encode() + b"\x00"
    return struct.pack("<I", len(b)) + b


def test_cdr_string_and_clock():
    lc = _load("tools/local_check.py", "local_check")
    payload = b"\x00\x01\x00\x00" + _cdr_string('{"event": "x", "t_sim": 1.0}')
    assert lc.dec_string(payload) == '{"event": "x", "t_sim": 1.0}'
    clock = b"\x00\x01\x00\x00" + struct.pack("<iI", 12, 500000000)
    assert abs(lc.dec_clock(clock) - 12.5) < 1e-9


def test_cdr_odometry_matches_rclpy():
    from nav_msgs.msg import Odometry
    from rclpy.serialization import serialize_message
    lc = _load("tools/local_check.py", "local_check")
    m = Odometry()
    m.header.stamp.sec, m.header.stamp.nanosec = 41, 250000000
    m.header.frame_id = "map"
    m.child_frame_id = "rover/base_link_x"
    m.pose.pose.position.x, m.pose.pose.position.y, m.pose.pose.position.z = 1.5, -2.25, 9.75
    m.pose.pose.orientation.w = 1.0
    m.twist.twist.linear.x = 0.3
    o = lc.dec_odom(serialize_message(m))
    assert abs(o["t"] - 41.25) < 1e-9 and o["frame"] == "map"
    assert o["child"] == "rover/base_link_x"
    assert o["pos"] == (1.5, -2.25, 9.75) and o["q"][3] == 1.0 and o["v"][0] == 0.3


def test_cdr_camerainfo_and_posearray_match_rclpy():
    from geometry_msgs.msg import Pose, PoseArray
    from rclpy.serialization import serialize_message
    from sensor_msgs.msg import CameraInfo
    lc = _load("tools/local_check.py", "local_check")
    ci = CameraInfo()
    ci.header.stamp.sec = 3
    ci.header.frame_id = "ingenuity_quad_approx/base_link/nadir_cam"
    ci.width, ci.height = 320, 240
    ci.distortion_model = "plumb_bob"
    ci.d = [0.0] * 5
    ci.k = [233.87, 0.0, 160.0, 0.0, 233.87, 120.0, 0.0, 0.0, 1.0]
    d = lc.dec_caminfo(serialize_message(ci))
    assert d["w"] == 320 and d["h"] == 240 and abs(d["k"][0] - 233.87) < 1e-9 and d["t"] == 3.0
    pa = PoseArray()
    pa.header.frame_id = "map"
    pa.poses = [Pose(), Pose(), Pose()]
    assert lc.dec_posearray_count(serialize_message(pa))[2] == 3


def test_src_hash_definitions_agree(tmp_path):
    from option_c_starter.common import src_tree_sha256
    lc = _load("tools/local_check.py", "local_check")
    (tmp_path / "pkg" / "sub").mkdir(parents=True)
    (tmp_path / "pkg" / "a.py").write_text("print(1)\n")
    (tmp_path / "pkg" / "sub" / "b.txt").write_text("x")
    (tmp_path / "pkg" / "__pycache__").mkdir()
    (tmp_path / "pkg" / "__pycache__" / "a.cpython-312.pyc").write_bytes(b"\x00")
    (tmp_path / "pkg" / "build").mkdir()
    (tmp_path / "pkg" / "build" / "junk").write_text("y")
    assert src_tree_sha256(tmp_path / "pkg") == lc.src_tree_sha256(tmp_path / "pkg")
    assert src_tree_sha256(tmp_path / "pkg")[1] == 2


def test_twist_is_finite():
    from geometry_msgs.msg import Twist
    from option_c_starter.common import twist_is_finite
    t = Twist()
    assert twist_is_finite(t)
    for field in ("x", "y", "z"):
        for part in ("linear", "angular"):
            for bad in (float("nan"), float("inf"), -float("inf")):
                t = Twist()
                setattr(getattr(t, part), field, bad)
                assert not twist_is_finite(t), (part, field, bad)


def test_ag05_rates_exclude_ground_time():
    lc = _load("tools/local_check.py", "local_check")
    # two sorties at 19.23 Hz with a 67 s ground gap
    iv = [(34.7, 144.9), (212.4, 257.7)]
    st = [34.7 + k * 0.052 for k in range(int(110.2 / 0.052))]
    st += [212.4 + k * 0.052 for k in range(int(45.3 / 0.052))]
    st += [150.0 + k for k in range(60)]                     # 1 Hz on the ground
    pooled, per = lc.interval_rates(iv, st)
    assert 19.0 < pooled < 19.5
    assert len(per) == 2 and all(19.0 < hz < 19.5 for _iv, hz in per)
    assert lc.rate_hz(lc.stamps_in(iv, st)) < 15.0           # the old single-span rate
    # a short hop below 5 s is pooled but not checked alone
    pooled2, per2 = lc.interval_rates([(0.0, 3.0)], [0.0, 1.0, 2.0, 3.0])
    assert per2 == [] and abs(pooled2 - 1.0) < 1e-9


def test_config_parser_flow_and_block(tmp_path, monkeypatch):
    lc = _load("tools/local_check.py", "local_check")
    flow = tmp_path / "flow.yaml"
    flow.write_text("netid: ABC123\nseeds: [1, 2, 3]\n")
    block = tmp_path / "block.yaml"
    block.write_text("netid: abc123\nseeds:\n  - 1\n  - 2   # c\n  - 3\nrover: starter\n")
    assert lc.config_netid_seeds(flow) == ("abc123", [1, 2, 3])
    assert lc.config_netid_seeds(block) == ("abc123", [1, 2, 3])
    monkeypatch.setitem(sys.modules, "yaml", None)            # stdlib fallback parser
    assert lc.config_netid_seeds(flow) == ("abc123", [1, 2, 3])
    assert lc.config_netid_seeds(block) == ("abc123", [1, 2, 3])
    assert lc.parse_config(block)["rover"] == "starter"


def _sub(t):
    return "[INFO] [1.0] [rosbag2_recorder]: Subscribed to topic '%s'\n" % t


def test_ready_watch_decision():
    rw = _load("tools/recorder_ready_watch.py", "recorder_ready_watch")
    world = ["/option_c/run_info", "/option_c/clock_20hz"]
    ta = world + ["/option_c/rover/hazcam"]
    topics = ta + ["/option_c/mission_phase", "/option_c/rover/active_path"]
    st = rw.ReadyState(topics, ta, 0.0)
    for t in world:
        st.observe(_sub(t), 0.5)
    ex = set(ta)
    # hazcam published but not subscribed yet: never READY
    assert st.evaluate(1.0, ex) is None and st.evaluate(9.0, ex) is None
    st.observe(_sub("/option_c/rover/hazcam"), 9.5)
    assert st.evaluate(10.0, ex) is None            # the picture changed less than SETTLE_S ago
    assert st.evaluate(11.5, ex) is None
    r = st.evaluate(12.1, ex)
    assert r and r["how"] == "graph" and r["n_sub"] == 3 and r["early_student"] == [] and r["ta_absent"] == []
    assert st.evaluate(20.0, ex) is None            # READY is printed once
    # mission already running: its topics are published and subscribed -> READY with the early-start warning
    st = rw.ReadyState(topics, ta, 0.0)
    for t in topics:
        st.observe(_sub(t), 0.2)
    assert st.evaluate(4.5, set(topics)) is None    # first view of the graph: settle first
    r = st.evaluate(6.6, set(topics))
    assert r and r["early_student"] == ["/option_c/mission_phase", "/option_c/rover/active_path"]
    # world not running: run_info never subscribed -> never READY, status says why
    st = rw.ReadyState(topics, ta, 0.0)
    assert st.evaluate(60.0, set()) is None
    assert "world topics" in st.status(60.0, set())
    # a TA topic without any publisher holds READY back for TA_GRACE_S, then READY with a warning
    st = rw.ReadyState(topics, ta, 0.0)
    for t in world:
        st.observe(_sub(t), 0.2)
    assert st.evaluate(5.0, set(world)) is None
    assert st.evaluate(rw.TA_GRACE_S - 0.5, set(world)) is None
    r = st.evaluate(rw.TA_GRACE_S + 0.1, set(world))
    assert r and r["ta_absent"] == ["/option_c/rover/hazcam"]
    # rosbag2's own "All requested topics are subscribed" line is READY at once
    st = rw.ReadyState(topics, ta, 0.0)
    st.observe("[INFO] [1.0] [rosbag2_recorder]: All requested topics are subscribed. Stopping discovery...\n", 0.3)
    assert st.evaluate(0.3, None)["how"] == "all"
    # without a graph view: world topics, NO_GRAPH_MIN_S and NO_GRAPH_QUIET_S without a new subscription
    st = rw.ReadyState(topics, ta, 0.0)
    for t in world:
        st.observe(_sub(t), 1.0)
    assert st.evaluate(rw.NO_GRAPH_MIN_S - 0.1, None) is None
    assert st.evaluate(rw.NO_GRAPH_MIN_S + 0.1, None)["how"] == "no_graph"


def test_ready_watch_copies_every_line_and_ignores_sigint():
    """The recorder must never see a broken pipe: Ctrl-C reaches the whole process group, the watcher ignores it
    and keeps copying until the recorder closes the pipe."""
    env = dict(os.environ, OPTION_C_READY_NO_GRAPH="1", PYTHONUNBUFFERED="1")
    p = subprocess.Popen([sys.executable, str(PKG / "tools" / "recorder_ready_watch.py"), "--tag", "t",
                          "--topics", "/option_c/run_info,/option_c/clock_20hz", "--ta", "/option_c/run_info"],
                         stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env)
    try:
        p.stdin.write(b"first line\n")
        p.stdin.write(_sub("/option_c/run_info").encode())
        p.stdin.flush()
        time.sleep(1.0)
        p.send_signal(signal.SIGINT)
        time.sleep(0.5)
        assert p.poll() is None, "the watcher exited on SIGINT"
        out, err = p.communicate(input=b"after ctrl-c\nlast line without newline", timeout=20)
    finally:
        if p.poll() is None:
            p.kill()
    text = out.decode()
    assert p.returncode == 0, err.decode()
    for s in ("first line\n", "after ctrl-c\n", "last line without newline\n"):
        assert s in text
