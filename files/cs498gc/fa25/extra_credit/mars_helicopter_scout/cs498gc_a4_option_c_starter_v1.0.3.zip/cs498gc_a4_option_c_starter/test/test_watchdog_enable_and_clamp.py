"""Watchdog unit tests (v1.0.2): /ingenuity/enable goes through the watchdog, which forwards it to the
TA-only gz enable topic and ignores false while the scout is airborne (event enable_ignored); in
kinematic mode a forwarded false gives zero twists; huge finite horizontal commands are clamped to
3 m/s with their direction kept (the old v x 3 / |v| overflowed to inf and the scout hovered).
"""
import json
import math
import sys
from pathlib import Path

PKG = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PKG))


class _Pub:
    def __init__(self):
        self.msgs = []

    def publish(self, m):
        self.msgs.append(m)


def _odom(z, x=1.0, y=2.0):
    from nav_msgs.msg import Odometry
    m = Odometry()
    m.pose.pose.position.x, m.pose.pose.position.y, m.pose.pose.position.z = x, y, z
    m.pose.pose.orientation.w = 1.0
    return m


def _events(pub):
    return [json.loads(m.data)["event"] for m in pub.msgs]


def test_clamp_xy_is_overflow_safe():
    from option_c_starter.common import clamp_xy
    assert clamp_xy(1.0, 1.0, 3.0) == (1.0, 1.0, False)
    assert clamp_xy(3.0, 0.0, 3.0) == (3.0, 0.0, False)
    assert clamp_xy(0.0, 0.0, 3.0) == (0.0, 0.0, False)
    vx, vy, c = clamp_xy(1e308, 0.0, 3.0)
    assert c and (vx, vy) == (3.0, 0.0)
    vx, vy, c = clamp_xy(1e308, 1e308, 3.0)       # hypot overflows to inf here
    assert c and abs(vx - 3.0 / math.sqrt(2.0)) < 1e-12 and abs(vy - vx) < 1e-12
    vx, vy, c = clamp_xy(-1.7e308, 5.0, 3.0)
    assert c and abs(vx + 3.0) < 1e-12 and abs(vy) < 1e-12
    vx, vy, c = clamp_xy(-6.0, 8.0, 3.0)          # ordinary case unchanged in behavior
    assert c and abs(vx + 1.8) < 1e-12 and abs(vy - 2.4) < 1e-12
    for big in (1e307, 6e307, 1e308, 1.7976931348623157e308):
        vx, vy, c = clamp_xy(big, -big / 3.0, 3.0)
        assert c and math.isfinite(vx) and math.isfinite(vy)
        assert abs(math.hypot(vx, vy) - 3.0) < 1e-9 and vx > 0.0 > vy


def test_huge_finite_command_flies_at_the_speed_cap():
    import rclpy
    from geometry_msgs.msg import Twist
    from option_c_starter.scout_safety_watchdog import ScoutSafetyWatchdog
    rclpy.init(args=["--ros-args", "-p", "accel_xy_max:=0.0"])   # no ramp: check the clamp itself
    node = ScoutSafetyWatchdog()
    try:
        clock = [0.0]
        node.now = lambda: clock[0]
        pub, evt = _Pub(), _Pub()
        node.pub_cmd_main, node.pub_evt = pub, evt
        node.on_truth(_odom(5.0))                  # airborne, yaw 0
        c = Twist()
        c.linear.x = 1e308
        node.on_cmd(c)
        node.tick()
        assert (pub.msgs[-1].linear.x, pub.msgs[-1].linear.y) == (3.0, 0.0)
        assert "speed_clamped" in _events(evt) and "invalid_cmd" not in _events(evt)
        clock[0] = 0.05
        c = Twist()
        c.linear.x, c.linear.y = 1e308, -1e308
        node.on_cmd(c)
        node.tick()
        o = pub.msgs[-1]
        assert abs(o.linear.x - 3.0 / math.sqrt(2.0)) < 1e-9 and abs(o.linear.y + o.linear.x) < 1e-9
    finally:
        node.destroy_node()
        rclpy.shutdown()


def test_enable_is_forwarded_and_false_ignored_while_airborne():
    import rclpy
    from std_msgs.msg import Bool
    from option_c_starter.scout_safety_watchdog import ScoutSafetyWatchdog
    rclpy.init(args=[])
    node = ScoutSafetyWatchdog()
    try:
        clock = [0.0]
        node.now = lambda: clock[0]
        en, evt = _Pub(), _Pub()
        node.pub_enable_gz, node.pub_evt = en, evt
        # no pose yet: both values are forwarded (the scout is on the ground at start)
        node.on_enable(Bool(data=False))
        node.on_enable(Bool(data=True))
        assert [m.data for m in en.msgs] == [False, True]
        # on the ground (z 0.08 m): false is forwarded
        node.on_truth(_odom(0.08))
        node.on_enable(Bool(data=False))
        assert en.msgs[-1].data is False and not node.enabled
        node.on_enable(Bool(data=True))
        assert en.msgs[-1].data is True and node.enabled
        # airborne (10 m): false is NOT forwarded, event enable_ignored, still enabled
        node.on_truth(_odom(10.0))
        n0 = len(en.msgs)
        clock[0] = 5.0
        node.on_enable(Bool(data=False))
        assert len(en.msgs) == n0 and node.enabled
        assert _events(evt) == ["enable_ignored"]
        assert json.loads(evt.msgs[-1].data)["pose_source"] == "truth"
        # repeated within 1 s: no second event; after 1 s: one more
        clock[0] = 5.5
        node.on_enable(Bool(data=False))
        clock[0] = 6.1
        node.on_enable(Bool(data=False))
        assert _events(evt) == ["enable_ignored", "enable_ignored"]
        assert len(en.msgs) == n0
        # true in the air is forwarded
        node.on_enable(Bool(data=True))
        assert len(en.msgs) == n0 + 1 and en.msgs[-1].data is True
        # just above the landed threshold (0.31 m) still counts as airborne; 0.30 m does not
        node.on_truth(_odom(0.31))
        node.on_enable(Bool(data=False))
        assert len(en.msgs) == n0 + 1
        node.on_truth(_odom(0.30))
        node.on_enable(Bool(data=False))
        assert en.msgs[-1].data is False and len(en.msgs) == n0 + 2
    finally:
        node.destroy_node()
        rclpy.shutdown()


def test_enable_ignored_event_carries_no_truth_in_drift_mode():
    import rclpy
    from std_msgs.msg import Bool
    from option_c_starter.scout_safety_watchdog import ScoutSafetyWatchdog
    rclpy.init(args=["--ros-args", "-p", "odom_mode:=drift"])
    node = ScoutSafetyWatchdog()
    try:
        clock = [0.0]
        node.now = lambda: clock[0]
        en, evt = _Pub(), _Pub()
        node.pub_enable_gz, node.pub_evt = en, evt
        node.on_truth(_odom(8.0, x=11.0, y=-4.0))
        node.on_est(_odom(8.0, x=12.5, y=-3.0))
        node.on_enable(Bool(data=False))
        assert not en.msgs
        p = json.loads(evt.msgs[-1].data)
        assert p["event"] == "enable_ignored" and p["pose_source"] == "odom_est"
        assert (p["x"], p["y"]) == (12.5, -3.0)
    finally:
        node.destroy_node()
        rclpy.shutdown()


def test_kinematic_mode_zero_twist_after_forwarded_false():
    import rclpy
    from geometry_msgs.msg import Twist
    from std_msgs.msg import Bool
    from option_c_starter.scout_safety_watchdog import ScoutSafetyWatchdog
    rclpy.init(args=["--ros-args", "-p", "scout_dynamics:=kinematic", "-p", "accel_xy_max:=0.0"])
    node = ScoutSafetyWatchdog()
    try:
        clock = [0.0]
        node.now = lambda: clock[0]
        main, kin, en, evt = _Pub(), _Pub(), _Pub(), _Pub()
        node.pub_cmd_main, node.pub_cmd_kin, node.pub_enable_gz, node.pub_evt = main, kin, en, evt

        def step(t, z, vz):
            clock[0] = t
            node.on_truth(_odom(z))
            c = Twist()
            c.linear.z = vz
            node.on_cmd(c)
            node.tick()
            return kin.msgs[-1].linear.z

        assert step(0.0, 0.08, 0.5) == 0.5            # enabled at start
        node.on_enable(Bool(data=False))               # on the ground: forwarded
        assert not node.enabled
        assert step(0.05, 0.08, 0.5) == 0.0
        node.on_enable(Bool(data=True))
        assert step(0.10, 0.08, 0.5) == 0.5
        node.on_enable(Bool(data=False))               # still on the ground: forwarded
        node.on_enable(Bool(data=True))
        assert step(0.15, 6.0, 0.5) == 0.5            # airborne
        node.on_enable(Bool(data=False))               # ignored in the air
        assert node.enabled and step(0.20, 6.0, 0.5) == 0.5
        assert "enable_ignored" in _events(evt)
    finally:
        node.destroy_node()
        rclpy.shutdown()


def test_teleop_refuses_enable_false_in_the_air():
    from option_c_starter.teleop_scout import enable_false_allowed
    assert enable_false_allowed(None)
    assert enable_false_allowed(0.08) and enable_false_allowed(0.3)
    assert not enable_false_allowed(0.31) and not enable_false_allowed(10.0)
    assert enable_false_allowed(float("nan"))
