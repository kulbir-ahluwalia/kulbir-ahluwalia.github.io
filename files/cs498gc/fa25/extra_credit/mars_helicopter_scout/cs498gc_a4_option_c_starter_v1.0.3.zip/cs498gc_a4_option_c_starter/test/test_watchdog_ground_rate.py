"""Watchdog unit tests: the watchdog repeats a zero twist at 1 Hz while the scout is idle on the
ground, and at 20 Hz otherwise (airborne, a fresh nonzero command, or a recent enable); the
horizontal velocity setpoint is slew-limited to 1 m/s^2, including the watchdog's own stops; in
drift mode it holds the estimated heading and adds a per-run random yaw-rate disturbance.
"""
import sys
from pathlib import Path

PKG = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PKG))


class _Pub:
    def __init__(self):
        self.msgs = []

    def publish(self, m):
        self.msgs.append(m)


def _odom(z):
    from nav_msgs.msg import Odometry
    m = Odometry()
    m.pose.pose.position.x, m.pose.pose.position.y, m.pose.pose.position.z = 1.0, 2.0, z
    m.pose.pose.orientation.w = 1.0
    return m


def _run(node, clock, t0, t1, dt=0.05):
    """Tick at t0, t0 + dt, ... (< t1), with times computed from an integer count (no float drift)."""
    n = int(round((t1 - t0) / dt))
    for k in range(n):
        clock[0] = round(t0 + k * dt, 6)
        node.tick()


def test_ground_idle_rate_and_wakeup():
    import rclpy
    from geometry_msgs.msg import Twist
    from std_msgs.msg import Bool
    from option_c_starter.scout_safety_watchdog import ScoutSafetyWatchdog
    rclpy.init(args=[])
    node = ScoutSafetyWatchdog()
    try:
        clock = [0.0]
        node.now = lambda: clock[0]
        pub = _Pub()
        node.pub_cmd_main = pub
        node.on_truth(_odom(0.05))                 # landed
        _run(node, clock, 0.0, 2.0)                # 40 ticks, idle: t = 0, 1.0 only
        assert len(pub.msgs) == 2, len(pub.msgs)
        # a fresh nonzero command on the ground: every tick again
        cmd = Twist()
        cmd.linear.z = 0.5
        n0 = len(pub.msgs)
        clock[0] = 2.0
        node.on_cmd(cmd)
        _run(node, clock, 2.0, 2.4)                # 8 ticks within the 0.5 s timeout
        assert len(pub.msgs) - n0 == 8
        assert pub.msgs[-1].linear.z == 0.5
        # stale command, idle again: next repeat at most 1 s after the last publish
        n0 = len(pub.msgs)
        _run(node, clock, 3.0, 5.0)
        assert 2 <= len(pub.msgs) - n0 <= 3, len(pub.msgs) - n0
        # an enable on the ground: 20 Hz for the next second
        clock[0] = 5.0
        node.on_enable(Bool(data=True))
        n0 = len(pub.msgs)
        _run(node, clock, 5.0, 5.5)
        assert len(pub.msgs) - n0 == 10
        # airborne with a fresh ZERO command (hover): every tick
        node.on_truth(_odom(5.0))
        clock[0] = 7.0
        node.on_cmd(Twist())
        n0 = len(pub.msgs)
        _run(node, clock, 7.0, 7.4)
        assert len(pub.msgs) - n0 == 8
        # airborne and the command goes stale (cmd_timeout): still every tick
        n0 = len(pub.msgs)
        _run(node, clock, 8.0, 9.0)
        assert len(pub.msgs) - n0 == 20
    finally:
        node.destroy_node()
        rclpy.shutdown()


def test_ground_idle_rate_can_be_disabled():
    import rclpy
    from option_c_starter.scout_safety_watchdog import ScoutSafetyWatchdog
    rclpy.init(args=["--ros-args", "-p", "ground_idle_rate_hz:=0.0"])
    node = ScoutSafetyWatchdog()
    try:
        clock = [0.0]
        node.now = lambda: clock[0]
        pub = _Pub()
        node.pub_cmd_main = pub
        node.on_truth(_odom(0.05))
        _run(node, clock, 0.0, 1.0)
        assert len(pub.msgs) == 20
    finally:
        node.destroy_node()
        rclpy.shutdown()


def test_horizontal_setpoint_slew_limit():
    import rclpy
    from geometry_msgs.msg import Twist
    from option_c_starter.scout_safety_watchdog import ScoutSafetyWatchdog
    rclpy.init(args=[])
    node = ScoutSafetyWatchdog()
    try:
        clock = [0.0]
        node.now = lambda: clock[0]
        pub = _Pub()
        node.pub_cmd_main = pub
        node.on_truth(_odom(10.0))                 # airborne, yaw 0: body x = east

        def fly(t0, n, vx, vz=0.4, fresh=True):
            out = []
            for k in range(n):
                clock[0] = round(t0 + 0.05 * k, 6)
                if fresh:
                    c = Twist()
                    c.linear.x, c.linear.z = vx, vz
                    node.on_cmd(c)
                node.tick()
                out.append((pub.msgs[-1].linear.x, pub.msgs[-1].linear.z))
            return out

        up = fly(0.0, 80, 3.0)                     # step hover -> 3 m/s
        xs = [x for x, _ in up]
        assert all(0.0 <= b - a <= 0.05 + 1e-9 for a, b in zip([0.0] + xs, xs))
        assert abs(xs[19] - 1.0) < 1e-9 and abs(xs[-1] - 3.0) < 1e-12
        assert all(z == 0.4 for _, z in up)        # the vertical command is not slewed
        rev = [x for x, _ in fly(4.0, 140, -3.0)]  # reversal: 6 s at 1 m/s^2
        assert all(-0.05 - 1e-9 <= b - a <= 0.0 for a, b in zip([xs[-1]] + rev, rev))
        assert abs(rev[59] - 0.0) < 1e-9 and abs(rev[-1] + 3.0) < 1e-12
        nan = [x for x, _ in fly(11.0, 10, float("nan"))]   # NaN = zero command, ramped
        assert all(abs(b - a) <= 0.05 + 1e-9 for a, b in zip([rev[-1]] + nan, nan))
        assert abs(nan[-1] + 2.5) < 1e-9
        # stale command (cmd_timeout): the watchdog's own stop is ramped too
        stale = [x for x, _ in fly(11.5, 60, 0.0, fresh=False)]
        assert all(abs(b - a) <= 0.05 + 1e-9 for a, b in zip([nan[-1]] + stale, stale))
        assert stale[-1] == 0.0
        # a pause in the ticks (sim paused) never lets the setpoint jump more than 5 ticks' worth
        clock[0] = 30.0
        c = Twist()
        c.linear.x = 3.0
        node.on_cmd(c)
        node.tick()
        assert abs(pub.msgs[-1].linear.x - 0.25) < 1e-9
    finally:
        node.destroy_node()
        rclpy.shutdown()


def _odom_yaw(z, yaw):
    import math
    m = _odom(z)
    m.pose.pose.orientation.z, m.pose.pose.orientation.w = math.sin(yaw / 2.0), math.cos(yaw / 2.0)
    return m


def test_drift_mode_holds_the_estimated_heading():
    """odom_mode:=drift, airborne: the yaw-rate command steers the odom_est yaw to the commanded
    heading (so the true heading drifts with the yaw error); on the ground and in truth mode the
    student's yaw rate passes unchanged. The yaw disturbance is switched off here so the hold law
    can be checked exactly (test_drift_mode_yaw_disturbance checks it)."""
    import rclpy
    from geometry_msgs.msg import Twist
    from option_c_starter.scout_safety_watchdog import ScoutSafetyWatchdog
    for mode in ("drift", "truth"):
        rclpy.init(args=["--ros-args", "-p", "odom_mode:=%s" % mode,
                         "-p", "yaw_disturbance_std:=0.0"])
        node = ScoutSafetyWatchdog()
        try:
            clock = [0.0]
            node.now = lambda: clock[0]
            pub = _Pub()
            node.pub_cmd_main = pub

            def tick(t, est_yaw, wz=0.0, z=10.0):
                clock[0] = t
                node.on_truth(_odom_yaw(z, 0.0))           # the true heading stays 0 here
                node.on_est(_odom_yaw(z, est_yaw))
                c = Twist()
                c.angular.z = wz
                node.on_cmd(c)
                node.tick()
                return pub.msgs[-1].angular.z

            assert abs(tick(0.0, 0.10)) < 1e-12           # psi_c starts at the estimate
            w = tick(0.05, 0.12)                          # the estimate drifted +0.02 rad
            if mode == "drift":
                assert abs(w - 0.5 * -0.02) < 1e-9, w     # gain 0.5: steer back
            else:
                assert w == 0.0
            for k in range(20):                           # 1 s at a commanded 0.2 rad/s
                w = tick(0.1 + 0.05 * k, 0.12, wz=0.2)
            if mode == "drift":
                # psi_c = 0.10 + 0.2 x 1.0 s; correction 0.5 x (0.30 - 0.12), capped at 0.2 rad/s
                assert abs(w - (0.2 + min(0.2, 0.5 * 0.18))) < 1e-6, w
            else:
                assert abs(w - 0.2) < 1e-12
            w = tick(2.5, 0.12, wz=0.0, z=0.1)            # landed: no hold, psi_c reset
            assert w == 0.0
            assert node.psi_c is None
            node.on_truth(_odom_yaw(10.0, 0.0))
            node.on_est(_odom_yaw(10.0, -3.0))            # wrap: psi_c restarts at -3.0
            assert abs(tick(3.0, -3.0)) < 1e-12
            w = tick(3.05, 3.0)                           # -3.0 -> 3.0 is a +0.283 rad change
            if mode == "drift":
                assert abs(w - 0.5 * ((-3.0 - 3.0) + 2.0 * 3.141592653589793)) < 1e-6, w
        finally:
            node.destroy_node()
            rclpy.shutdown()


def test_ou_step_statistics():
    import math
    import random
    from option_c_starter.scout_safety_watchdog import ou_step
    rng = random.Random(4)
    x, xs = None, []
    for _ in range(40000):                       # 2000 s at 20 Hz, tau 3 s
        x = ou_step(x, 0.05, 0.02, 3.0, rng.gauss)
        xs.append(x)
    m = sum(xs) / len(xs)
    sd = math.sqrt(sum((v - m) ** 2 for v in xs) / len(xs))
    assert abs(m) < 0.004 and 0.017 < sd < 0.023, (m, sd)
    lag = 60                                      # 3 s: autocorrelation about exp(-1) = 0.37
    r = sum((xs[i] - m) * (xs[i + lag] - m) for i in range(len(xs) - lag)) / (len(xs) - lag) / sd ** 2
    assert 0.25 < r < 0.5, r
    assert ou_step(0.5, 0.05, 0.0, 3.0, rng.gauss) == 0.0


def test_drift_mode_yaw_disturbance():
    """odom_mode:=drift, airborne: the yaw-rate command = hold law + a zero-mean random
    disturbance that differs between runs, so the true heading cannot be recomputed from the hold
    law and public data. Truth mode and the ground never get it."""
    import math
    import rclpy
    from geometry_msgs.msg import Twist
    from option_c_starter.scout_safety_watchdog import ScoutSafetyWatchdog

    def run(mode, z):
        rclpy.init(args=["--ros-args", "-p", "odom_mode:=%s" % mode])
        node = ScoutSafetyWatchdog()
        try:
            clock = [0.0]
            node.now = lambda: clock[0]
            pub = _Pub()
            node.pub_cmd_main = pub
            out = []
            for k in range(400):                  # 20 s; estimate = psi_c, so the law gives 0
                clock[0] = round(0.05 * k, 6)
                node.on_truth(_odom_yaw(z, 0.0))
                node.on_est(_odom_yaw(z, 0.0))
                node.on_cmd(Twist())
                node.tick()
                out.append(pub.msgs[-1].angular.z if pub.msgs else 0.0)
            return out
        finally:
            node.destroy_node()
            rclpy.shutdown()

    a, b = run("drift", 10.0), run("drift", 10.0)
    sd = math.sqrt(sum(v * v for v in a) / len(a))
    assert 0.005 < sd < 0.06, sd                 # about 0.02 rad/s
    assert max(abs(v) for v in a) <= 1.0
    assert a != b                                 # fresh random source in every run
    assert len({round(v, 12) for v in a}) > 300   # no constant value to read off
    assert all(v == 0.0 for v in run("truth", 10.0))
    assert all(v == 0.0 for v in run("drift", 0.1))   # landed: no hold, no disturbance
