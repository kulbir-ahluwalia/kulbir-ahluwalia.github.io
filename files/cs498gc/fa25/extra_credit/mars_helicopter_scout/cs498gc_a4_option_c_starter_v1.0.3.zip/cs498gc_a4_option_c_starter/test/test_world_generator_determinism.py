"""World generator determinism (spec: same seed -> byte-identical SDF and JSON on any Python 3.10+).

Run: colcon test --packages-select cs498gc_a4_option_c_starter
 or: python3 -m pytest test/test_world_generator_determinism.py
The full 20-seed check that compares several Python versions is run by the course staff; this file
checks generation twice in one interpreter plus the world rules that are cheap to recompute.
"""
import hashlib
import importlib.util
import json
import math
import subprocess
import sys
from pathlib import Path

import pytest

PKG = Path(__file__).resolve().parents[1]
GEN = PKG / "tools" / "gen_option_c_world.py"
SEEDS = [0, 1, 2, 7, 101, 202, 303, 3141592653]


def _load():
    spec = importlib.util.spec_from_file_location("gen_option_c_world", str(GEN))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


@pytest.fixture(scope="module")
def gen():
    return _load()


def test_generator_uses_stdlib_only():
    text = GEN.read_text(encoding="utf-8")
    assert "import random" not in text and "from random" not in text
    for line in text.splitlines():
        if line.startswith("import ") or line.startswith("from "):
            mod = line.split()[1].split(".")[0]
            assert mod in {"argparse", "hashlib", "heapq", "json", "os", "sys", "pathlib"}, line


@pytest.mark.parametrize("seed", SEEDS)
def test_same_seed_same_bytes(gen, seed):
    a, gta, _ = gen.generate(seed)
    b, gtb, _ = gen.generate(seed)
    assert a == b
    assert gen.gt_json_text(gta) == gen.gt_json_text(gtb)
    assert gta["sdf_sha256"] == hashlib.sha256(a.encode("utf-8")).hexdigest()


def test_fresh_interpreter_matches(gen, tmp_path):
    seed = 7
    out = subprocess.run([sys.executable, str(GEN), "--seed", str(seed), "--no-write",
                          "--print-sha256"], capture_output=True, text=True, check=True)
    sdf, _gt, _ = gen.generate(seed)
    assert out.stdout.strip() == hashlib.sha256(sdf.encode("utf-8")).hexdigest()
    gen.write_world(seed, tmp_path)
    sdf_path, gt_path = gen.world_paths(seed, tmp_path)
    assert sdf_path.read_bytes() == sdf.encode("utf-8")
    json.loads(gt_path.read_text(encoding="utf-8"))


def test_floats_are_four_decimals(gen):
    sdf, _gt, _ = gen.generate(7)
    import re
    for num in re.findall(r"-?\d+\.\d+", sdf.split("-->", 1)[1]):
        assert len(num.split(".")[1]) <= 7, num   # 4 decimals, plus fixed constants like 1.5707963


@pytest.mark.parametrize("seed", SEEDS[:5])
def test_world_rules(gen, seed):
    _sdf, gt, _ = gen.generate(seed)
    S, G, H = gt["S"], gt["G"], gt["helipad"]
    d_sg = math.hypot(G[0] - S[0], G[1] - S[1])
    assert 100.0 <= d_sg <= 120.0
    for p in (S, G):
        assert -65.0 <= p[0] <= 65.0 and -65.0 <= p[1] <= 65.0
    ux, uy = (S[0] - G[0]) / d_sg, (S[1] - G[1]) / d_sg
    assert math.hypot(H[0] - (S[0] + 3.0 * ux), H[1] - (S[1] + 3.0 * uy)) < 0.01
    boulders, rocks = gt["boulders"], gt["rocks"]
    assert 25 <= len(boulders) <= 40
    for b in boulders:
        assert 2.5 <= 2 * b["radius"] <= 4.0 + 1e-6 and 1.0 <= b["height"] <= 2.0 + 1e-6
        for p in (S, G, H):
            assert math.hypot(b["x"] - p[0], b["y"] - p[1]) - b["radius"] >= 6.0 - 1e-6
    for i, a in enumerate(boulders):
        for b in boulders[i + 1:]:
            assert math.hypot(a["x"] - b["x"], a["y"] - b["y"]) - a["radius"] - b["radius"] >= 3.0 - 1e-6
    assert 3 <= len(gt["rock_fields"]) <= 5
    for r in rocks:
        assert 0.4 - 1e-6 <= 2 * r["radius"] <= 0.9 + 1e-6 and 0.35 - 1e-6 <= r["height"] <= 0.60 + 1e-6
    assert gt["reference_path"]["rocks_overlapping_reference_footprint"] >= 3 \
        if isinstance(gt["reference_path"]["rocks_overlapping_reference_footprint"], int) \
        else len(gt["reference_path"]["rocks_overlapping_reference_footprint"]) >= 3
    assert gt["feasible_path"]["ratio_to_reference"] <= 1.6
    sp = gt["sand_patch"]
    assert 15.0 - 1e-6 <= sp["length"] <= 25.0 + 1e-6 and 8.0 - 1e-6 <= sp["width"] <= 12.0 + 1e-6


@pytest.mark.parametrize("seed", [7, 9, 16, 303])
def test_route_family_and_barriers(gen, seed):
    """Guarantee (a) holds for the whole route family, every on-path field cuts the
    corridor, and each barrier chain is a connected wall for the r_fp = 0.45 m footprint."""
    _sdf, gt, _ = gen.generate(seed)
    routes = gt["route_family"]["routes"]
    assert {"astar_fwd", "astar_rev", "taut_fwd"} <= set(routes)
    assert all(len(v["rocks_overlapped"]) >= 3 for v in routes.values())
    on_path = [f for f in gt["rock_fields"] if f["role"] == "on_path"]
    assert len(on_path) >= 2
    assert all(gt["corridor_cut"]["fields"].get(f["id"]) for f in on_path)
    rocks = {r["id"]: r for r in gt["rocks"]}
    for f in on_path:
        chain = [rocks[i] for i in f["barrier_rocks"]]
        assert len(chain) >= 5
        for a, b in zip(chain, chain[1:]):
            d = math.hypot(a["x"] - b["x"], a["y"] - b["y"])
            assert 1.5 <= d < 0.45 * 2 + a["radius"] + b["radius"], (a["id"], b["id"], d)
        for r in chain:
            assert math.hypot(r["x"] - f["x"], r["y"] - f["y"]) <= f["radius"] + 1e-6
    # an independent route: the straight S-G segment, when it is collision free, crosses
    # both barriers, so it overlaps >= 2 rocks
    poly = [tuple(p) for p in gt["sand_patch"]["polygon"]]
    S, G = gt["S"], gt["G"]
    if all(gen.dist_point_segment(b["x"], b["y"], S[0], S[1], G[0], G[1]) > b["radius"] + 0.55
           for b in gt["boulders"]) and gen.dist_segment_polygon(S[0], S[1], G[0], G[1], poly) > 0.55:
        n = sum(1 for r in gt["rocks"]
                if gen.dist_point_segment(r["x"], r["y"], S[0], S[1], G[0], G[1]) < 0.45 + r["radius"])
        assert n >= 2
