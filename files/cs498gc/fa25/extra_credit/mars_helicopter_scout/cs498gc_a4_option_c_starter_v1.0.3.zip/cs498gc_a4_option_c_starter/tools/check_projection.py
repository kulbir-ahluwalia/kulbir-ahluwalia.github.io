#!/usr/bin/env python3
"""check_projection.py: M0b nadir projection test against worlds/calib_tile.sdf.

Start the calibration world first:
  ros2 launch cs498gc_a4_option_c_starter calib_tile.launch.py headless:=true
Then, in another terminal (same ROS_DOMAIN_ID):
  ros2 run cs498gc_a4_option_c_starter check_projection --func my_projection:pixel_to_ground \\
      --module-path ~/option_c_m0b --fly --out m0b.json

--func is module:function. --module-path is the FOLDER that contains the module file (here
~/option_c_m0b/my_projection.py); it is put first on sys.path, so the file needs no package, no
__init__.py and no colcon build. At M0 you do not have option_c_scout yet: any folder works, and
examples/pixel_to_ground_stub.py in this package is a skeleton to copy there. Later, point it at
the folder of the module inside your package (for example <workspace>/src/option_c_scout/
option_c_scout) to test the function your mosaicker really uses.

Your function must have the signature
    pixel_to_ground(u, v, K, pose) -> (x, y)
  u, v  pixel coordinates in the image (u = column index, v = row index; the tool passes the
        centroid of each detected fiducial in the same index coordinates your code sees)
  K     the 9 numbers of sensor_msgs/CameraInfo.k (row-major 3 x 3)
  pose  dict with keys x, y, z, qx, qy, qz, qw: the scout base_link pose in the map frame,
        interpolated to the image stamp (linear position, slerp orientation) from
        /model/ingenuity_quad_approx/odometry
and return the ground point (z = 0) in the map frame. Compose the camera mount yourself
(config/scout_mount.yaml; docs/FRAMES.md).

The tool detects the four fiducials (red (+5,+5), green (-5,+5), blue (-5,-5), white (+5,-5);
each 1.0 m x 1.0 m) in every nadir frame, keeps only blobs fully inside the image, calls your
function on each centroid, and reports the error against the true center, split into hover
(horizontal speed < 0.2 m/s) and translate (> 0.5 m/s) samples. It also calls your function with
the attitude ignored (roll = pitch = 0, yaw kept) so you can report that error (MR-2).
PASS (M0b): every hover error <= 0.15 m and every translate error <= 0.30 m.

--fly makes the tool fly the standard maneuver itself (12 m hover over the origin for 10 s, then
a 1 m/s pass from x = -9 m to x = +9 m along y = 0, then landing). 12 m rather than 10 m because
at 10 m the 1.0 m squares at (+-5, +-5) touch the 240 px image border (footprint 13.7 x 10.3 m).
Without --fly, fly the scout yourself and the tool only listens for --duration seconds.

If your function raises an exception (for example the stub's NotImplementedError) or does not
return two numbers, the tool prints the error with a hint, stops calling it, lands the scout (with
--fly) and exits with code 1.
"""
import argparse
import importlib
import json
import math
import sys
import time
import traceback

import rclpy
from rclpy.node import Node
from rclpy.parameter import Parameter
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from sensor_msgs.msg import CameraInfo, Image
from std_msgs.msg import Bool

FIDUCIALS = {"red": (5.0, 5.0), "green": (-5.0, 5.0), "blue": (-5.0, -5.0), "white": (5.0, -5.0)}


def classify(r, g, b):
    if r > 180 and g < 90 and b < 90:
        return "red"
    if g > 180 and r < 90 and b < 90:
        return "green"
    if b > 180 and r < 90 and g < 90:
        return "blue"
    if r > 215 and g > 215 and b > 215:
        return "white"
    return None


def detect(img):
    """Return {color: (u_centroid, v_centroid, n_pixels, touches_border)} for an rgb8 image."""
    w, h, step, data = img.width, img.height, img.step, img.data
    acc = {}
    for v in range(h):
        row = v * step
        for u in range(w):
            k = row + 3 * u
            c = classify(data[k], data[k + 1], data[k + 2])
            if c is None:
                continue
            a = acc.setdefault(c, [0.0, 0.0, 0, w, -1, h, -1])
            a[0] += u
            a[1] += v
            a[2] += 1
            a[3] = min(a[3], u)
            a[4] = max(a[4], u)
            a[5] = min(a[5], v)
            a[6] = max(a[6], v)
    out = {}
    for c, a in acc.items():
        border = a[3] <= 1 or a[5] <= 1 or a[4] >= w - 2 or a[6] >= h - 2
        out[c] = (a[0] / a[2], a[1] / a[2], a[2], border)
    return out


def slerp(q0, q1, s):
    dot = sum(a * b for a, b in zip(q0, q1))
    if dot < 0.0:
        q1 = tuple(-c for c in q1)
        dot = -dot
    if dot > 0.9995:
        q = tuple(a + s * (b - a) for a, b in zip(q0, q1))
    else:
        th = math.acos(dot)
        s0 = math.sin((1 - s) * th) / math.sin(th)
        s1 = math.sin(s * th) / math.sin(th)
        q = tuple(s0 * a + s1 * b for a, b in zip(q0, q1))
    n = math.sqrt(sum(c * c for c in q))
    return tuple(c / n for c in q)


def yaw_only(q):
    x, y, z, w = q
    yaw = math.atan2(2.0 * (w * z + x * y), 1.0 - 2.0 * (y * y + z * z))
    return (0.0, 0.0, math.sin(yaw / 2), math.cos(yaw / 2))


def tilt_deg(q):
    x, y, z, w = q
    # angle between body z and world z
    bz_z = 1.0 - 2.0 * (x * x + y * y)
    return math.degrees(math.acos(max(-1.0, min(1.0, bz_z))))


def load_func(spec, module_path):
    if module_path:
        sys.path.insert(0, module_path)
    mod_name, fn = spec.split(":")
    return getattr(importlib.import_module(mod_name), fn)


class CheckProjection(Node):
    def __init__(self, a, func):
        super().__init__("check_projection", parameter_overrides=[Parameter("use_sim_time", value=True)])
        self.a = a
        self.func = func
        self.k = None
        self.odom = []
        self.samples = []
        self.frames = 0
        self.pub = self.create_publisher(Twist, "/option_c/scout/cmd_vel", 10)
        self.pub_en = self.create_publisher(Bool, "/ingenuity/enable", 10)
        self.create_subscription(CameraInfo, "/ingenuity/nadir_cam/camera_info", self.on_info, 5)
        self.create_subscription(Odometry, a.odom_topic, self.on_odom, 50)
        self.create_subscription(Image, "/ingenuity/nadir_cam/image", self.on_image, 5)
        self.state = "WAIT"
        self.t_state = None
        self.t_fly0 = None
        self.done = False
        self.func_error = None        # (one-line message, traceback text) of the first failure
        self.timer = self.create_timer(0.1, self.fly) if a.fly else None
        self.t0 = time.time()

    def on_func_error(self, exc):
        """Your function failed: remember the first error, stop calling it and land (or stop)."""
        if self.func_error is not None:
            return
        self.func_error = ("%s raised %s: %s" % (self.a.func, type(exc).__name__, exc),
                           traceback.format_exc())
        self.get_logger().error("your projection function failed: %s (see the message at the end)"
                                % self.func_error[0])
        if self.timer is None or self.state in ("WAIT", "DONE"):
            self.done = True
        elif self.state != "LAND":
            self.go("LAND")

    def now(self):
        return self.get_clock().now().nanoseconds * 1e-9

    def on_info(self, msg):
        self.k = list(msg.k)

    def on_odom(self, msg):
        t = msg.header.stamp.sec + msg.header.stamp.nanosec * 1e-9
        p = msg.pose.pose.position
        q = msg.pose.pose.orientation
        self.odom.append((t, p.x, p.y, p.z, (q.x, q.y, q.z, q.w)))
        if len(self.odom) > 400:
            self.odom = self.odom[-400:]

    def pose_at(self, t):
        od = self.odom
        for i in range(len(od) - 1, 0, -1):
            if od[i - 1][0] <= t <= od[i][0]:
                a, b = od[i - 1], od[i]
                s = 0.0 if b[0] == a[0] else (t - a[0]) / (b[0] - a[0])
                pos = [a[j] + s * (b[j] - a[j]) for j in (1, 2, 3)]
                q = slerp(a[4], b[4], s)
                vh = math.hypot(b[1] - a[1], b[2] - a[2]) / max(1e-6, b[0] - a[0])
                return pos, q, vh
        return None

    def on_image(self, msg):
        if self.func_error is not None or self.k is None or msg.encoding not in ("rgb8", "8UC3"):
            return
        t = msg.header.stamp.sec + msg.header.stamp.nanosec * 1e-9
        pq = self.pose_at(t)
        if pq is None:
            return
        pos, q, vh = pq
        if pos[2] < 6.0:
            return
        self.frames += 1
        expected = (self.k[0] / pos[2]) ** 2
        for color, (u, v, n, border) in detect(msg).items():
            if border or n < 0.5 * expected:
                continue
            pose = {"x": pos[0], "y": pos[1], "z": pos[2], "qx": q[0], "qy": q[1], "qz": q[2], "qw": q[3]}
            qy = yaw_only(q)
            pose0 = dict(pose, qx=qy[0], qy=qy[1], qz=qy[2], qw=qy[3])
            try:
                gx, gy = (float(c) for c in self.func(u, v, self.k, pose))
                hx, hy = (float(c) for c in self.func(u, v, self.k, pose0))
            except Exception as exc:  # noqa: BLE001 - your function: report it, never crash
                self.on_func_error(exc)
                return
            tx, ty = FIDUCIALS[color]
            self.samples.append({
                "t": round(t, 3), "color": color, "u": round(u, 2), "v": round(v, 2),
                "z": round(pos[2], 3), "hspeed": round(vh, 3), "tilt_deg": round(tilt_deg(q), 2),
                "err_m": round(math.hypot(gx - tx, gy - ty), 4),
                "err_attitude_ignored_m": round(math.hypot(hx - tx, hy - ty), 4)})

    def send(self, vx, vy, vz):
        t = Twist()
        t.linear.x, t.linear.y, t.linear.z = float(vx), float(vy), float(vz)
        self.pub.publish(t)

    def go(self, s):
        self.state = s
        self.t_state = self.now()
        self.get_logger().info("maneuver -> %s" % s)

    def fly(self):
        if not self.odom:
            return
        t = self.now()
        if t <= 0.0:
            return
        if self.t_fly0 is None:
            self.t_fly0 = t
        _, x, y, z, _q = self.odom[-1]

        def clip(v, m):
            # float() matters: an int in a Twist float64 field aborts rclpy in C
            return float(max(-float(m), min(float(m), float(v))))

        alt = self.a.alt
        if self.state == "WAIT":
            if t - self.t_fly0 > 2.0:
                for _ in range(3):
                    self.pub_en.publish(Bool(data=True))
                self.go("CLIMB")
        elif self.state == "CLIMB":
            self.send(clip(-0.6 * x, 1), clip(-0.6 * y, 1), clip(0.8 * (alt - z), 1))
            if abs(z - alt) < 0.2:
                self.go("HOVER")
        elif self.state == "HOVER":
            self.send(clip(-0.6 * x, 1), clip(-0.6 * y, 1), clip(0.8 * (alt - z), 1))
            if t - self.t_state > 10.0:
                self.go("TO_START")
        elif self.state == "TO_START":
            self.send(clip(0.6 * (-9 - x), 1), clip(-0.6 * y, 1), clip(0.8 * (alt - z), 1))
            if abs(x + 9) < 0.3 and abs(y) < 0.3:
                self.go("PASS")
        elif self.state == "PASS":
            self.send(1.0 if x < 9.0 else 0.0, clip(-0.6 * y, 0.5), clip(0.8 * (alt - z), 1))
            if x >= 9.0:
                self.go("RETURN")
        elif self.state == "RETURN":
            self.send(clip(-0.6 * x, 1), clip(-0.6 * y, 1), clip(0.8 * (alt - z), 1))
            if abs(x) < 0.3 and abs(y) < 0.3:
                self.go("LAND")
        elif self.state == "LAND":
            self.send(clip(-0.6 * x, 0.3), clip(-0.6 * y, 0.3), -0.8 if z > 2 else -0.3)
            if z < 0.2:
                self.send(0.0, 0.0, 0.0)
                self.go("DONE")
                self.done = True


def summarize(samples, frames):
    def stats(key, sel):
        e = sorted(s[key] for s in sel)
        if not e:
            return {"n": 0}
        return {"n": len(e), "median_m": e[len(e) // 2], "p95_m": e[min(len(e) - 1, int(0.95 * len(e)))],
                "max_m": e[-1]}
    hover = [s for s in samples if s["hspeed"] < 0.2]
    trans = [s for s in samples if s["hspeed"] > 0.5]
    res = {"frames_used": frames, "samples": len(samples),
           "hover": stats("err_m", hover), "translate": stats("err_m", trans),
           "hover_attitude_ignored": stats("err_attitude_ignored_m", hover),
           "translate_attitude_ignored": stats("err_attitude_ignored_m", trans),
           "translate_max_tilt_deg": max((s["tilt_deg"] for s in trans), default=None)}
    res["pass_hover_0p15"] = bool(hover) and res["hover"]["max_m"] <= 0.15
    res["pass_translate_0p30"] = bool(trans) and res["translate"]["max_m"] <= 0.30
    res["PASS"] = res["pass_hover_0p15"] and res["pass_translate_0p30"]
    return res


def main(argv=None):
    # --help prints the whole module docstring (interface of pixel_to_ground, K, pose, PASS rule)
    ap = argparse.ArgumentParser(description="M0b nadir projection check on calib_tile.sdf",
                                 formatter_class=argparse.RawDescriptionHelpFormatter,
                                 epilog=__doc__)
    ap.add_argument("--func", required=True, help="module:function, e.g. my_projection:pixel_to_ground")
    ap.add_argument("--module-path", default="",
                    help="folder that contains the module file of --func (put first on sys.path; "
                         "any folder, no package or build needed)")
    ap.add_argument("--fly", action="store_true", help="fly the standard maneuver")
    ap.add_argument("--alt", type=float, default=12.0)
    ap.add_argument("--duration", type=float, default=150.0, help="max wall seconds")
    ap.add_argument("--odom-topic", default="/model/ingenuity_quad_approx/odometry")
    ap.add_argument("--out", default="", help="write the JSON report (and samples) here")
    a, ros_args = ap.parse_known_args(argv)
    func = load_func(a.func, a.module_path)
    rclpy.init(args=ros_args)
    node = CheckProjection(a, func)
    try:
        while rclpy.ok() and time.time() - node.t0 < a.duration and not node.done:
            rclpy.spin_once(node, timeout_sec=0.05)
    except KeyboardInterrupt:
        pass
    res = summarize(node.samples, node.frames)
    if node.func_error is not None:
        res["PASS"] = False
        res["error"] = node.func_error[0]
    print(json.dumps(res, indent=1))
    if a.out:
        with open(a.out, "w", encoding="utf-8") as f:
            json.dump({"summary": res, "samples": node.samples}, f, indent=1)
    node.destroy_node()
    if rclpy.ok():
        rclpy.shutdown()
    if node.func_error is not None:
        print("\ncheck_projection: %s\n%s" % (node.func_error[0], node.func_error[1].rstrip()),
              file=sys.stderr)
        print("Hint: fix the function above (the stub's TODO is the projection itself; see "
              "docs/FRAMES.md). It must return the ground point (x, y) as two numbers. The tool "
              "stopped calling it%s." % (" and landed the scout" if a.fly else ""), file=sys.stderr)
    return 0 if res["PASS"] else 1


if __name__ == "__main__":
    sys.exit(main())
