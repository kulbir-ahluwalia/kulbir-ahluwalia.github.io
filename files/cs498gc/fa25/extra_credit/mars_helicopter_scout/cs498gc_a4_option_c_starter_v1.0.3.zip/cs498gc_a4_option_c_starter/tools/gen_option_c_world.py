#!/usr/bin/env python3
"""gen_option_c_world.py: world generator for CS 498 GC / ABE 426 A4 Extra Credit Option C
(Mars Helicopter Scout), starter package cs498gc_a4_option_c_starter v1.0.0.

Python standard library only. All randomness comes from SHA-256 in counter mode (no `random`
module), every generated number is quantized to 4 decimals as soon as it is drawn, and every float
is written with '%.4f'. Trigonometry uses a fixed Taylor series built only from + - * / so the
result does not depend on the platform math library. Same seed -> byte-identical SDF and JSON on any
Python 3.10+.

Usage:
  python3 gen_option_c_world.py --seed 7
  python3 gen_option_c_world.py --seed 7 --out-dir /tmp/oc --print-sha256

Writes:
  <out-dir>/worlds/generated/mars_scout_seed_<N>.sdf     Gazebo world 'mars_scout'
  <out-dir>/ground_truth/hazards_seed_<N>.json           x, y, radius, height, type of every hazard,
                                                         the sand polygon, S, G and the helipad
Default <out-dir> is $OPTION_C_WORK_DIR, else ~/.ros/cs498gc_option_c.

The grader imports this file (it has no ROS dependency) and calls generate(seed) and
reference_astar(gt, r_fp). Keep both stable across releases of starter major version 1.

Generator guarantees (checked for every world; a failing attempt is redrawn):
  (a) every member of route_family() (the reference A*, the same A* from G to S and with the
      other tie-break, their string-pulled versions, and A* with 0.3 m less or more inflation)
      overlaps >= 3 rocks with the r_fp = 0.45 m footprint;
  (a2) each of the >= 2 on-path rock fields holds a barrier chain of rocks (consecutive centres
      1.52 m apart, radius >= 0.35 m, so the footprint-inflated disks touch) laid across the
      cross-section of the corridor; corridor_cut() confirms that no path within 1.5 m of the
      reference, of a family route or of any shortest 8-connected grid path gets past the field
      without overlapping one of its rocks;
  (b) a ground-truth feasible path with 0.3 m clearance exists and is <= 1.6 x the reference.

The scout and the rover are NOT part of the world file: the launch file spawns them at the helipad
and at S, so the world bytes (and world_sha256) depend on the seed only, not on launch options such
as scout_dynamics or rover.
"""
import argparse
import hashlib
import heapq
import json
import os
import sys
from pathlib import Path

# 1.1.0: on-path rock fields hold a barrier chain across the whole corridor of
# plausible orbit-only routes; guarantee (a) is checked for a route family and a corridor cut.
# Worlds (and world_sha256) differ from 1.0.0 for every seed.
GENERATOR_VERSION = "1.1.0"
WORLD_NAME = "mars_scout"
HALF_EXTENT = 80.0            # world is [-80, 80]^2, x east, y north
R_FP_REF = 0.45               # starter rover footprint radius used by the generator guarantees
MAX_ATTEMPTS = 200
PI = 3.141592653589793
TWO_PI = 6.283185307179586
SQRT2 = 1.4142135623730951


# ----------------------------------------------------------------------------------------------
# Deterministic numerics
# ----------------------------------------------------------------------------------------------
def q4(v):
    """Quantize to 4 decimals; normalizes -0.0 to 0.0."""
    r = float("%.4f" % v)
    return r + 0.0


def f4(v):
    return "%.4f" % (v + 0.0)


def _reduce_angle(a):
    k = round(a / TWO_PI)
    return a - k * TWO_PI


def dsin(a):
    x = _reduce_angle(a)
    x2 = x * x
    term = x
    s = x
    for n in range(1, 16):
        term = term * (-x2) / ((2 * n) * (2 * n + 1))
        s += term
    return s


def dcos(a):
    x = _reduce_angle(a)
    x2 = x * x
    term = 1.0
    s = 1.0
    for n in range(1, 16):
        term = term * (-x2) / ((2 * n - 1) * (2 * n))
        s += term
    return s


def dist(ax, ay, bx, by):
    dx = ax - bx
    dy = ay - by
    return (dx * dx + dy * dy) ** 0.5


class ShaRng:
    """SHA-256 counter-mode generator: u_k = first 8 bytes of sha256(prefix + str(k)) / 2^64."""

    def __init__(self, seed, domain="world"):
        self.prefix = ("cs498gc-a4c:%s:%d:" % (domain, int(seed))).encode("ascii")
        self.counter = 0

    def u01(self):
        h = hashlib.sha256(self.prefix + str(self.counter).encode("ascii")).digest()
        self.counter += 1
        return int.from_bytes(h[:8], "big") / 18446744073709551616.0

    def uniform(self, a, b):
        return q4(a + (b - a) * self.u01())

    def randint(self, a, b):
        k = a + int(self.u01() * (b - a + 1))
        return b if k > b else k


# ----------------------------------------------------------------------------------------------
# Geometry
# ----------------------------------------------------------------------------------------------
def dist_point_segment(px, py, ax, ay, bx, by):
    vx = bx - ax
    vy = by - ay
    wx = px - ax
    wy = py - ay
    vv = vx * vx + vy * vy
    if vv <= 0.0:
        return dist(px, py, ax, ay)
    t = (wx * vx + wy * vy) / vv
    if t < 0.0:
        t = 0.0
    elif t > 1.0:
        t = 1.0
    return dist(px, py, ax + t * vx, ay + t * vy)


def point_in_polygon(px, py, poly):
    inside = False
    n = len(poly)
    j = n - 1
    for i in range(n):
        xi, yi = poly[i]
        xj, yj = poly[j]
        if (yi > py) != (yj > py):
            xc = xi + (py - yi) * (xj - xi) / (yj - yi)
            if px < xc:
                inside = not inside
        j = i
    return inside


def dist_point_polygon(px, py, poly):
    """0.0 inside the polygon, else distance to its boundary."""
    if point_in_polygon(px, py, poly):
        return 0.0
    best = None
    n = len(poly)
    for i in range(n):
        ax, ay = poly[i]
        bx, by = poly[(i + 1) % n]
        d = dist_point_segment(px, py, ax, ay, bx, by)
        if best is None or d < best:
            best = d
    return best


def dist_point_polyline(px, py, pts):
    best = None
    for i in range(len(pts) - 1):
        d = dist_point_segment(px, py, pts[i][0], pts[i][1], pts[i + 1][0], pts[i + 1][1])
        if best is None or d < best:
            best = d
    return best


def polyline_length(pts):
    s = 0.0
    for i in range(len(pts) - 1):
        s += dist(pts[i][0], pts[i][1], pts[i + 1][0], pts[i + 1][1])
    return s


def rect_polygon(cx, cy, length, width, yaw):
    c = dcos(yaw)
    s = dsin(yaw)
    hl = length / 2.0
    hw = width / 2.0
    pts = []
    for sl, sw in ((1, 1), (-1, 1), (-1, -1), (1, -1)):
        x = cx + sl * hl * c - sw * hw * s
        y = cy + sl * hl * s + sw * hw * c
        pts.append([q4(x), q4(y)])
    return pts


# ----------------------------------------------------------------------------------------------
# Grid A* (shared with the grader: keep the cell and blocking rules stable)
# ----------------------------------------------------------------------------------------------
class Grid:
    """Square grid over [-80, 80]^2. Cell (i, j) has center
    x = -80 + (i + 0.5) * res, y = -80 + (j + 0.5) * res; index = j * n + i."""

    def __init__(self, res):
        self.res = res
        self.n = int(round(2 * HALF_EXTENT / res))
        self.blocked = bytearray(self.n * self.n)

    def center(self, i, j):
        return (-HALF_EXTENT + (i + 0.5) * self.res, -HALF_EXTENT + (j + 0.5) * self.res)

    def cell_of(self, x, y):
        i = int((x + HALF_EXTENT) // self.res)
        j = int((y + HALF_EXTENT) // self.res)
        return min(max(i, 0), self.n - 1), min(max(j, 0), self.n - 1)

    def block_disk(self, x, y, radius):
        """Block every cell whose center lies strictly closer than `radius` to (x, y)."""
        res = self.res
        i0, j0 = self.cell_of(x - radius - res, y - radius - res)
        i1, j1 = self.cell_of(x + radius + res, y + radius + res)
        r2 = radius * radius
        n = self.n
        for j in range(j0, j1 + 1):
            cy = -HALF_EXTENT + (j + 0.5) * res
            dy2 = (cy - y) * (cy - y)
            if dy2 >= r2:
                continue
            row = j * n
            for i in range(i0, i1 + 1):
                cx = -HALF_EXTENT + (i + 0.5) * res
                if (cx - x) * (cx - x) + dy2 < r2:
                    self.blocked[row + i] = 1

    def block_polygon(self, poly, inflate):
        """Block every cell whose center is inside the polygon or closer than `inflate` to it."""
        xs = [p[0] for p in poly]
        ys = [p[1] for p in poly]
        i0, j0 = self.cell_of(min(xs) - inflate - self.res, min(ys) - inflate - self.res)
        i1, j1 = self.cell_of(max(xs) + inflate + self.res, max(ys) + inflate + self.res)
        for j in range(j0, j1 + 1):
            for i in range(i0, i1 + 1):
                cx, cy = self.center(i, j)
                if dist_point_polygon(cx, cy, poly) < inflate:
                    self.blocked[j * self.n + i] = 1

    def astar(self, start_xy, goal_xy, lifo=False):
        """8-connected A*, octile heuristic, no corner cutting (a diagonal step needs both
        orthogonal neighbours free). Ties are broken by insertion order (oldest first; newest
        first with lifo=True, used only for the route family). Returns the list of (i, j) cells
        from the start cell to the goal cell, or None."""
        n = self.n
        si, sj = self.cell_of(*start_xy)
        gi, gj = self.cell_of(*goal_xy)
        s = sj * n + si
        g = gj * n + gi
        blk = self.blocked
        if blk[s] or blk[g]:
            return None
        inf = float("inf")
        gscore = {s: 0.0}
        came = {}
        closed = bytearray(n * n)

        def h(idx):
            i = idx % n
            j = idx // n
            dx = abs(i - gi)
            dy = abs(j - gj)
            return (dx + dy) + (SQRT2 - 2.0) * min(dx, dy)

        counter = 0
        heap = [(h(s), counter, s)]
        steps = ((1, 0, 1.0), (-1, 0, 1.0), (0, 1, 1.0), (0, -1, 1.0),
                 (1, 1, SQRT2), (1, -1, SQRT2), (-1, 1, SQRT2), (-1, -1, SQRT2))
        while heap:
            _f, _c, cur = heapq.heappop(heap)
            if closed[cur]:
                continue
            if cur == g:
                path = [cur]
                while cur in came:
                    cur = came[cur]
                    path.append(cur)
                path.reverse()
                return [(p % n, p // n) for p in path]
            closed[cur] = 1
            ci = cur % n
            cj = cur // n
            gc = gscore[cur]
            for di, dj, cost in steps:
                ni = ci + di
                nj = cj + dj
                if ni < 0 or nj < 0 or ni >= n or nj >= n:
                    continue
                nidx = nj * n + ni
                if blk[nidx] or closed[nidx]:
                    continue
                if di != 0 and dj != 0:
                    if blk[cj * n + ni] or blk[nj * n + ci]:
                        continue
                ng = gc + cost
                if ng < gscore.get(nidx, inf):
                    gscore[nidx] = ng
                    came[nidx] = cur
                    counter += 1
                    heapq.heappush(heap, (ng + h(nidx), -counter if lifo else counter, nidx))
        return None

    def path_polyline(self, cells, start_xy, goal_xy):
        pts = [[start_xy[0], start_xy[1]]]
        for i, j in cells:
            cx, cy = self.center(i, j)
            pts.append([cx, cy])
        pts.append([goal_xy[0], goal_xy[1]])
        return pts


def reference_astar(gt, r_fp=R_FP_REF, inflate_extra=0.1, res=0.5):
    """The orbit-only reference path used by the generator and by grader check AG-10:
    8-connected A* with octile heuristic on a `res` grid of ground-truth boulders and the sand
    polygon, inflated by r_fp + inflate_extra. Rocks are ignored (orbit cannot see them).
    Returns (polyline [[x, y], ...] from S to G, length_m) or (None, None)."""
    grid = Grid(res)
    infl = r_fp + inflate_extra
    for b in gt["boulders"]:
        grid.block_disk(b["x"], b["y"], b["radius"] + infl)
    grid.block_polygon(gt["sand_patch"]["polygon"], infl)
    S = tuple(gt["S"])
    G = tuple(gt["G"])
    cells = grid.astar(S, G)
    if cells is None:
        return None, None
    pts = grid.path_polyline(cells, S, G)
    return pts, polyline_length(pts)


def feasible_astar(gt, r_fp=R_FP_REF, clearance=0.3, margin=0.1, res=0.25):
    """Ground-truth feasibility path: every hazard (boulders, rocks, sand) inflated by
    r_fp + clearance + margin on a `res` grid. Returns (polyline, length_m) or (None, None)."""
    grid = Grid(res)
    infl = r_fp + clearance + margin
    for b in gt["boulders"]:
        grid.block_disk(b["x"], b["y"], b["radius"] + infl)
    for r in gt["rocks"]:
        grid.block_disk(r["x"], r["y"], r["radius"] + infl)
    grid.block_polygon(gt["sand_patch"]["polygon"], infl)
    S = tuple(gt["S"])
    G = tuple(gt["G"])
    cells = grid.astar(S, G)
    if cells is None:
        return None, None
    pts = grid.path_polyline(cells, S, G)
    return pts, polyline_length(pts)


def point_at_arclength(pts, s):
    acc = 0.0
    for i in range(len(pts) - 1):
        seg = dist(pts[i][0], pts[i][1], pts[i + 1][0], pts[i + 1][1])
        if acc + seg >= s and seg > 0:
            t = (s - acc) / seg
            x = pts[i][0] + t * (pts[i + 1][0] - pts[i][0])
            y = pts[i][1] + t * (pts[i + 1][1] - pts[i][1])
            nx = -(pts[i + 1][1] - pts[i][1]) / seg
            ny = (pts[i + 1][0] - pts[i][0]) / seg
            return x, y, nx, ny
        acc += seg
    return pts[-1][0], pts[-1][1], 0.0, 1.0


# ----------------------------------------------------------------------------------------------
# Route family and rock barriers (guarantee (a) must hold for the routes a student's orbit-only
# planner may produce, not only for this file's A* tie-break)
# ----------------------------------------------------------------------------------------------
CORRIDOR_HALF_WIDTH = 1.5     # every on-path field blocks a +-1.5 m corridor around the routes
BARRIER_STEP_M = 1.52         # consecutive barrier rock centres: >= 1.5 m (spacing rule) and
                              # < 2 * (r_fp + 0.35) = 1.60 m, so the footprint-inflated disks touch
BARRIER_MAX_TURN = 0.6        # rad; chain steps deviate at most this much from the cross direction
BARRIER_EDGE_M = 0.8          # the chain reaches to within this distance of the field edge
ROUTE_INFL_DELTAS = (("taut_infl_minus_0.3", -0.3), ("taut_infl_plus_0.3", 0.3))


def _orient(px, py, qx, qy, rx, ry):
    return (qx - px) * (ry - py) - (qy - py) * (rx - px)


def _segments_cross(ax, ay, bx, by, cx, cy, ex, ey):
    o1 = _orient(ax, ay, bx, by, cx, cy)
    o2 = _orient(ax, ay, bx, by, ex, ey)
    o3 = _orient(cx, cy, ex, ey, ax, ay)
    o4 = _orient(cx, cy, ex, ey, bx, by)
    return (o1 > 0.0) != (o2 > 0.0) and (o3 > 0.0) != (o4 > 0.0)


def dist_segment_polygon(ax, ay, bx, by, poly):
    """0.0 if the segment touches or enters the polygon, else the smallest distance."""
    if point_in_polygon(ax, ay, poly) or point_in_polygon(bx, by, poly):
        return 0.0
    best = None
    n = len(poly)
    for i in range(n):
        px, py = poly[i]
        qx, qy = poly[(i + 1) % n]
        if _segments_cross(ax, ay, bx, by, px, py, qx, qy):
            return 0.0
        d = min(dist_point_segment(ax, ay, px, py, qx, qy),
                dist_point_segment(bx, by, px, py, qx, qy),
                dist_point_segment(px, py, ax, ay, bx, by),
                dist_point_segment(qx, qy, ax, ay, bx, by))
        if best is None or d < best:
            best = d
    return best


def _segment_clear(a, b, disks, poly, infl):
    ax, ay = a
    bx, by = b
    x0, x1 = (ax, bx) if ax < bx else (bx, ax)
    y0, y1 = (ay, by) if ay < by else (by, ay)
    for x, y, r in disks:
        if x + r < x0 or x - r > x1 or y + r < y0 or y - r > y1:
            continue
        if dist_point_segment(x, y, ax, ay, bx, by) < r:
            return False
    return dist_segment_polygon(ax, ay, bx, by, poly) >= infl


def string_pull(pts, disks, poly, infl):
    """Greedy shortcutting of a grid path: from each kept vertex jump to the farthest later vertex
    reachable by a straight segment that keeps the inflation clearance (what a path smoother or
    a pure-pursuit follower drives)."""
    out = [pts[0]]
    i = 0
    n = len(pts)
    while i < n - 1:
        k = n - 1
        while k > i + 1 and not _segment_clear(pts[i], pts[k], disks, poly, infl):
            k -= 1
        out.append(pts[k])
        i = k
    return out


def _rock_free_grid(gt, infl, res=0.5):
    grid = Grid(res)
    for b in gt["boulders"]:
        grid.block_disk(b["x"], b["y"], b["radius"] + infl)
    grid.block_polygon(gt["sand_patch"]["polygon"], infl)
    return grid


def _search_costs(grid, start_xy, goal_xy, eps=1e-6):
    """A* from start toward goal (same moves and costs as Grid.astar) that keeps expanding until
    the smallest f in the queue exceeds the optimal cost + eps. With the consistent octile
    heuristic every cell on a shortest path is popped with its exact cost-to-come. Returns
    ({cell index: g}, optimal cost) or (None, None)."""
    n = grid.n
    si, sj = grid.cell_of(*start_xy)
    gi, gj = grid.cell_of(*goal_xy)
    s = sj * n + si
    g = gj * n + gi
    blk = grid.blocked
    if blk[s] or blk[g]:
        return None, None

    def h(idx):
        dx = abs(idx % n - gi)
        dy = abs(idx // n - gj)
        return (dx + dy) + (SQRT2 - 2.0) * min(dx, dy)

    gscore = {s: 0.0}
    popped = {}
    opt = None
    counter = 0
    heap = [(h(s), counter, s)]
    steps = ((1, 0, 1.0), (-1, 0, 1.0), (0, 1, 1.0), (0, -1, 1.0),
             (1, 1, SQRT2), (1, -1, SQRT2), (-1, 1, SQRT2), (-1, -1, SQRT2))
    while heap:
        f, _c, cur = heapq.heappop(heap)
        if cur in popped:
            continue
        if opt is not None and f > opt + eps:
            break
        gc = gscore[cur]
        popped[cur] = gc
        if cur == g and opt is None:
            opt = gc
        ci = cur % n
        cj = cur // n
        for di, dj, cost in steps:
            ni = ci + di
            nj = cj + dj
            if ni < 0 or nj < 0 or ni >= n or nj >= n:
                continue
            nidx = nj * n + ni
            if blk[nidx] or nidx in popped:
                continue
            if di != 0 and dj != 0 and (blk[cj * n + ni] or blk[nj * n + ci]):
                continue
            ng = gc + cost
            if ng < gscore.get(nidx, float("inf")) - 1e-12:
                gscore[nidx] = ng
                counter += 1
                heapq.heappush(heap, (ng + h(nidx), counter, nidx))
    if opt is None:
        return None, None
    return popped, opt


def optimal_cell_centers(grid, S, G, eps=1e-6):
    """Centres of every grid cell that lies on at least one shortest 8-connected path from the
    S cell to the G cell (cost from S + cost to G <= optimal + eps): the region swept by every
    tie-break of every exact A* or Dijkstra on this grid, searched from either end."""
    gs, opt = _search_costs(grid, S, G, eps)
    if gs is None:
        return []
    gg, _opt2 = _search_costs(grid, G, S, eps)
    if gg is None:
        return []
    n = grid.n
    out = []
    for idx in sorted(gs):
        if idx in gg and gs[idx] + gg[idx] <= opt + eps:
            out.append(grid.center(idx % n, idx // n))
    return out


def route_family(gt, r_fp=R_FP_REF):
    """Rock-free S-to-G routes (boulders and sand only, as seen from orbit) that a student's
    orbit-only planner may produce. Guarantee (a) must hold for every member:
      astar_fwd             the reference path (reference_astar, oldest-first tie-break)
      astar_rev             the same A* searched from G to S
      astar_lifo            the same A* with newest-first tie-break
      taut_fwd, taut_rev    the two A* paths string-pulled (smoothed) with the same clearance
      taut_infl_minus_0.3,  A* with inflation r_fp + 0.1 -/+ 0.3 m, string-pulled
      taut_infl_plus_0.3
    Returns ({name: polyline}, optimal cell centres) (a member whose search fails is left out;
    see optimal_cell_centers), or (None, None) if the reference itself does not exist."""
    S = tuple(gt["S"])
    G = tuple(gt["G"])
    poly = gt["sand_patch"]["polygon"]
    infl = r_fp + 0.1
    grid = _rock_free_grid(gt, infl)
    disks = [(b["x"], b["y"], b["radius"] + infl) for b in gt["boulders"]]
    cells = grid.astar(S, G)
    if cells is None:
        return None, None
    fam = {"astar_fwd": grid.path_polyline(cells, S, G)}
    cells = grid.astar(G, S)
    if cells is not None:
        fam["astar_rev"] = list(reversed(grid.path_polyline(cells, G, S)))
    cells = grid.astar(S, G, lifo=True)
    if cells is not None:
        fam["astar_lifo"] = grid.path_polyline(cells, S, G)
    fam["taut_fwd"] = string_pull(fam["astar_fwd"], disks, poly, infl)
    if "astar_rev" in fam:
        fam["taut_rev"] = string_pull(fam["astar_rev"], disks, poly, infl)
    for name, delta in ROUTE_INFL_DELTAS:
        infl2 = infl + delta
        grid2 = _rock_free_grid(gt, infl2)
        cells = grid2.astar(S, G)
        if cells is None:
            continue
        disks2 = [(b["x"], b["y"], b["radius"] + infl2) for b in gt["boulders"]]
        fam[name] = string_pull(grid2.path_polyline(cells, S, G), disks2, poly, infl2)
    return fam, optimal_cell_centers(grid, S, G)


def route_crossings(route, px, py, nx, ny):
    """Lateral offsets lam (along the unit normal n) where the route crosses the straight line
    through (px, py) along n."""
    tx, ty = ny, -nx
    out = []
    for k in range(len(route) - 1):
        ax, ay = route[k]
        bx, by = route[k + 1]
        ta = (ax - px) * tx + (ay - py) * ty
        tb = (bx - px) * tx + (by - py) * ty
        if (ta <= 0.0 < tb) or (tb <= 0.0 < ta):
            u = ta / (ta - tb)
            xx = ax + u * (bx - ax)
            yy = ay + u * (by - ay)
            out.append((xx - px) * nx + (yy - py) * ny)
    return out


def smooth_frame(pts, s, half=3.0, total=None):
    """Point at arclength s plus the unit normal of the chord from s - half to s + half."""
    x, y, nx, ny = point_at_arclength(pts, s)
    total = polyline_length(pts) if total is None else total
    ax, ay, _, _ = point_at_arclength(pts, max(0.0, s - half))
    bx, by, _, _ = point_at_arclength(pts, min(total, s + half))
    d = dist(ax, ay, bx, by)
    if d > 1e-6:
        nx, ny = -(by - ay) / d, (bx - ax) / d
    return x, y, nx, ny


def barrier_chain(rng, lam_a, lam_b):
    """Chain of barrier rock positions (lam, tau) across the corridor: lam lateral, tau along the
    route. Consecutive centres are BARRIER_STEP_M apart, so the r_fp-inflated rock disks overlap
    and any route crossing the chain overlaps at least one barrier rock."""
    pts = [(lam_a, 0.0)]
    lam, tau = lam_a, 0.0
    while lam < lam_b and len(pts) < 21:
        th = rng.uniform(-BARRIER_MAX_TURN, BARRIER_MAX_TURN)
        if (tau > 0.8 and th > 0.0) or (tau < -0.8 and th < 0.0):
            th = -th
        lam += BARRIER_STEP_M * dcos(th)
        tau += BARRIER_STEP_M * dsin(th)
        pts.append((lam, tau))
    return pts


def corridor_cut(ref_pts, field, field_rocks, gt, routes=(), opt_pts=(), r_fp=R_FP_REF,
                 half_width=CORRIDOR_HALF_WIDTH, res=0.1):
    """Grid test that the field blocks the corridor. The corridor ("band") is every point within
    half_width of the reference polyline, of any route in `routes`, or of any shortest-path cell
    centre in `opt_pts` (optimal_cell_centers, inflated by a further 0.36 m, half a cell
    diagonal). In the window of radius (field radius + 3 m) around the field centre, no
    8-connected path (no corner cutting, `res` grid) of band cells may get from where the
    reference enters the window to where it leaves it without a cell centre closer than r_fp + r
    to one of the field's rocks. Boulders (inflated by r_fp) and the sand polygon (r_fp) block
    too. Returns (base_connected_without_rocks, connected_with_rocks); the field cuts the
    corridor when the first is True and the second False."""
    fx, fy, fr = field["x"], field["y"], field["radius"]
    win = fr + 3.0
    inside = [k for k, p in enumerate(ref_pts) if dist(p[0], p[1], fx, fy) <= win - 0.5]
    if not inside:
        return False, False
    k0, k1 = inside[0], inside[-1]
    x0 = fx - win
    y0 = fy - win
    nside = int(2.0 * win / res) + 1
    band = {}

    def mark_segment(a, b, hw):
        i0 = max(0, int((min(a[0], b[0]) - hw - x0) / res) - 1)
        i1 = min(nside - 1, int((max(a[0], b[0]) + hw - x0) / res) + 1)
        j0 = max(0, int((min(a[1], b[1]) - hw - y0) / res) - 1)
        j1 = min(nside - 1, int((max(a[1], b[1]) + hw - y0) / res) + 1)
        for j in range(j0, j1 + 1):
            cy = y0 + (j + 0.5) * res
            for i in range(i0, i1 + 1):
                key = j * nside + i
                if key in band:
                    continue
                cx = x0 + (i + 0.5) * res
                if dist(cx, cy, fx, fy) > win:
                    continue
                if dist_point_segment(cx, cy, a[0], a[1], b[0], b[1]) <= hw:
                    band[key] = (cx, cy)

    for route in [ref_pts] + list(routes):
        for a, b in zip(route, route[1:]):
            if dist_point_segment(fx, fy, a[0], a[1], b[0], b[1]) <= win + half_width:
                mark_segment(a, b, half_width)
    for p in opt_pts:
        if dist(p[0], p[1], fx, fy) <= win + half_width + 0.36:
            mark_segment(p, p, half_width + 0.36)
    near_b = [b for b in gt["boulders"] if dist(b["x"], b["y"], fx, fy) < win + b["radius"] + r_fp]
    poly = gt["sand_patch"]["polygon"]
    sand_near = dist_point_polygon(fx, fy, poly) < win + r_fp
    free = set()
    for key, (cx, cy) in band.items():
        if any(dist(cx, cy, b["x"], b["y"]) < b["radius"] + r_fp for b in near_b):
            continue
        if sand_near and dist_point_polygon(cx, cy, poly) < r_fp:
            continue
        free.add(key)
    rock_free = set(k for k in free
                    if not any(dist(band[k][0], band[k][1], r["x"], r["y"]) < r_fp + r["radius"]
                               for r in field_rocks))
    ex, ey = ref_pts[k0]
    gx, gy = ref_pts[k1]
    src = [k for k in free if dist(band[k][0], band[k][1], ex, ey) <= 0.3]
    dst = set(k for k in free if dist(band[k][0], band[k][1], gx, gy) <= 0.3)

    def connected(cells):
        q = [k for k in src if k in cells]
        seen = set(q)
        while q:
            cur = q.pop()
            if cur in dst:
                return True
            ci = cur % nside
            cj = cur // nside
            for di, dj in ((1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (1, -1), (-1, 1), (-1, -1)):
                ni = ci + di
                nj = cj + dj
                if ni < 0 or nj < 0 or ni >= nside or nj >= nside:
                    continue
                nk = nj * nside + ni
                if nk in seen or nk not in cells:
                    continue
                if di != 0 and dj != 0:
                    if (cj * nside + ni) not in cells or (nj * nside + ci) not in cells:
                        continue
                seen.add(nk)
                q.append(nk)
        return False

    return connected(free), connected(rock_free)


# ----------------------------------------------------------------------------------------------
# One generation attempt
# ----------------------------------------------------------------------------------------------
def _attempt(rng):
    # --- S and G -------------------------------------------------------------------------------
    for _ in range(2000):
        sx, sy = rng.uniform(-65.0, 65.0), rng.uniform(-65.0, 65.0)
        gx, gy = rng.uniform(-65.0, 65.0), rng.uniform(-65.0, 65.0)
        dsg = dist(sx, sy, gx, gy)
        if 100.0 <= dsg <= 120.0:
            break
    else:
        return None, "S-G draw failed"
    ux = (sx - gx) / dsg
    uy = (sy - gy) / dsg
    hx, hy = q4(sx + 3.0 * ux), q4(sy + 3.0 * uy)
    keypts = ((sx, sy), (gx, gy), (hx, hy))

    # --- sand patch ------------------------------------------------------------------------------
    sand = None
    for _ in range(2000):
        length = rng.uniform(15.0, 25.0)
        width = rng.uniform(8.0, 12.0)
        yaw = rng.uniform(0.0, PI)
        cx = rng.uniform(-70.0, 70.0)
        cy = rng.uniform(-70.0, 70.0)
        dseg = dist_point_segment(cx, cy, sx, sy, gx, gy)
        if not (15.0 <= dseg <= 40.0):
            continue
        if min(dist(cx, cy, px, py) for px, py in keypts) < 15.0:
            continue
        poly = rect_polygon(cx, cy, length, width, yaw)
        if any(abs(v[0]) > 76.0 or abs(v[1]) > 76.0 for v in poly):
            continue
        if min(dist_point_polygon(px, py, poly) for px, py in keypts) < 5.0:
            continue
        sand = {"center": [cx, cy], "length": length, "width": width, "yaw": yaw,
                "polygon": poly}
        break
    if sand is None:
        return None, "sand placement failed"
    poly = sand["polygon"]

    # --- boulders --------------------------------------------------------------------------------
    n_boulders = rng.randint(25, 40)
    boulders = []
    draws = 0
    while len(boulders) < n_boulders and draws < 6000:
        draws += 1
        diameter = rng.uniform(2.5, 4.0)
        r = q4(diameter / 2.0)
        h = rng.uniform(1.0, 2.0)
        x = rng.uniform(-77.0, 77.0)
        y = rng.uniform(-77.0, 77.0)
        yaw = rng.uniform(0.0, TWO_PI)
        if abs(x) + r > 79.0 or abs(y) + r > 79.0:
            continue
        if min(dist(x, y, px, py) for px, py in keypts) - r < 6.0:
            continue
        if dist_point_polygon(x, y, poly) - r < 3.0:
            continue
        ok = True
        for b in boulders:
            if dist(x, y, b["x"], b["y"]) - r - b["radius"] < 3.0:
                ok = False
                break
        if not ok:
            continue
        boulders.append({"id": "B%02d" % len(boulders), "type": "boulder", "x": x, "y": y,
                         "radius": r, "height": h, "yaw": yaw})
    if len(boulders) < n_boulders:
        return None, "boulder placement failed"

    gt = {"S": [sx, sy], "G": [gx, gy], "helipad": [hx, hy], "sand_patch": sand,
          "boulders": boulders, "rocks": []}

    # --- orbit-only reference path and the route family ------------------------------------------
    ref_pts, ref_len = reference_astar(gt)
    if ref_pts is None:
        return None, "no orbit-only reference path"
    family, opt_pts = route_family(gt)
    if family is None:
        return None, "no orbit-only route family"
    # bucket the shortest-path cell centres (2 m buckets) for cross-section queries
    opt_buckets = {}
    for p in opt_pts:
        opt_buckets.setdefault((int(p[0] // 2.0), int(p[1] // 2.0)), []).append(p)

    def opt_lateral(px, py, nx, ny, reach):
        """Lateral offsets of shortest-path cells within 0.5 m of the cross-section line."""
        tx, ty = ny, -nx
        out = []
        b0 = int((px - reach) // 2.0)
        b1 = int((px + reach) // 2.0)
        c0 = int((py - reach) // 2.0)
        c1 = int((py + reach) // 2.0)
        for bi in range(b0, b1 + 1):
            for bj in range(c0, c1 + 1):
                for qx, qy in opt_buckets.get((bi, bj), ()):
                    if abs((qx - px) * tx + (qy - py) * ty) <= 0.5:
                        out.append((qx - px) * nx + (qy - py) * ny)
        return out

    # --- rock fields -----------------------------------------------------------------------------
    n_fields = rng.randint(3, 5)
    fields = []

    def field_ok(fx, fy, fr):
        if abs(fx) + fr > 77.0 or abs(fy) + fr > 77.0:
            return False
        if min(dist(fx, fy, px, py) for px, py in keypts) - fr < 10.0:
            return False
        if dist_point_polygon(fx, fy, poly) - fr < 1.0:
            return False
        for f in fields:
            if dist(fx, fy, f["x"], f["y"]) - fr - f["radius"] < 1.0:
                return False
        return True

    def rock_site_ok(x, y, r):
        if abs(x) > 78.0 or abs(y) > 78.0:
            return False
        if dist_point_polygon(x, y, poly) - r < 1.0:
            return False
        for b in boulders:
            if dist(x, y, b["x"], b["y"]) - r - b["radius"] < 1.0:
                return False
        return True

    roles = ["on_path", "on_path", "distractor"] + ["any"] * (n_fields - 3)
    barriers = {}
    for role in roles:
        placed = False
        for _ in range(600 if role == "on_path" else 3000):
            fr = rng.uniform(5.0, 7.0)
            barrier = None
            if role == "on_path":
                # Cross-section of the corridor at arclength s of the reference path: every
                # route of the family must cross it near the field, and a chain of rocks spans
                # all those crossings plus +-1.5 m (and most of the field's width).
                s = rng.uniform(0.15, 0.85) * ref_len
                px, py, nx, ny = smooth_frame(ref_pts, s, total=ref_len)
                lams = []
                for name in sorted(family):
                    cr = route_crossings(family[name], px, py, nx, ny)
                    if not cr:
                        lams = None
                        break
                    lams.append(min(cr, key=abs))
                if lams is None:
                    continue
                # every shortest grid path crosses this line inside the optimal-cell band
                opt_l = opt_lateral(px, py, nx, ny, 16.0)
                if not opt_l or max(abs(v) for v in opt_l) > 14.0:
                    continue
                lams.extend((min(opt_l), max(opt_l)))
                need_lo = min(lams) - CORRIDOR_HALF_WIDTH
                need_hi = max(lams) + CORRIDOR_HALF_WIDTH
                off = q4(max(-1.5, min(1.5, 0.5 * (need_lo + need_hi))))
                fx, fy = q4(px + off * nx), q4(py + off * ny)
                if dist_point_polyline(fx, fy, ref_pts) > 2.0:
                    continue
                lam_a = min(need_lo, off - (fr - BARRIER_EDGE_M))
                lam_b = max(need_hi, off + (fr - BARRIER_EDGE_M))
                chain = barrier_chain(rng, lam_a, lam_b)
                if chain[-1][0] < lam_b or len(chain) > 20:
                    continue
                barrier = []
                for lam, tau in chain:
                    bx = q4(px + lam * nx + tau * ny)
                    by = q4(py + lam * ny - tau * nx)
                    barrier.append((bx, by))
                # inside the field disk, and away from boulders, sand and the world edge
                # (checked with the largest barrier rock radius, 0.45 m)
                if any(dist(bx, by, fx, fy) > fr for bx, by in barrier):
                    continue
                if not all(rock_site_ok(bx, by, 0.45) for bx, by in barrier):
                    continue
            else:
                fx, fy = rng.uniform(-70.0, 70.0), rng.uniform(-70.0, 70.0)
                if role == "distractor" and dist_point_polyline(fx, fy, ref_pts) < 15.0:
                    continue
            if not field_ok(fx, fy, fr):
                continue
            fid = "F%d" % len(fields)
            fields.append({"id": fid, "x": fx, "y": fy, "radius": fr,
                           "role": role,
                           "dist_to_reference_path_m": q4(dist_point_polyline(fx, fy, ref_pts))})
            if barrier is not None:
                barriers[fid] = barrier
            placed = True
            break
        if not placed:
            return None, "rock field placement failed (%s)" % role

    rocks = []
    for k, f in enumerate(fields):
        n_rocks = rng.randint(12, 20)
        placed = 0
        # Barrier rocks first (diameter 0.70-0.90 m so consecutive inflated disks overlap)
        chain = barriers.get(f["id"], [])
        if len(chain) > n_rocks:
            n_rocks = len(chain)
        barrier_ids = []
        for x, y in chain:
            d = rng.uniform(0.70, 0.90)
            r = q4(d / 2.0)
            h = rng.uniform(0.35, 0.60)
            yaw = rng.uniform(0.0, TWO_PI)
            if any(dist(x, y, o["x"], o["y"]) < 1.5 for o in rocks):
                return None, "barrier rock spacing failed in %s" % f["id"]
            rid = "R%d-%02d" % (k, placed)
            rocks.append({"id": rid, "type": "rock", "field": f["id"],
                          "x": x, "y": y, "radius": r, "height": h, "yaw": yaw})
            barrier_ids.append(rid)
            placed += 1
        if barrier_ids:
            f["barrier_rocks"] = barrier_ids
        tries = 0
        while placed < n_rocks and tries < 4000:
            tries += 1
            rad = f["radius"] * (rng.u01() ** 0.5)
            th = rng.uniform(0.0, TWO_PI)
            x = q4(f["x"] + rad * dcos(th))
            y = q4(f["y"] + rad * dsin(th))
            d = rng.uniform(0.4, 0.9)
            r = q4(d / 2.0)
            h = rng.uniform(0.35, 0.60)
            yaw = rng.uniform(0.0, TWO_PI)
            if abs(x) > 78.0 or abs(y) > 78.0:
                continue
            if dist_point_polygon(x, y, poly) - r < 1.0:
                continue
            ok = True
            for b in boulders:
                if dist(x, y, b["x"], b["y"]) - r - b["radius"] < 1.0:
                    ok = False
                    break
            if ok:
                for o in rocks:
                    if dist(x, y, o["x"], o["y"]) < 1.5:
                        ok = False
                        break
            if not ok:
                continue
            rocks.append({"id": "R%d-%02d" % (k, placed), "type": "rock", "field": f["id"],
                          "x": x, "y": y, "radius": r, "height": h, "yaw": yaw})
            placed += 1
        if placed < n_rocks:
            return None, "rock placement failed in %s" % f["id"]
    gt["rocks"] = rocks
    gt["rock_fields"] = fields

    # --- guarantees ------------------------------------------------------------------------------
    # (a) every route of the family overlaps >= 3 rocks with its r_fp footprint (checking only
    #     the reference let other equally short routes miss every rock).
    family_out = {}
    for name in sorted(family):
        route = family[name]
        ids = [r["id"] for r in rocks
               if dist_point_polyline(r["x"], r["y"], route) < R_FP_REF + r["radius"]]
        if len(ids) < 3:
            return None, "guarantee (a) failed: route %s overlaps only %d rocks" % (name, len(ids))
        family_out[name] = {"length_m": q4(polyline_length(route)), "rocks_overlapped": ids}
    blocking = family_out["astar_fwd"]["rocks_overlapped"]
    # (a2) each on-path field alone blocks a +-1.5 m corridor around the reference path
    cut = {}
    for f in fields:
        if f["role"] != "on_path":
            continue
        base_ok, through = corridor_cut(ref_pts, f, [r for r in rocks if r["field"] == f["id"]],
                                        gt, routes=[family[k] for k in sorted(family)],
                                        opt_pts=opt_pts)
        if not base_ok or through:
            return None, "guarantee (a2) failed: %s does not cut the corridor" % f["id"]
        cut[f["id"]] = True
    feas_pts, feas_len = feasible_astar(gt)
    if feas_pts is None:
        return None, "guarantee (b) failed: no feasible path with 0.3 m clearance"
    if feas_len > 1.6 * ref_len:
        return None, "guarantee (b) failed: feasible path %.1f m > 1.6 x %.1f m" % (feas_len, ref_len)

    gt["route_family"] = {
        "definition": "rock-free S-to-G routes on boulders and sand (what an orbit-only planner "
                      "may produce): astar_fwd = reference path; astar_rev = same A* searched "
                      "G to S; astar_lifo = newest-first tie-break; taut_* = string-pulled with "
                      "the same clearance; taut_infl_minus_0.3 / taut_infl_plus_0.3 = A* with "
                      "inflation r_fp + 0.1 -/+ 0.3 m, string-pulled. Guarantee (a): every member "
                      "overlaps >= 3 rocks (centre distance < r_fp + rock radius, r_fp = 0.45).",
        "routes": family_out,
    }
    gt["corridor_cut"] = {
        "definition": "each on-path field alone blocks every path that stays within 1.5 m of "
                      "the reference path, of any route_family member, or of any cell that lies "
                      "on a shortest 8-connected path of the reference grid (any tie-break, "
                      "either search direction); tested on a 0.1 m grid, 8-connected, no corner "
                      "cutting, rock disks inflated by r_fp = 0.45 m, in a window of radius "
                      "field radius + 3 m. A route that crosses a field's barrier chain overlaps "
                      "at least one of its rocks (barrier_rocks: consecutive centres 1.52 m "
                      "apart, rock radius >= 0.35 m).",
        "half_width_m": CORRIDOR_HALF_WIDTH,
        "shortest_path_cells": len(opt_pts),
        "fields": cut,
    }

    gt["reference_path"] = {
        "definition": "8-connected A*, octile heuristic, no corner cutting, 0.5 m grid, "
                      "boulders and sand inflated by r_fp + 0.1 m, r_fp = 0.45",
        "r_fp_m": R_FP_REF, "grid_resolution_m": 0.5, "inflation_m": q4(R_FP_REF + 0.1),
        "length_m": q4(ref_len),
        "polyline": [[q4(p[0]), q4(p[1])] for p in ref_pts],
        "rocks_overlapping_reference_footprint": blocking,
    }
    gt["feasible_path"] = {
        "definition": "8-connected A*, 0.25 m grid, all hazards inflated by r_fp + 0.3 + 0.1 m",
        "length_m": q4(feas_len),
        "ratio_to_reference": q4(feas_len / ref_len),
    }
    return gt, "ok"


def generate(seed):
    """Return (sdf_text, gt_dict, attempts_used). Raises RuntimeError after MAX_ATTEMPTS."""
    rng = ShaRng(seed, "world")
    reasons = []
    for attempt in range(1, MAX_ATTEMPTS + 1):
        gt, why = _attempt(rng)
        if gt is None:
            reasons.append(why)
            continue
        gt_out = {
            "generator": "gen_option_c_world.py",
            "generator_version": GENERATOR_VERSION,
            "seed": int(seed),
            "attempts": attempt,
            "world_name": WORLD_NAME,
            "frame": "map (= Gazebo world frame, x east, y north, z up)",
            "world_extent_m": [-HALF_EXTENT, HALF_EXTENT],
            "S": gt["S"], "G": gt["G"], "helipad": gt["helipad"],
            "boulders": gt["boulders"], "rocks": gt["rocks"], "rock_fields": gt["rock_fields"],
            "sand_patch": gt["sand_patch"],
            "hazards": [dict(x=h["x"], y=h["y"], radius=h["radius"], height=h["height"],
                             type=h["type"], id=h["id"]) for h in gt["boulders"] + gt["rocks"]],
            "reference_path": gt["reference_path"],
            "feasible_path": gt["feasible_path"],
            "route_family": gt["route_family"],
            "corridor_cut": gt["corridor_cut"],
        }
        sdf = world_sdf(seed, gt_out)
        gt_out["sdf_sha256"] = hashlib.sha256(sdf.encode("utf-8")).hexdigest()
        return sdf, gt_out, attempt
    raise RuntimeError("seed %s: no valid world after %d attempts; last reasons: %s"
                       % (seed, MAX_ATTEMPTS, reasons[-5:]))


# ----------------------------------------------------------------------------------------------
# SDF writer
# ----------------------------------------------------------------------------------------------
BOULDER_RGB = "0.22 0.17 0.15"
ROCK_RGB = "0.40 0.29 0.23"
SAND_RGB = "0.90 0.79 0.60"
HELIPAD_RGB = "0.55 0.53 0.50"


def _hazard_model(name, h, rgb):
    r = h["radius"]
    hh = h["height"]
    return (
        '    <model name="%s">\n'
        '      <static>true</static>\n'
        '      <pose>%s %s 0.0000 0 0 %s</pose>\n'
        '      <link name="link">\n'
        '        <collision name="collision">\n'
        '          <pose>0 0 %s 0 0 0</pose>\n'
        '          <geometry><cylinder><radius>%s</radius><length>%s</length></cylinder></geometry>\n'
        '        </collision>\n'
        '        <visual name="visual">\n'
        '          <geometry><ellipsoid><radii>%s %s %s</radii></ellipsoid></geometry>\n'
        '          <material><ambient>%s 1</ambient><diffuse>%s 1</diffuse>'
        '<specular>0.02 0.02 0.02 1</specular></material>\n'
        '        </visual>\n'
        '      </link>\n'
        '    </model>\n'
    ) % (name, f4(h["x"]), f4(h["y"]), f4(h["yaw"]), f4(hh / 2.0), f4(r), f4(hh),
         f4(0.95 * r), f4(0.85 * r), f4(hh), rgb, rgb)


def world_sdf(seed, gt):
    out = []
    out.append('<?xml version="1.0" ?>\n')
    out.append('<!-- CS 498 GC / ABE 426 A4 Extra Credit Option C world, seed %d.\n'
               '     Generated by gen_option_c_world.py v%s. Do not edit: the grader regenerates this\n'
               '     file from the seed and compares its sha256 (world_sha256 in /option_c/run_info). -->\n'
               % (int(seed), GENERATOR_VERSION))
    out.append('<sdf version="1.10">\n')
    out.append('  <world name="%s">\n' % WORLD_NAME)
    out.append('    <gravity>0 0 -3.711</gravity>\n')
    out.append('    <physics name="4ms" type="ignored">\n'
               '      <max_step_size>0.004</max_step_size>\n'
               '      <real_time_factor>1.0</real_time_factor>\n'
               '    </physics>\n')
    out.append('    <plugin filename="gz-sim-physics-system" name="gz::sim::systems::Physics"/>\n'
               '    <plugin filename="gz-sim-scene-broadcaster-system" name="gz::sim::systems::SceneBroadcaster"/>\n'
               '    <plugin filename="gz-sim-user-commands-system" name="gz::sim::systems::UserCommands"/>\n'
               '    <plugin filename="gz-sim-sensors-system" name="gz::sim::systems::Sensors">\n'
               '      <render_engine>ogre2</render_engine>\n'
               '    </plugin>\n')
    out.append('    <scene>\n'
               '      <ambient>0.35 0.30 0.28 1</ambient>\n'
               '      <background>0.05 0.04 0.04 1</background>\n'
               '      <shadows>true</shadows>\n'
               '    </scene>\n')
    # Sun: 35 deg elevation, from the south-west (light travels toward the north-east).
    out.append('    <light type="directional" name="sun">\n'
               '      <cast_shadows>true</cast_shadows>\n'
               '      <pose>-60 -60 120 0 0 0</pose>\n'
               '      <diffuse>1.0 0.96 0.90 1</diffuse>\n'
               '      <specular>0.10 0.10 0.10 1</specular>\n'
               '      <direction>0.579228 0.579228 -0.573576</direction>\n'
               '    </light>\n')
    out.append('    <include>\n      <uri>model://mars_ground</uri>\n      <name>mars_ground</name>\n'
               '      <pose>0 0 0 0 0 0</pose>\n    </include>\n')
    out.append('    <include>\n      <uri>model://option_c_orbiter</uri>\n      <name>orbiter</name>\n'
               '      <pose>0 0 6000 0 1.5707963 1.5707963</pose>\n    </include>\n')
    hx, hy = gt["helipad"]
    out.append('    <model name="helipad">\n'
               '      <static>true</static>\n'
               '      <pose>%s %s 0 0 0 0</pose>\n'
               '      <link name="link">\n'
               '        <visual name="pad">\n'
               '          <pose>0 0 0.006 0 0 0</pose>\n'
               '          <cast_shadows>false</cast_shadows>\n'
               '          <geometry><cylinder><radius>1.0</radius><length>0.01</length></cylinder></geometry>\n'
               '          <material><ambient>%s 1</ambient><diffuse>%s 1</diffuse></material>\n'
               '        </visual>\n'
               '      </link>\n'
               '    </model>\n' % (f4(hx), f4(hy), HELIPAD_RGB, HELIPAD_RGB))
    sp = gt["sand_patch"]
    out.append('    <model name="sand_patch">\n'
               '      <static>true</static>\n'
               '      <pose>%s %s 0 0 0 %s</pose>\n'
               '      <link name="link">\n'
               '        <visual name="sand">\n'
               '          <pose>0 0 0.008 0 0 0</pose>\n'
               '          <cast_shadows>false</cast_shadows>\n'
               '          <geometry><box><size>%s %s 0.01</size></box></geometry>\n'
               '          <material><ambient>%s 1</ambient><diffuse>%s 1</diffuse>'
               '<specular>0 0 0 1</specular></material>\n'
               '        </visual>\n'
               '      </link>\n'
               '    </model>\n' % (f4(sp["center"][0]), f4(sp["center"][1]), f4(sp["yaw"]),
                                   f4(sp["length"]), f4(sp["width"]), SAND_RGB, SAND_RGB))
    for b in gt["boulders"]:
        out.append(_hazard_model("boulder_%s" % b["id"][1:], b, BOULDER_RGB))
    for r in gt["rocks"]:
        out.append(_hazard_model("rock_%s" % r["id"][1:].replace("-", "_"), r, ROCK_RGB))
    out.append('  </world>\n</sdf>\n')
    return "".join(out)


# ----------------------------------------------------------------------------------------------
# Files
# ----------------------------------------------------------------------------------------------
def default_out_dir():
    env = os.environ.get("OPTION_C_WORK_DIR")
    if env:
        return Path(env)
    return Path.home() / ".ros" / "cs498gc_option_c"


def world_paths(seed, out_dir):
    out_dir = Path(out_dir)
    return (out_dir / "worlds" / "generated" / ("mars_scout_seed_%d.sdf" % int(seed)),
            out_dir / "ground_truth" / ("hazards_seed_%d.json" % int(seed)))


def gt_json_text(gt):
    return json.dumps(gt, sort_keys=True, indent=1) + "\n"


def write_world(seed, out_dir=None):
    """Generate and write both files; returns (sdf_path, json_path, sdf_sha256)."""
    out_dir = default_out_dir() if out_dir is None else Path(out_dir)
    sdf, gt, _ = generate(seed)
    sdf_path, gt_path = world_paths(seed, out_dir)
    sdf_path.parent.mkdir(parents=True, exist_ok=True)
    gt_path.parent.mkdir(parents=True, exist_ok=True)
    data = sdf.encode("utf-8")
    sdf_path.write_bytes(data)
    gt_path.write_text(gt_json_text(gt), encoding="utf-8")
    return sdf_path, gt_path, hashlib.sha256(data).hexdigest()


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--seed", type=int, required=True)
    ap.add_argument("--out-dir", default=None,
                    help="default $OPTION_C_WORK_DIR or ~/.ros/cs498gc_option_c")
    ap.add_argument("--print-sha256", action="store_true",
                    help="print only the SDF sha256 on stdout")
    ap.add_argument("--no-write", action="store_true",
                    help="generate in memory only (with --print-sha256)")
    a = ap.parse_args(argv)
    try:
        if a.no_write:
            sdf, gt, attempts = generate(a.seed)
            sha = hashlib.sha256(sdf.encode("utf-8")).hexdigest()
            print(sha if a.print_sha256 else json.dumps({"seed": a.seed, "sdf_sha256": sha,
                                                         "attempts": attempts}))
            return 0
        sdf_path, gt_path, sha = write_world(a.seed, a.out_dir)
    except RuntimeError as e:
        print("gen_option_c_world: ERROR: %s" % e, file=sys.stderr)
        return 2
    if a.print_sha256:
        print(sha)
    else:
        print(json.dumps({"seed": a.seed, "sdf": str(sdf_path), "ground_truth": str(gt_path),
                          "sdf_sha256": sha}, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())
