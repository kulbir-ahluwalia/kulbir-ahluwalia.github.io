#!/usr/bin/env python3
"""local_check.py: run the CS 498 GC A4 Option C autograder checks on your own machine (no ROS needed).

This is the grader's own check code (tools/option_c_grading/, byte-identical to the Gradescope autograder):
every AG check runs against worlds regenerated from your seeds, prints what it measured, what is required and
how to fix a failure, and writes results.json (the Gradescope format) and metrics.json (the recomputed
comparison-table metrics).

Usage:
  python3 tools/local_check.py --stage M0 --bag bags/seed7_orbit_scout [--seed 7]
  python3 tools/local_check.py --submission ~/option_c                 (all checks, = M5)
  python3 tools/local_check.py --submission ~/option_c --stage M1      (only the checks of milestones <= M1)
  python3 tools/local_check.py --print-config ~/option_c/config/option_c.yaml
  ros2 run cs498gc_a4_option_c_starter local_check ...

Options:
  --stage M0..M5     M0 = bring-up criteria on one bag (--bag; an orbit_only bag is checked for no flight
                     instead of the hover and landing criteria); M1..M5 = autograder checks up to that milestone
                     (M1 orbital map, A* and orbit-only drive; M2 sorties; M3 mosaic and detections;
                     M4 fusion and hand-off; M5 comparison table and the bonus)
  --netid NETID      NetID for the seeds (default: netid in config/option_c.yaml). Gradescope uses the local
                     part of your account email instead, so make sure they agree.
  --out-dir DIR      where results.json and metrics.json go (default ./local_check_out)
  --json PATH        also write the full results JSON to PATH
  --reader rosbags|stdlib   bag reader (default: rosbags if installed, else the standard-library reader)

Requirements: Python >= 3.10, numpy, PyYAML and Pillow (Ubuntu: sudo apt install python3-numpy python3-yaml
python3-pil; they come with ROS 2 Jazzy desktop). rosbags is optional (pip install rosbags==0.11.5).
Exit code: 0 = every scored check passed (M0: every criterion), 1 = something failed, 2 = usage error.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
_ENV = os.environ.get("OPTION_C_GRADING_DIR")
for cand in ([Path(_ENV)] if _ENV else []) + [HERE]:
    if (cand / "option_c_grading" / "__init__.py").is_file():
        sys.path.insert(0, str(cand))
        break
else:  # pragma: no cover
    print("local_check: cannot find tools/option_c_grading/ next to this file (%s).\n"
          "Run it from the starter source instead: python3 <starter source>/tools/local_check.py ...,\n"
          "rebuild the starter with colcon build, or set OPTION_C_GRADING_DIR=<starter source>/tools."
          % HERE, file=sys.stderr)
    sys.exit(2)

from option_c_grading.submission import (config_netid_seeds, parse_config,  # noqa: E402,F401
                                         src_tree_sha256)

LOCAL_CHECK_VERSION = "1.0.1"


def seeds_for(netid):
    """Same formula as tools/option_c_seed.py and the grader (option_c_grading.groundtruth.seeds_for)."""
    import hashlib
    nid = netid.strip().lower()
    return [int(hashlib.sha256(("cs498gc-a4c:" + nid + ":" + str(k)).encode()).hexdigest()[:8], 16) for k in range(3)]
MILESTONES = ("M0", "M1", "M2", "M3", "M4", "M5")


# ---------------------------------------------------------------------------------------------- compatibility
# Names kept from the starter's partial local_check (test/test_tools_unit.py imports them).
def _lazy(name):
    def f(*a, **k):
        if name in ("rate_hz", "stamps_in", "interval_rates"):
            from option_c_grading import analysis
            return getattr(analysis, name)(*a, **k)
        from option_c_grading import cdr
        return getattr(cdr, name)(*a, **k)
    f.__name__ = name
    return f


dec_string = _lazy("dec_string")
dec_bool = _lazy("dec_bool")
dec_clock = _lazy("dec_clock")
dec_twist = _lazy("dec_twist")
dec_header = _lazy("dec_header")
dec_odom = _lazy("dec_odom")
dec_caminfo = _lazy("dec_caminfo")
dec_posearray_count = _lazy("dec_posearray_count")
rate_hz = _lazy("rate_hz")
stamps_in = _lazy("stamps_in")
interval_rates = _lazy("interval_rates")


# ---------------------------------------------------------------------------------------------- main
def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0], formatter_class=argparse.RawDescriptionHelpFormatter,
                                 epilog=__doc__.split("\n", 2)[2])
    ap.add_argument("--stage", default=None, choices=MILESTONES)
    ap.add_argument("--bag", default=None, help="(M0) one bag folder")
    ap.add_argument("--seed", type=int, default=None, help="(M0) the seed the bag must carry")
    ap.add_argument("--submission", default=None, help="your option_c folder (or a folder that contains it)")
    ap.add_argument("--netid", default=None)
    ap.add_argument("--out-dir", default="local_check_out")
    ap.add_argument("--json", default=None)
    ap.add_argument("--reader", default=None, choices=("rosbags", "stdlib"))
    ap.add_argument("--print-config", default=None, metavar="CFG")
    a = ap.parse_args(argv)

    if a.print_config:
        try:
            netid, seeds = config_netid_seeds(a.print_config)
        except OSError as exc:
            print("cannot read %s (%s)" % (a.print_config, exc), file=sys.stderr)
            return 2
        print(json.dumps({"netid": netid, "seeds": seeds}))
        return 0

    if a.stage == "M0":
        if not a.bag:
            print("--stage M0 needs --bag <bag folder>", file=sys.stderr)
            return 2
        from option_c_grading import runner
        print("local_check.py %s (stage M0, python %s)" % (LOCAL_CHECK_VERSION, sys.version.split()[0]))
        items = runner.check_m0(a.bag, a.seed, a.reader)
        scope = Path(a.bag).name
        for status, label, msg in items:
            print("  [%s] M0     (%s) %s" % (status, scope, msg))
        fails = sum(1 for st, _l, _m in items if st == "FAIL")
        print("local_check: %d check(s) failed" % fails)
        if a.json:
            Path(a.json).write_text(json.dumps({"stage": "M0", "bag": scope, "items": [
                {"status": s, "label": l, "message": m} for s, l, m in items]}, indent=2))
        return 1 if fails else 0

    if not a.submission:
        ap.print_help()
        return 2
    sub = Path(a.submission).expanduser().resolve()
    if not sub.is_dir():
        print("no such folder: %s" % sub, file=sys.stderr)
        return 2
    from option_c_grading import runner
    stage = a.stage or "M5"
    print("local_check.py %s (stage %s, python %s)" % (LOCAL_CHECK_VERSION, stage, sys.version.split()[0]))
    with tempfile.TemporaryDirectory(prefix="option_c_local_check_") as tmp:
        res = runner.grade(sub, Path(tmp) / "work", None, stage, True, a.netid, None, a.reader)
        roots = [sub, Path(tmp)]
        runner.print_report(res, roots)
        data = runner.results_dict(res, roots)
    out = Path(a.out_dir)
    runner.write_json(out / "results.json", data)
    runner.write_json(out / "metrics.json", {"stage": stage, "metrics": runner.metrics_rows(res["ctx"]),
                                             "integrity_flags": res["ctx"].flags})
    if a.json:
        runner.write_json(Path(a.json), data)
    scored = [o for o in res["outcomes"] if o.max_score > 0]
    earned = sum(o.score for o in scored)
    avail = sum(sum(e.points for e in o.elements) for o in scored)
    failed = [o.test_id for o in scored if sum(e.points for e in o.elements) - o.score > 1e-6]
    print("=" * 78)
    print("local_check: %.2f of the %.2f automated points checked at stage %s; %s" % (
        earned, avail, stage, ("failing: " + ", ".join(failed)) if failed else "every checked item passed"))
    if res["ctx"].flags:
        print("local_check: %d integrity flag(s) for TA review (see AG-26): %s" % (
            len(res["ctx"].flags), ", ".join(sorted({f["code"] for f in res["ctx"].flags}))))
    print("local_check: wrote %s and %s" % (out / "results.json", out / "metrics.json"))
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
