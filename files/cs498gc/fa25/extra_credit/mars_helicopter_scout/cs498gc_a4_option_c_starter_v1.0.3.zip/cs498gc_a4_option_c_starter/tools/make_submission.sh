#!/usr/bin/env bash
# make_submission.sh: check and zip a CS 498 GC A4 Option C submission.
#
#   make_submission.sh <path/to/option_c> [output_dir]
#
# <path/to/option_c> is the folder named option_c (see HANDOUT.md, Deliverables). Writes
# <output_dir>/<netid>_a4_option_c.zip (default output_dir: the parent of option_c) after checking:
#   * the required files and folders exist (README.md, PROVENANCE.md, report.pdf, video_link.txt,
#     config/option_c.yaml, src/option_c_scout/package.xml, six bag folders named from the seeds,
#     results/seed<s>/... and results/comparison_table.csv)
#   * config/option_c.yaml has netid and seeds that match option_c_seed.py for that netid
#   * every bag folder has metadata.yaml and at least one .db3 file, and is <= 25 MB
#   * no bag contains an image topic or raw /clock (metadata.yaml scan)
#   * the zip is <= 150 MB
# Missing optional items (bonus_drift/) are reported, not fatal. Exit 0 = zip written and all
# required checks passed; exit 1 = problems listed (the zip is still written unless --strict).
set -u
case "${1:-}" in
  -h|--help)
    # print the header comment above (without the leading '# ') as the help text
    sed -n '2,/^set -u$/p' "${BASH_SOURCE[0]}" | sed '$d' | sed 's/^# \{0,1\}//'
    echo "options: --strict  exit 1 and write no zip when a required check fails"
    exit 0 ;;
esac
STRICT=0
if [ "${1:-}" = "--strict" ]; then STRICT=1; shift; fi
if [ $# -lt 1 ] || [ $# -gt 2 ]; then
  echo "usage: make_submission [--strict] <path/to/option_c> [output_dir]   (make_submission --help for details)" >&2; exit 2
fi
[ -d "$1" ] || { echo "no such folder: $1" >&2; exit 2; }
ROOT=$(cd "$1" && pwd) || { echo "cannot enter folder: $1" >&2; exit 2; }
OUTDIR=${2:-$(dirname "$ROOT")}
HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
PROBLEMS=0
problem() { echo "  PROBLEM: $*"; PROBLEMS=$((PROBLEMS + 1)); }
ok() { echo "  ok: $*"; }

[ "$(basename "$ROOT")" = "option_c" ] || problem "the folder should be named option_c (is $(basename "$ROOT"))"

echo "[make_submission] checking $ROOT"
for f in README.md PROVENANCE.md report.pdf video_link.txt config/option_c.yaml src/option_c_scout/package.xml results/comparison_table.csv results/ablation.csv; do
  if [ -f "$ROOT/$f" ]; then ok "$f"; else problem "missing $f"; fi
done
[ -d "$ROOT/results/analysis" ] && ok "results/analysis/" || problem "missing results/analysis/"

# netid and seeds from config/option_c.yaml, read by the same parser as local_check AG-01
# (PyYAML when installed, else a stdlib parser that accepts 'seeds: [a, b, c]' and block lists),
# so the two tools always agree.
CFG_JSON=$(python3 "$HERE/local_check.py" --print-config "$ROOT/config/option_c.yaml" 2>/dev/null)
NETID=$(printf '%s' "$CFG_JSON" | python3 -c 'import json,sys
try: print(json.load(sys.stdin)["netid"])
except Exception: print("")' 2>/dev/null)
SEEDS_CFG=$(printf '%s' "$CFG_JSON" | python3 -c 'import json,sys
try: print(" ".join(str(s) for s in json.load(sys.stdin)["seeds"]))
except Exception: print("")' 2>/dev/null)
if [ -z "$NETID" ] || [ "$NETID" = "yournetid" ]; then
  problem "config/option_c.yaml has no real netid"; NETID=unknown
fi
SEEDS_TRUE=$(python3 "$HERE/option_c_seed.py" --netid "$NETID" --json 2>/dev/null | python3 -c 'import json,sys; print(" ".join(str(s) for s in json.load(sys.stdin)["seeds"]))' 2>/dev/null)
if [ "$SEEDS_CFG" = "$SEEDS_TRUE" ]; then ok "seeds $SEEDS_CFG match netid $NETID"; else problem "seeds in config ($SEEDS_CFG) differ from option_c_seed.py --netid $NETID ($SEEDS_TRUE)"; fi

for s in $SEEDS_TRUE; do
  for c in orbit_only orbit_scout; do
    B="$ROOT/bags/seed${s}_${c}"
    if [ ! -d "$B" ]; then problem "missing bag folder bags/seed${s}_${c}"; continue; fi
    [ -f "$B/metadata.yaml" ] || problem "bags/seed${s}_${c}: no metadata.yaml"
    ls "$B"/*.db3 >/dev/null 2>&1 || problem "bags/seed${s}_${c}: no .db3 (record with -s sqlite3)"
    BYTES=$(du -sb "$B" | cut -f1)
    if [ "$BYTES" -gt 25000000 ]; then problem "bags/seed${s}_${c} is $BYTES bytes (> 25 MB)"; else ok "bags/seed${s}_${c} ($BYTES bytes)"; fi
    if grep -qE 'name: (/clock|.*/image)$' "$B/metadata.yaml" 2>/dev/null; then problem "bags/seed${s}_${c} contains an image topic or raw /clock"; fi
  done
  for f in orbital_bev.png orbital_hazards.csv orbital_sand_polygon.json scout_mosaic.png scout_mosaic.json scout_hazards.csv; do
    [ -f "$ROOT/results/seed${s}/$f" ] || problem "missing results/seed${s}/$f"
  done
done
[ -d "$ROOT/bonus_drift" ] && ok "bonus_drift/ present" || echo "  note: no bonus_drift/ (optional)"

# ---------------------------------------------------------------------------------------------
# HOOK: tools/local_check.py runs the grader's own check code (tools/option_c_grading/, the same
# files as the Gradescope autograder) on the folder: every AG check, including the bag integrity
# checks AG-01 to AG-06, so a bag with the wrong seed, condition or world is caught here.
# ---------------------------------------------------------------------------------------------
if [ -f "$HERE/local_check.py" ]; then
  echo "[make_submission] running local_check.py --submission ..."
  python3 "$HERE/local_check.py" --submission "$ROOT" || problem "local_check.py reported failures (see the FAIL lines above)"
else
  problem "tools/local_check.py is missing from this starter install"
fi

mkdir -p "$OUTDIR"
ZIP="$OUTDIR/${NETID}_a4_option_c.zip"
if [ "$STRICT" = 1 ] && [ "$PROBLEMS" -gt 0 ]; then
  echo "[make_submission] $PROBLEMS problem(s); --strict: no zip written"; exit 1
fi
rm -f "$ZIP"
python3 - "$ROOT" "$ZIP" <<'EOF'
import os, sys, zipfile
root, out = sys.argv[1], sys.argv[2]
skip = {"__pycache__", "build", "install", "log", ".git"}
parent = os.path.dirname(root)
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
    for d, dirs, files in os.walk(root):
        dirs[:] = sorted(x for x in dirs if x not in skip)
        for f in sorted(files):
            if f.endswith(".pyc"):
                continue
            p = os.path.join(d, f)
            z.write(p, os.path.relpath(p, parent))
EOF
ZB=$(stat -c %s "$ZIP" 2>/dev/null || stat -f %z "$ZIP")
if [ "$ZB" -gt 150000000 ]; then problem "zip is $ZB bytes (> 150 MB)"; fi
echo "[make_submission] wrote $ZIP ($ZB bytes); problems: $PROBLEMS"
[ "$PROBLEMS" -eq 0 ]
