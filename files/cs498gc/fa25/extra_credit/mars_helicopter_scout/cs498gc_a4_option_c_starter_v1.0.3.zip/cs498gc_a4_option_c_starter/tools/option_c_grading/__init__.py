"""Shared grading code of CS 498 GC / ABE 426 A4 Extra Credit Option C (Mars Helicopter Scout).

The same package runs in two places, byte for byte:
  * the Gradescope autograder (a4_ec_mars_helicopter/option_c_grading/, called by run_tests.py), and
  * the students' starter package (cs498gc_a4_option_c_starter/tools/option_c_grading/, called by
    tools/local_check.py).
The autograder build refuses to package if the two copies differ.

It never executes student code and never needs ROS. Bags (rosbag2, sqlite3 storage) are read with the
pinned rosbags library when it is installed, otherwise with the standard-library CDR reader in cdr.py
(devtests check that both give identical decoded data). Ground truth is regenerated in memory from the
seed with gen_option_c_world.py, which sits next to this package in both layouts.

Modules:
  util        helpers, result model (Element / Outcome), settings (spec + policy defaults + overrides)
  cdr         standard-library rosbag2 sqlite3 reader and CDR decoders (fallback reader)
  bagio       one streaming pass over a bag folder into compact numpy arrays (BagData)
  geometry    disks, polygon, polylines, rays, quaternions, grids
  groundtruth regenerated worlds (SDF sha256, hazards, reference A*)
  submission  layout discovery, safe archive extraction, config, NetID, src hash, source scan
  analysis    per-bag derived quantities (time base, phases, sorties, footprint union, drive metrics)
  checks      AG-01 .. AG-26 and AG-B1
  runner      grade a submission (all checks or one milestone), the M0 bring-up check, rendering
"""

GRADER_ID = "a4_ec_mars_helicopter"
GRADER_VERSION = "1.0.1"
