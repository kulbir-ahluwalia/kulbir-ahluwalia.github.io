"""Per-bag derived quantities shared by the checks and the metrics table."""
from __future__ import annotations

import json
import math
from dataclasses import dataclass, field

import numpy as np

from . import bagio as B
from . import geometry as geo


# ---------------------------------------------------------------------------------------------- rates
def rate_hz(stamps) -> float:
    s = np.sort(np.asarray(list(stamps), dtype=np.float64))
    if len(s) < 2 or s[-1] <= s[0]:
        return 0.0
    return float((len(s) - 1) / (s[-1] - s[0]))


def stamps_in(intervals, stamps):
    s = np.asarray(list(stamps), dtype=np.float64)
    keep = np.zeros(len(s), dtype=bool)
    for a, b in intervals:
        keep |= (s >= a) & (s <= b)
    return list(s[keep])


def interval_rates(intervals, stamps, min_dur: float = 5.0):
    """Rate pooled over the intervals, sum(n_i - 1) / sum(span_i) with n_i stamps inside interval i and span_i
    the time between its first and last stamp (ground time never counts), plus [(interval, hz)] for every
    interval of at least min_dur s."""
    s = np.sort(np.asarray(list(stamps), dtype=np.float64))
    num, den = 0.0, 0.0
    per = []
    for a, b in intervals:
        inside = s[(s >= a) & (s <= b)]
        if len(inside) >= 2 and inside[-1] > inside[0]:
            num += len(inside) - 1
            den += inside[-1] - inside[0]
        if b - a >= min_dur:
            hz = (len(inside) - 1) / (inside[-1] - inside[0]) if len(inside) >= 2 and inside[-1] > inside[0] else 0.0
            per.append(((a, b), float(hz)))
    return (float(num / den) if den > 0 else 0.0), per


# ---------------------------------------------------------------------------------------------- time base
class TimeBase:
    """Receive time (bag timestamp, s) -> sim time through /option_c/clock_20hz pairs; slope 1 outside."""

    def __init__(self, rx: np.ndarray, sim: np.ndarray):
        self.rx = np.asarray(rx, dtype=np.float64)
        self.simv = np.asarray(sim, dtype=np.float64)
        self.ok = len(self.rx) >= 2

    def sim(self, t_rx):
        t = np.asarray(t_rx, dtype=np.float64)
        if not self.ok:
            if len(self.rx) == 1:
                return t - self.rx[0] + self.simv[0]
            return t.copy()
        out = np.interp(t, self.rx, self.simv)
        lo = t < self.rx[0]
        hi = t > self.rx[-1]
        out = np.where(lo, self.simv[0] - (self.rx[0] - t), out)
        out = np.where(hi, self.simv[-1] + (t - self.rx[-1]), out)
        return out

    def span(self) -> float:
        if len(self.simv) < 2:
            return 0.0
        return float(np.max(self.simv) - np.min(self.simv))


# ---------------------------------------------------------------------------------------------- sorties
@dataclass
class Sortie:
    k: int
    i0: int
    i1: int
    t_takeoff: float
    t_land: float
    landed: bool
    t_touchdown: float | None = None
    landing_xy: tuple | None = None

    @property
    def duration(self) -> float:
        return self.t_land - self.t_takeoff


@dataclass
class Phase:
    event: str
    t_sim: float | None
    t_rx: float
    t: float              # effective time (t_sim if within tolerance of the receive time, else the receive time)
    agrees: bool
    extras: dict = field(default_factory=dict)


class BagAnalysis:
    def __init__(self, bd: B.BagData, settings, world=None, r_fp: float = 0.45, condition: str = ""):
        self.bd = bd
        self.s = settings
        self.world = world
        self.r_fp = float(r_fp)
        self.condition = condition
        self.tb = TimeBase(bd.clock_rx if bd.clock_rx is not None else [], bd.clock_sim if bd.clock_sim is not None else [])
        self.tol_event = float(settings.th("AG-05")["event_tsim_tol_s"])
        self._phases = None
        self._sorties = None
        self._union = {}
        self._drive = None
        self.run_info = self._first_run_info()

    # ------------------------------------------------------------------ basics
    def _first_run_info(self):
        for _rx, text in self.bd.strings.get(B.T_RUN_INFO, []):
            try:
                d = json.loads(text)
                if isinstance(d, dict):
                    return d
            except ValueError:
                continue
        return None

    def sim_of(self, rx):
        return self.tb.sim(rx)

    def phases(self) -> list:
        if self._phases is None:
            out = []
            for rx, text in self.bd.strings.get(B.T_PHASE, []):
                t_rx = float(self.tb.sim(rx))
                try:
                    d = json.loads(text)
                except ValueError:
                    continue
                if not isinstance(d, dict) or "event" not in d:
                    continue
                ts = d.get("t_sim")
                try:
                    ts = float(ts) if ts is not None else None
                    if ts is not None and not math.isfinite(ts):
                        ts = None
                except (TypeError, ValueError):
                    ts = None
                agrees = ts is not None and abs(ts - t_rx) <= self.tol_event
                extras = {k: v for k, v in d.items() if k not in ("event", "t_sim")}
                out.append(Phase(str(d.get("event")), ts, t_rx, ts if agrees else t_rx, agrees, extras))
            out.sort(key=lambda p: p.t_rx)
            self._phases = out
        return self._phases

    def history_note(self) -> str:
        """'' or a short note on messages re-timed from transient_local history (bagio.retime_history)."""
        h = {k: v for k, v in (self.bd.history or {}).items() if not str(k).startswith("_")}
        if not h:
            return ""
        return "; ".join("%d %s message%s arrived as transient_local history up to %.1f s late (timed by their own stamps)"
                         % (v["n"], k, "" if v["n"] == 1 else "s", v["max_age_s"]) for k, v in sorted(h.items()))

    def recording_hint(self) -> str:
        """'' or an explanation when the bag lacks the first mission events: the recorder started after the
        mission, or the mission_phase publisher is volatile and sent them before rosbag2 subscribed."""
        ph = self.phases()
        names = {p.event for p in ph}
        missing = []
        if "orbital_plan_ready" not in names:
            missing.append("orbital_plan_ready")
        drove = bool(names & {"rover_goal_reached", "rover_aborted"}) or self.bd.count(B.T_ACTIVE) > 0
        if "rover_start" not in names and drove:
            missing.append("rover_start")
        if not missing or (not ph and not drove):
            return ""
        parts = ["the bag has no %s" % " and no ".join(missing)]
        if ph:
            p0 = ph[0]
            parts.append("its first mission_phase event is %s at t_sim %s s" % (
                p0.event, "%.1f" % p0.t_sim if p0.t_sim is not None else "?"))
        else:
            parts.append("it has no mission_phase message although the rover drove")
        if self.tb.simv is not None and len(self.tb.simv):
            parts.append("its clock starts at sim t %.1f s" % float(self.tb.simv[0]))
        dur = self.bd.durability.get(B.T_PHASE)
        if dur:
            parts.append("your mission_phase publisher offered %s durability" % "/".join(dur))
        if dur == ["transient_local"]:
            cause = ("the recorder joined after more events than your publisher's history depth keeps, or the "
                     "events were never published")
        else:
            cause = ("events published before rosbag2 subscribed were lost, because the recorder started after the "
                     "mission or a volatile publisher sent them in the 1 to 3 s rosbag2 needs to discover a new node")
        return ("%s. Likely cause: %s. Fix: start record_option_c_bag first, wait for its READY line, then launch "
                "the mission, and publish /option_c/mission_phase (depth >= 100) and /option_c/rover/active_path "
                "(depth >= 20) reliable + transient_local (TOPICS.md, Durability)" % ("; ".join(parts), cause))

    def phase(self, event: str, after: float | None = None, last: bool = False, before: float | None = None):
        cands = [p for p in self.phases() if p.event == event
                 and (after is None or p.t >= after - 1e-9) and (before is None or p.t <= before + 1e-9)]
        if not cands:
            return None
        return cands[-1] if last else cands[0]

    def events(self):
        out = []
        for rx, text in self.bd.strings.get(B.T_WD, []):
            try:
                d = json.loads(text)
            except ValueError:
                continue
            if isinstance(d, dict):
                ts = d.get("t_sim")
                try:
                    ts = float(ts)
                except (TypeError, ValueError):
                    ts = None
                out.append((float(self.tb.sim(rx)), ts, str(d.get("event", ""))))
        return out

    # ------------------------------------------------------------------ scout
    def scout(self):
        return self.bd.odoms.get(B.T_SCOUT)

    def scout_hspeed(self) -> np.ndarray:
        sc = self.scout()
        if sc is None or len(sc["t"]) == 0:
            return np.zeros(0)
        t, x, y = sc["t"], sc["x"], sc["y"]
        n = len(t)
        v = np.zeros(n)
        if n < 2:
            return v
        gap = float(self.s.timebase("max_odom_gap_s", 0.25))
        dt_f = np.diff(t)
        dp = np.hypot(np.diff(x), np.diff(y))
        with np.errstate(divide="ignore", invalid="ignore"):
            sp = np.where(dt_f > 1e-9, dp / dt_f, 0.0)
        okf = dt_f <= gap
        # central difference where both neighbours are close, else one-sided
        fwd = np.append(np.where(okf, sp, np.nan), np.nan)
        bwd = np.insert(np.where(okf, sp, np.nan), 0, np.nan)
        both = ~np.isnan(fwd) & ~np.isnan(bwd)
        with np.errstate(invalid="ignore"):
            cen = np.zeros(n)
            if n >= 3:
                dtc = t[2:] - t[:-2]
                dpc = np.hypot(x[2:] - x[:-2], y[2:] - y[:-2])
                cen[1:-1] = np.where(dtc > 1e-9, dpc / np.where(dtc > 1e-9, dtc, 1.0), 0.0)
        v = np.where(both, cen, np.where(~np.isnan(fwd), fwd, np.where(~np.isnan(bwd), bwd, 0.0)))
        return np.nan_to_num(v)

    def sorties(self) -> list:
        if self._sorties is not None:
            return self._sorties
        out = []
        sc = self.scout()
        if sc is not None and len(sc["t"]):
            t, z = sc["t"], sc["z"]
            zair = float(self.s.world("airborne_z_m"))
            ztd = float(self.s.world("touchdown_z_m"))
            gap = float(self.s.timebase("crossing_interp_max_gap_s", 0.25))
            above = z > zair
            n = len(t)
            i = 0
            k = 0
            while i < n:
                if not above[i]:
                    i += 1
                    continue
                a = i
                while i + 1 < n and above[i + 1]:
                    i += 1
                b = i
                t0 = float(t[a])
                if a > 0 and t[a] - t[a - 1] <= gap and z[a] != z[a - 1]:
                    t0 = float(t[a - 1] + (zair - z[a - 1]) * (t[a] - t[a - 1]) / (z[a] - z[a - 1]))
                landed = b < n - 1
                t1 = float(t[b])
                if landed and t[b + 1] - t[b] <= gap and z[b] != z[b + 1]:
                    t1 = float(t[b] + (zair - z[b]) * (t[b + 1] - t[b]) / (z[b + 1] - z[b]))
                s = Sortie(k, a, b, t0, t1, landed)
                if landed:
                    td = np.nonzero((np.arange(n) > b) & (z < ztd))[0]
                    if len(td):
                        t_td = float(t[td[0]])
                        win = (t >= t_td) & (t <= t_td + 2.0)
                        s.t_touchdown = t_td
                        s.landing_xy = (float(np.median(sc["x"][win])), float(np.median(sc["y"][win])))
                out.append(s)
                k += 1
                i += 1
        self._sorties = out
        return out

    def airborne_intervals(self):
        return [(s.t_takeoff, s.t_land) for s in self.sorties()]

    def last_touchdown(self) -> float | None:
        ss = self.sorties()
        if not ss:
            return None
        return ss[-1].t_land

    def scout_rest_xy(self):
        """Where the scout sits for the rover drive: landing site of the last sortie, else its last pose."""
        ss = self.sorties()
        if ss and ss[-1].landing_xy is not None:
            return ss[-1].landing_xy
        sc = self.scout()
        if sc is None or len(sc["t"]) == 0:
            return None
        return (float(sc["x"][-1]), float(sc["y"][-1]))

    def scout_track_length(self) -> float:
        sc = self.scout()
        total = 0.0
        if sc is None:
            return 0.0
        for s in self.sorties():
            xy = np.stack([sc["x"][s.i0:s.i1 + 1], sc["y"][s.i0:s.i1 + 1]], axis=1)
            total += geo.polyline_length(xy)
        return total

    def scout_pose_at(self, tq: np.ndarray, max_gap: float):
        """Interpolated (pos (N, 3), quat (N, 4), ok (N,)) of the grader scout odometry."""
        sc = self.scout()
        tq = np.asarray(tq, dtype=np.float64)
        n = len(tq)
        pos = np.zeros((n, 3))
        qq = np.zeros((n, 4))
        qq[:, 3] = 1.0
        ok = np.zeros(n, dtype=bool)
        if sc is None or len(sc["t"]) < 2:
            return pos, qq, ok
        t = sc["t"]
        j = np.searchsorted(t, tq, side="right")
        j0 = np.clip(j - 1, 0, len(t) - 1)
        j1 = np.clip(j, 0, len(t) - 1)
        exact = np.abs(t[j0] - tq) < 1e-6
        valid = (j > 0) & (j < len(t)) & ((t[j1] - t[j0]) <= max_gap) | exact
        dt = np.where(t[j1] - t[j0] > 1e-9, t[j1] - t[j0], 1.0)
        f = np.clip((tq - t[j0]) / dt, 0.0, 1.0)
        f = np.where(exact, 0.0, f)
        P0 = np.stack([sc["x"][j0], sc["y"][j0], sc["z"][j0]], axis=1)
        P1 = np.stack([sc["x"][j1], sc["y"][j1], sc["z"][j1]], axis=1)
        pos = P0 + f[:, None] * (P1 - P0)
        Q0 = np.stack([sc["qx"][j0], sc["qy"][j0], sc["qz"][j0], sc["qw"][j0]], axis=1)
        Q1 = np.stack([sc["qx"][j1], sc["qy"][j1], sc["qz"][j1], sc["qw"][j1]], axis=1)
        qq = geo.slerp(Q0, Q1, f)
        return pos, qq, valid

    # ------------------------------------------------------------------ footprint union (AG-19)
    def footprint_union(self, z_lo: float, z_hi: float):
        """(union bool grid [j, i] on the 0.25 m grid over [-80, 80]^2, frames used, frames total)."""
        key = (round(z_lo, 3), round(z_hi, 3))
        if key in self._union:
            return self._union[key]
        g = self.s.grid("union")
        res, W, H = float(g["resolution_m"]), int(g["width"]), int(g["height"])
        ox, oy = float(g["origin_xy"][0]), float(g["origin_xy"][1])
        U = np.zeros((H, W), dtype=bool)
        ci = self.bd.caminfos.get(B.T_NADIR)
        used = 0
        total = 0 if ci is None else len(ci["t"])
        if ci is not None and total:
            from PIL import Image, ImageDraw
            mount = self.s.camera("nadir_mount")
            off = np.array(mount["xyz"], dtype=np.float64)
            pos, q, ok = self.scout_pose_at(ci["t"], float(self.s.th("AG-19")["max_pose_gap_s"]))
            z = pos[:, 2]
            sel = ok & (z >= z_lo) & (z <= z_hi)
            img = Image.new("L", (W, H), 0)
            draw = ImageDraw.Draw(img)
            for idx in np.nonzero(sel)[0]:
                k = ci["k"][idx]
                fx, cx, fy, cy = k[0], k[2], k[4], k[5]
                w, h = ci["w"][idx], ci["h"][idx]
                if fx <= 0 or fy <= 0 or w <= 0 or h <= 0:
                    continue
                corners = np.array([[0.0, 0.0], [w, 0.0], [w, h], [0.0, h]])
                u, v = corners[:, 0], corners[:, 1]
                d = np.stack([-(v - cy) / fy, -(u - cx) / fx, -np.ones(4)], axis=1)
                Rq = np.repeat(q[idx][None, :], 4, axis=0)
                dw = geo.quat_rotate(Rq, d)
                o = pos[idx] + geo.quat_rotate(q[idx][None, :], off[None, :])[0]
                if np.any(dw[:, 2] >= -1e-6):
                    continue
                sgr = -o[2] / dw[:, 2]
                if np.any(sgr <= 0) or np.any(sgr > 1000.0):
                    continue
                gp = o[None, :2] + sgr[:, None] * dw[:, :2]
                pix = [((gx - ox) / res - 0.5, (gy - oy) / res - 0.5) for gx, gy in gp]
                draw.polygon(pix, fill=1, outline=1)
                used += 1
            U = np.asarray(img, dtype=np.uint8) > 0
        self._union[key] = (U, used, total)
        return self._union[key]

    def union_main(self):
        th = self.s.th("AG-19")
        return self.footprint_union(float(th["z_lo_m"]), float(th["z_hi_m"]))

    def union_grid(self) -> geo.GridSpec:
        g = self.s.grid("union")
        return geo.GridSpec(float(g["resolution_m"]), int(g["width"]), int(g["height"]),
                            float(g["origin_xy"][0]), float(g["origin_xy"][1]))

    def in_union(self, U: np.ndarray, P: np.ndarray) -> np.ndarray:
        gs = self.union_grid()
        i, j, inside = gs.cell(P)
        out = np.zeros(len(i), dtype=bool)
        out[inside] = U[j[inside], i[inside]]
        return out

    def disks_inside_union(self, U: np.ndarray, hz: geo.Hazards) -> np.ndarray:
        out = np.zeros(len(hz.r), dtype=bool)
        for k in range(len(hz.r)):
            pts = geo.disk_sample_points(hz.xy[k, 0], hz.xy[k, 1], hz.r[k])
            out[k] = bool(np.all(self.in_union(U, pts)))
        return out

    @staticmethod
    def dilate(U: np.ndarray, cells: int) -> np.ndarray:
        if cells <= 0:
            return U.copy()
        out = U.copy()
        H, W = U.shape
        for dj in range(-cells, cells + 1):
            for di in range(-cells, cells + 1):
                if di * di + dj * dj > cells * cells:
                    continue
                src = U[max(0, -dj):H - max(0, dj), max(0, -di):W - max(0, di)]
                out[max(0, dj):H - max(0, -dj), max(0, di):W - max(0, -di)] |= src
        return out

    def area_m2(self, U: np.ndarray) -> float:
        res = float(self.s.grid("union")["resolution_m"])
        return float(U.sum()) * res * res

    # ------------------------------------------------------------------ rover
    def rover(self):
        return self.bd.odoms.get(B.T_ROVER)

    def rover_xy_at(self, tq: float):
        r = self.rover()
        if r is None or len(r["t"]) == 0:
            return None
        k = int(np.clip(np.searchsorted(r["t"], tq), 0, len(r["t"]) - 1))
        cands = [k]
        if k > 0:
            cands.append(k - 1)
        best = min(cands, key=lambda i: abs(r["t"][i] - tq))
        if abs(r["t"][best] - tq) > 2.0:
            return None
        return (float(r["x"][best]), float(r["y"][best]))

    def rover_max_speed(self) -> float:
        r = self.rover()
        if r is None or len(r["t"]) < 2:
            return 0.0
        win = float(self.s.th("AG-11")["speed_window_s"])
        t, x, y = r["t"], r["x"], r["y"]
        j = np.searchsorted(t, t + win)
        ok = j < len(t)
        if not np.any(ok):
            return 0.0
        i = np.nonzero(ok)[0]
        jj = j[ok]
        dt = t[jj] - t[i]
        good = (dt > 1e-6) & (dt <= 2.0 * win + 0.5)
        if not np.any(good):
            return 0.0
        sp = np.hypot(x[jj] - x[i], y[jj] - y[i])[good] / dt[good]
        return float(np.max(sp))

    def drive_hazards(self) -> geo.Hazards:
        hz = self.world.hazards
        if self.condition == "orbit_scout":
            xy = self.scout_rest_xy()
            if xy is not None:
                hz = hz.with_disk(xy[0], xy[1], float(self.s.world("landed_scout_radius_m")), "scout", "landed_scout")
        return hz

    def drive(self) -> dict:
        """Drive window, track and per-run metrics (memoized)."""
        if self._drive is not None:
            return self._drive
        d: dict = {"ok": False}
        rs = self.phase("rover_start")
        r = self.rover()
        d["rover_start"] = rs
        if rs is None or r is None or len(r["t"]) == 0:
            self._drive = d
            return d
        limit = float(self.s.world("drive_limit_s"))
        t0 = rs.t
        endp = None
        for p in self.phases():
            if p.event in ("rover_goal_reached", "rover_aborted") and p.t >= t0 - 1e-9:
                endp = p
                break
        t_end = endp.t if endp is not None else min(float(r["t"][-1]), t0 + limit)
        d.update(ok=True, t_start=t0, t_end=t_end, end_phase=endp)
        sel = (r["t"] >= t0) & (r["t"] <= t_end)
        tt, xx, yy = r["t"][sel], r["x"][sel], r["y"][sel]
        d["t"], d["xy"] = tt, np.stack([xx, yy], axis=1)
        G = self.world.G
        win = (r["t"] >= t0) & (r["t"] <= t0 + limit)
        dg = np.hypot(r["x"][win] - G[0], r["y"][win] - G[1])
        tol = float(self.s.world("goal_tolerance_m"))
        d["reached_goal"] = bool(np.any(dg <= tol))
        d["min_goal_dist"] = float(np.min(dg)) if len(dg) else None
        hz = self.drive_hazards()
        d["hazards"] = hz
        # intrusions: per hazard cumulative overlap time
        cap = float(self.s.timebase("intrusion_dt_cap_s", 0.5))
        if len(tt):
            dt = np.append(np.diff(tt), 0.1)
            dt = np.clip(dt, 0.0, cap)
            P = d["xy"]
            overlap_t = np.zeros(len(hz.r) + 1)
            min_clear = np.inf
            step = max(1, geo.CHUNK // max(1, len(hz.r)))
            for s in range(0, len(P), step):
                Q = P[s:s + step]
                E = geo.disk_edge_distances(Q, hz) - self.r_fp
                if E.size:
                    overlap_t[:-1] += ((E < 0.0) * dt[s:s + step, None]).sum(axis=0)
                    min_clear = min(min_clear, float(np.min(E)))
                sd = geo.polygon_signed_distance(Q, hz.poly) - self.r_fp
                overlap_t[-1] += float(((sd < 0.0) * dt[s:s + step]).sum())
                min_clear = min(min_clear, float(np.min(sd)))
            thr = float(self.s.th("AG-14")["intrusion_min_s"])
            hit = overlap_t >= thr - 1e-9
            names = list(hz.ids) + ["sand_patch"]
            d["intrusion_ids"] = [names[k] for k in np.nonzero(hit)[0]]
            d["intrusions"] = int(hit.sum())
            d["min_clearance_m"] = float(min_clear)
            dec = geo.decimate_track(P, float(self.s.timebase("track_decimate_m", 0.05)))
            d["track_decimated"] = dec
            d["executed_length_m"] = geo.polyline_length(dec)
        else:
            d.update(intrusion_ids=[], intrusions=0, min_clearance_m=None, executed_length_m=0.0,
                     track_decimated=np.zeros((0, 2)))
        # hazard stops (rising edges) in the window
        stops = 0
        if B.T_STOP in self.bd.bools:
            rx, val = self.bd.bools[B.T_STOP]
            ts = self.tb.sim(rx)
            prev = False
            for t_, v_ in zip(ts, val):
                if v_ and not prev and t0 - 1e-9 <= t_ <= t_end + 1e-9:
                    stops += 1
                prev = bool(v_)
        d["hazard_stops"] = stops
        # active paths after rover_start
        slack = float(self.s.timebase("rover_start_slack_s", 1.0))
        ap = [p for p in self.bd.paths.get(B.T_ACTIVE, []) if float(self.tb.sim(p["rx"])) >= t0 - slack]
        d["active_paths"] = ap
        d["replans"] = max(0, len(ap) - 1)
        d["planned_length_m"] = geo.polyline_length(ap[0]["xyz"][:, :2]) if ap else None
        d["drive_time_s"] = float(t_end - t0)
        orp = self.phase("orbital_plan_ready")
        d["total_mission_s"] = float(t_end - orp.t) if orp is not None else None
        self._drive = d
        return d

    def start_costmap(self):
        """The costmap the drive started with: orbital (O) or fused (S), last received before rover_start."""
        topic = B.T_FUSED_GRID if self.condition == "orbit_scout" else B.T_ORB_GRID
        grids = self.bd.grids.get(topic, [])
        rs = self.phase("rover_start")
        if rs is None:
            return grids[-1] if grids else None
        before = [g for g in grids if float(self.tb.sim(g["rx"])) <= rs.t + 0.5]
        return before[-1] if before else None

    def hazcam_surprises(self) -> int | None:
        d = self.drive()
        if not d.get("ok"):
            return None
        rocks = self.world.rocks
        if len(rocks.r) == 0 or not self.bd.hazcam:
            return 0
        t0, t1 = d["t_start"], d["t_end"]
        seen = np.zeros(len(rocks.r), dtype=bool)
        for t, rx, xy in self.bd.hazcam:
            tt = t if t > 0 else float(self.tb.sim(rx))
            if tt < t0 - 1e-9 or tt > t1 + 1e-9 or len(xy) == 0:
                continue
            D = np.sqrt(((xy[:, None, :] - rocks.xy[None, :, :]) ** 2).sum(axis=2))
            k = np.argmin(D, axis=1)
            m = D[np.arange(len(xy)), k] <= 0.3
            seen[k[m]] = True
        grid = self.start_costmap()
        lethal = np.zeros(len(rocks.r), dtype=bool)
        if grid is not None:
            lethal = geo.grid_values(grid, rocks.xy) >= self.s.lethal()
        return int(np.sum(seen & ~lethal))

    # ------------------------------------------------------------------ metrics row
    def metrics(self) -> dict:
        d = self.drive()
        cond = self.condition
        row = {"seed": self.world.seed if self.world is not None else None, "condition": cond}
        if d.get("ok"):
            row.update(reached_goal=d["reached_goal"], intrusions=d["intrusions"], hazard_stops=d["hazard_stops"],
                       hazcam_surprises=self.hazcam_surprises(), replans=d["replans"],
                       min_clearance_m=d["min_clearance_m"], planned_length_m=d["planned_length_m"],
                       executed_length_m=d["executed_length_m"],
                       detour_ratio=(d["executed_length_m"] / self.world.sg_distance()) if self.world else None,
                       drive_time_s=d["drive_time_s"], total_mission_s=d["total_mission_s"])
        else:
            for k in ("reached_goal", "intrusions", "hazard_stops", "hazcam_surprises", "replans", "min_clearance_m",
                      "planned_length_m", "executed_length_m", "detour_ratio", "drive_time_s", "total_mission_s"):
                row[k] = None
        ss = self.sorties()
        air = float(sum(s.duration for s in ss))
        row["sorties"] = len(ss)
        row["airborne_s"] = air
        row["scout_track_m"] = self.scout_track_length()
        row["energy_proxy_wh"] = air * float(self.s.world("energy_power_w")) / 3600.0
        if cond == "orbit_scout":
            U, _used, _tot = self.union_main()
            row["scouted_area_m2"] = self.area_m2(U)
            row["scouted_path_fraction"] = self.scouted_path_fraction(U) if d.get("ok") else None
        else:
            row["scouted_area_m2"] = 0.0
            row["scouted_path_fraction"] = 0.0
        return row

    def scouted_path_fraction(self, U: np.ndarray):
        d = self.drive()
        dec = d.get("track_decimated")
        if dec is None or len(dec) < 2:
            return None
        total, inside = 0.0, 0.0
        for a, b in zip(dec[:-1], dec[1:]):
            seg = float(np.hypot(*(b - a)))
            if seg <= 0:
                continue
            mid = 0.5 * (a + b)
            pts = geo.disk_sample_points(mid[0], mid[1], self.r_fp)
            total += seg
            if bool(np.all(self.in_union(U, pts))):
                inside += seg
        return inside / total if total > 0 else None
