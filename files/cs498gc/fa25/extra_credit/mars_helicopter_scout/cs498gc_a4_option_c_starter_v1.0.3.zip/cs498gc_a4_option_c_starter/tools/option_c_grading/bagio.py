"""One streaming pass over a rosbag2 folder into compact arrays (BagData).

Reader preference: the pinned `rosbags` library (Gradescope; also used by students who installed it),
else the standard-library sqlite3 + CDR reader in cdr.py. Both feed the same normalize step, so the
checks see identical data (devtests/test_reader_equivalence.py). Image topics are never decoded.
"""
from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

from . import cdr

T_CLOCK = "/option_c/clock_20hz"
T_RUN_INFO = "/option_c/run_info"
T_PHASE = "/option_c/mission_phase"
T_WD = "/option_c/scout/watchdog_events"
T_SCOUT = "/option_c/grader/scout_odom"
T_ROVER = "/option_c/rover/odom_truth"
T_NADIR = "/ingenuity/nadir_cam/camera_info"
T_ORB_CI = "/orbiter/bev_cam/camera_info"
T_CMD_TWIST = "/ingenuity/gazebo/command/twist"
T_SCOUT_CMD = "/option_c/scout/cmd_vel"
T_ENABLE = "/ingenuity/enable"
T_REQ = "/option_c/rover/cmd_vel_request"
T_RCMD = "/option_c/rover/cmd_vel"
T_HAZCAM = "/option_c/rover/hazcam"
T_STOP = "/option_c/rover/hazard_stop"
T_ACTIVE = "/option_c/rover/active_path"
T_ORB_GRID = "/option_c/orbital_costmap"
T_ORB_PATH = "/option_c/orbital_path"
T_FUSED_GRID = "/option_c/fused_costmap"
T_FUSED_PATH = "/option_c/fused_path"
T_PLAN = "/option_c/sortie_plan"
T_ODOM_EST = "/ingenuity/odom_est"
T_NAV = "/ingenuity/nav_status"
T_REG = "/option_c/scout/registration_offset"

DECODE_TOPICS = {
    T_CLOCK, T_RUN_INFO, T_PHASE, T_WD, T_SCOUT, T_ROVER, T_NADIR, T_ORB_CI, T_CMD_TWIST, T_SCOUT_CMD, T_ENABLE,
    T_REQ, T_RCMD, T_HAZCAM, T_STOP, T_ACTIVE, T_ORB_GRID, T_ORB_PATH, T_FUSED_GRID, T_FUSED_PATH, T_PLAN,
    T_ODOM_EST, T_NAV, T_REG,
}
IMAGE_RE = re.compile(r"(^/clock$)|(/image$)|(/image_raw$)|(image.*compressed)")

# Student event and path topics whose first messages matter. Published transient_local (TOPICS.md,
# "Durability"), the messages sent before rosbag2 subscribed reach the bag together, at the moment
# the subscription matched. Such a leading burst is re-timed to the messages' own stamps
# (t_sim or header.stamp), see retime_history().
HISTORY_TOPICS = (T_PHASE, T_ACTIVE, T_PLAN, T_ORB_GRID, T_ORB_PATH, T_FUSED_GRID, T_FUSED_PATH)
HISTORY_BURST_S = 1.0      # a history burst arrives within this many seconds of the first message
HISTORY_MIN_AGE_S = 0.05   # a message received this much after its own stamp is history, not live
HISTORY_STARTUP_S = 15.0   # a late recorder gets its history within this many seconds of the bag's first message
HISTORY_RACE_AGE_S = 5.0   # later in the bag only the discovery race (rosbag2 finding a new node) delays history
HISTORY_AIRBORNE_Z = 0.5   # sortie plans: history only if it arrived before the first takeoff

_FORCED = os.environ.get("OPTION_C_BAG_READER", "").strip().lower()   # "rosbags" | "stdlib" | ""


def rosbags_available() -> bool:
    if _FORCED == "stdlib":
        return False
    try:
        import rosbags.rosbag2  # noqa: F401
        import rosbags.typesys  # noqa: F401
        return True
    except Exception:  # noqa: BLE001
        return False


def reader_name() -> str:
    return "rosbags" if rosbags_available() else "stdlib"


# ---------------------------------------------------------------------------------------------- normalize
def _stamp(st) -> float:
    return int(st.sec) + int(st.nanosec) * 1e-9


def normalize(msgtype: str, m):
    """rosbags message object -> the structure the cdr.py decoders return."""
    if msgtype == "rosgraph_msgs/msg/Clock":
        return _stamp(m.clock)
    if msgtype == "std_msgs/msg/String":
        return str(m.data)
    if msgtype == "std_msgs/msg/Bool":
        return bool(m.data)
    if msgtype == "geometry_msgs/msg/Twist":
        return (float(m.linear.x), float(m.linear.y), float(m.linear.z),
                float(m.angular.x), float(m.angular.y), float(m.angular.z))
    if msgtype == "nav_msgs/msg/Odometry":
        p, q = m.pose.pose.position, m.pose.pose.orientation
        v, w = m.twist.twist.linear, m.twist.twist.angular
        return {"t": _stamp(m.header.stamp), "frame": str(m.header.frame_id), "child": str(m.child_frame_id),
                "pos": (float(p.x), float(p.y), float(p.z)), "q": (float(q.x), float(q.y), float(q.z), float(q.w)),
                "v": (float(v.x), float(v.y), float(v.z)), "w": (float(w.x), float(w.y), float(w.z))}
    if msgtype == "sensor_msgs/msg/CameraInfo":
        return {"t": _stamp(m.header.stamp), "frame": str(m.header.frame_id), "w": int(m.width),
                "h": int(m.height), "k": [float(v) for v in m.k]}
    if msgtype == "geometry_msgs/msg/PoseArray":
        n = len(m.poses)
        xy = np.zeros((n, 2), dtype=np.float64)
        for i, pose in enumerate(m.poses):
            xy[i, 0], xy[i, 1] = pose.position.x, pose.position.y
        return {"t": _stamp(m.header.stamp), "frame": str(m.header.frame_id), "xy": xy}
    if msgtype == "nav_msgs/msg/Path":
        n = len(m.poses)
        xyz = np.zeros((n, 3), dtype=np.float64)
        for i, ps in enumerate(m.poses):
            xyz[i, 0], xyz[i, 1], xyz[i, 2] = ps.pose.position.x, ps.pose.position.y, ps.pose.position.z
        return {"t": _stamp(m.header.stamp), "frame": str(m.header.frame_id), "xyz": xyz}
    if msgtype == "geometry_msgs/msg/PoseStamped":
        p, q = m.pose.position, m.pose.orientation
        return {"t": _stamp(m.header.stamp), "frame": str(m.header.frame_id),
                "pos": (float(p.x), float(p.y), float(p.z)), "q": (float(q.x), float(q.y), float(q.z), float(q.w))}
    if msgtype == "nav_msgs/msg/OccupancyGrid":
        o, oq = m.info.origin.position, m.info.origin.orientation
        return {"t": _stamp(m.header.stamp), "frame": str(m.header.frame_id), "res": float(m.info.resolution),
                "w": int(m.info.width), "h": int(m.info.height), "origin": (float(o.x), float(o.y), float(o.z)),
                "oq": (float(oq.x), float(oq.y), float(oq.z), float(oq.w)),
                "data": np.asarray(m.data, dtype=np.int8).copy()}
    raise KeyError(msgtype)


# ---------------------------------------------------------------------------------------------- container
@dataclass
class BagData:
    path: Path
    name: str
    readable: bool = False
    error: str | None = None
    reader: str = ""
    storage_id: str = ""
    metadata_ok: bool = False
    size_bytes: int = 0
    topics: dict = field(default_factory=dict)
    counts: dict = field(default_factory=dict)
    decode_errors: dict = field(default_factory=dict)
    type_mismatch: dict = field(default_factory=dict)
    clock_rx: np.ndarray = None
    clock_sim: np.ndarray = None
    strings: dict = field(default_factory=dict)      # topic -> list[(rx, text)]
    bools: dict = field(default_factory=dict)        # topic -> (rx array, value array)
    twists: dict = field(default_factory=dict)       # topic -> (rx array, N x 6 array)
    odoms: dict = field(default_factory=dict)        # topic -> dict of arrays t,rx,x,y,z,qx,qy,qz,qw,vx,vy,vz
    caminfos: dict = field(default_factory=dict)     # topic -> dict t, rx, w, h, k (N x 9)
    hazcam: list = field(default_factory=list)       # [(t, rx, xy)]
    paths: dict = field(default_factory=dict)        # topic -> [dict(rx, t, frame, xyz)]
    grids: dict = field(default_factory=dict)        # topic -> [dict(rx, t, frame, res, w, h, origin, oq, data)]
    posestamped: dict = field(default_factory=dict)  # topic -> [dict(rx, t, frame, pos, q)]
    frames: dict = field(default_factory=dict)       # topic -> set of header frame ids seen (first 50 msgs)
    first_rx: float | None = None                    # receive time of the bag's first decoded message
    durability: dict = field(default_factory=dict)   # topic -> sorted list of offered durabilities (metadata)
    history: dict = field(default_factory=dict)      # topic -> dict(n, max_age_s, rx_first): re-timed leading burst

    def has(self, topic: str) -> bool:
        return topic in self.topics

    def count(self, topic: str) -> int:
        return int(self.counts.get(topic, 0))


def _folder_size(folder: Path) -> int:
    total = 0
    for dirpath, _dirs, files in os.walk(folder, followlinks=False):
        for f in files:
            p = Path(dirpath) / f
            try:
                if p.is_file() and not p.is_symlink():
                    total += p.stat().st_size
            except OSError:
                pass
    return total


def _read_metadata(folder: Path):
    p = folder / "metadata.yaml"
    if not p.is_file():
        return None, "no metadata.yaml (the recorder did not finish: stop it with Ctrl-C, or run ros2 bag reindex)"
    try:
        import yaml
        with open(p, "r", encoding="utf-8") as fh:
            md = yaml.safe_load(fh) or {}
        if not isinstance(md, dict) or "rosbag2_bagfile_information" not in md:
            return None, "metadata.yaml is not a rosbag2 metadata file"
        return md, None
    except Exception as exc:  # noqa: BLE001
        return None, "metadata.yaml does not parse (%s)" % type(exc).__name__


def offered_durability(md: dict) -> dict:
    """topic -> sorted list of the durabilities its publishers offered, from metadata.yaml (rosbag2 writes
    offered_qos_profiles as a list in metadata version >= 9 and as a YAML string before)."""
    out = {}
    info = (md or {}).get("rosbag2_bagfile_information") or {}
    for entry in info.get("topics_with_message_count") or []:
        tm = (entry or {}).get("topic_metadata") or {}
        name = tm.get("name")
        prof = tm.get("offered_qos_profiles")
        if isinstance(prof, str):
            try:
                import yaml
                prof = yaml.safe_load(prof) if prof.strip() else []
            except Exception:  # noqa: BLE001
                prof = []
        vals = set()
        for p in prof or []:
            if isinstance(p, dict) and p.get("durability") is not None:
                d = p.get("durability")
                d = {1: "transient_local", 2: "volatile"}.get(d, d) if isinstance(d, int) else str(d).strip().lower()
                vals.add(str(d))
        if name:
            out[str(name)] = sorted(vals)
    return out


def _clock_inverse(clock_rx: np.ndarray, clock_sim: np.ndarray):
    """(sim_of_rx, rx_of_sim) with the TimeBase rule of analysis.py (interpolate the clock pairs, slope 1
    outside them)."""
    rx = np.asarray(clock_rx, dtype=np.float64)
    sv = np.asarray(clock_sim, dtype=np.float64)

    def sim_of(t):
        t = float(t)
        if len(rx) == 0:
            return t
        if len(rx) == 1:
            return t - rx[0] + sv[0]
        if t < rx[0]:
            return float(sv[0] - (rx[0] - t))
        if t > rx[-1]:
            return float(sv[-1] + (t - rx[-1]))
        return float(np.interp(t, rx, sv))

    def rx_of(s):
        s = float(s)
        if len(rx) == 0:
            return s
        if len(rx) == 1:
            return s - sv[0] + rx[0]
        if s < sv[0]:
            return float(rx[0] - (sv[0] - s))
        if s > sv[-1]:
            return float(rx[-1] + (s - sv[-1]))
        # sim time is non-decreasing in receive order; np.interp needs increasing x
        keep = np.concatenate(([True], np.diff(sv) > 0))
        return float(np.interp(s, sv[keep], rx[keep]))

    return sim_of, rx_of


def _own_time(topic: str, item):
    """The message's own time (s): t_sim of a mission_phase JSON, header.stamp of a path or grid."""
    if topic == T_PHASE:
        try:
            d = json.loads(item[1])
            ts = float(d.get("t_sim")) if isinstance(d, dict) and d.get("t_sim") is not None else None
        except (ValueError, TypeError, AttributeError):
            ts = None
        return ts
    t = item.get("t")
    return float(t) if t is not None else None


def retime_history(bd: BagData) -> dict:
    """Re-time the transient_local history burst at the start of each HISTORY_TOPICS topic.

    A transient_local publisher hands its stored messages to rosbag2 when the subscription matches, so they
    are written with that receive time, seconds after they were sent. A message is treated as history when
    all of these hold: the bag metadata says every publisher of the topic offered transient_local; it is
    in the leading burst (received within HISTORY_BURST_S of the topic's first message, before any live
    message); its own time (t_sim or header.stamp) is positive, finite, not decreasing within the burst and
    at least HISTORY_MIN_AGE_S before its receive time; it is at most HISTORY_RACE_AGE_S old, unless the burst
    arrived within HISTORY_STARTUP_S of the bag's first message (a recorder started after the mission); and,
    for /option_c/sortie_plan, the burst arrived before the scout's first takeoff (a plan published after
    takeoff cannot be passed off as history). The age bound keeps a message published late in the run with
    a back-dated stamp from moving more than a few seconds. Its receive time is then replaced by the receive
    time at which the bag's clock shows its own time, so every check sees it when it was sent.
    Returns topic -> dict(n, max_age_s, rx_first)."""
    out = {}
    if bd.clock_rx is None:
        return out
    sim_of, rx_of = _clock_inverse(bd.clock_rx, bd.clock_sim)
    t_first = bd.first_rx
    if t_first is None and len(bd.clock_rx):
        t_first = float(np.min(bd.clock_rx))
    first_air_rx = None
    sc = bd.odoms.get(T_SCOUT)
    if sc is not None and len(sc["z"]):
        air = np.nonzero(sc["z"] > HISTORY_AIRBORNE_Z)[0]
        if len(air):
            first_air_rx = float(np.min(sc["rx"][air]))
    for topic in HISTORY_TOPICS:
        if bd.durability.get(topic) != ["transient_local"]:
            continue
        if topic == T_PHASE:
            items = bd.strings.get(topic) or []
        elif topic in (T_ORB_GRID, T_FUSED_GRID):
            items = bd.grids.get(topic) or []
        else:
            items = bd.paths.get(topic) or []
        if not items:
            continue
        rx_key = (lambda it: it[0]) if topic == T_PHASE else (lambda it: it["rx"])
        rx0 = float(rx_key(items[0]))
        if topic == T_PLAN and first_air_rx is not None and rx0 > first_air_rx:
            continue
        at_startup = t_first is not None and rx0 - t_first <= HISTORY_STARTUP_S
        n, max_age, prev = 0, 0.0, None
        for i, it in enumerate(items):
            rx = float(rx_key(it))
            if rx > rx0 + HISTORY_BURST_S:
                break
            own = _own_time(topic, it)
            if own is None or not np.isfinite(own) or own <= 0.0:
                break
            age = sim_of(rx) - own
            if age < HISTORY_MIN_AGE_S or (prev is not None and own < prev - 1e-6):
                break
            if age > HISTORY_RACE_AGE_S and not at_startup:
                break
            new_rx = rx_of(own)
            if topic == T_PHASE:
                items[i] = (new_rx, it[1])
            else:
                it["rx"] = new_rx
            n += 1
            max_age = max(max_age, age)
            prev = own
        if n:
            out[topic] = {"n": n, "max_age_s": float(max_age), "rx_first": rx0}
            if topic == T_PHASE:
                items.sort(key=lambda r: r[0])
            else:
                items.sort(key=lambda r: r["rx"])
    return out


def _iter_rosbags(folder: Path, wanted: set):
    from rosbags.rosbag2 import Reader
    from rosbags.typesys import Stores, get_typestore
    store = get_typestore(Stores.ROS2_JAZZY)
    with Reader(folder) as reader:
        topics = {c.topic: c.msgtype for c in reader.connections}
        counts = {}
        for c in reader.connections:
            counts[c.topic] = counts.get(c.topic, 0) + int(c.msgcount)
        conns = [c for c in reader.connections if c.topic in wanted and c.msgtype in cdr.DECODERS]
        yield ("__topics__", topics, counts)
        for conn, ts, raw in reader.messages(connections=conns):
            try:
                obj = normalize(conn.msgtype, store.deserialize_cdr(raw, conn.msgtype))
            except Exception:  # noqa: BLE001
                obj = None
            yield (conn.topic, conn.msgtype, int(ts), obj)


def _iter_stdlib(folder: Path, wanted: set, metadata: dict):
    bag = cdr.SqliteBag(folder, metadata)
    yield ("__topics__", dict(bag.topics), dict(bag.counts))
    names = [t for t in wanted if t in bag.topics and bag.topics[t] in cdr.DECODERS]
    for topic, typ, ts, raw in bag.messages(names):
        try:
            obj = cdr.DECODERS[typ](raw)
        except Exception:  # noqa: BLE001
            obj = None
        yield (topic, typ, ts, obj)


def read_bag(folder, expected_types: dict | None = None, accept_mcap: bool = False, force_reader: str | None = None) -> BagData:
    """Read one bag folder. expected_types maps topic -> required type: a topic recorded with a different
    type is not decoded (recorded in type_mismatch)."""
    folder = Path(folder)
    bd = BagData(path=folder, name=folder.name)
    bd.size_bytes = _folder_size(folder)
    md, err = _read_metadata(folder)
    if md is None:
        bd.error = err
        return bd
    bd.metadata_ok = True
    try:
        bd.durability = offered_durability(md)
    except Exception:  # noqa: BLE001
        bd.durability = {}
    info = md.get("rosbag2_bagfile_information") or {}
    bd.storage_id = str(info.get("storage_identifier") or "")
    if bd.storage_id != "sqlite3" and not accept_mcap:
        bd.error = ("storage %r, not sqlite3: re-record with tools/record_option_c_bag.sh (it uses -s sqlite3)"
                    % (bd.storage_id or "unknown"))
        return bd
    use = force_reader or ("rosbags" if rosbags_available() else "stdlib")
    if bd.storage_id != "sqlite3":
        use = "rosbags"
    bd.reader = use
    wanted = set(DECODE_TOPICS)
    expected_types = expected_types or {}

    clock_rx, clock_sim = [], []
    tw_rx, tw_v = {}, {}
    bo_rx, bo_v = {}, {}
    od = {}
    ci = {}
    try:
        it = _iter_rosbags(folder, wanted) if use == "rosbags" else _iter_stdlib(folder, wanted, md)
        head = next(it)
        _tag, topics, counts = head
        bd.topics = dict(topics)
        bd.counts = dict(counts)
        skip = set()
        for t, typ in expected_types.items():
            if t in bd.topics and bd.topics[t] != typ:
                bd.type_mismatch[t] = bd.topics[t]
                skip.add(t)
        for topic, typ, ts, obj in it:
            if topic in skip:
                continue
            if obj is None:
                bd.decode_errors[topic] = bd.decode_errors.get(topic, 0) + 1
                continue
            rx = ts * 1e-9
            if bd.first_rx is None or rx < bd.first_rx:
                bd.first_rx = rx
            if typ == "rosgraph_msgs/msg/Clock":
                if topic == T_CLOCK:
                    clock_rx.append(rx)
                    clock_sim.append(obj)
            elif typ == "std_msgs/msg/String":
                bd.strings.setdefault(topic, []).append((rx, obj))
            elif typ == "std_msgs/msg/Bool":
                bo_rx.setdefault(topic, []).append(rx)
                bo_v.setdefault(topic, []).append(bool(obj))
            elif typ == "geometry_msgs/msg/Twist":
                tw_rx.setdefault(topic, []).append(rx)
                tw_v.setdefault(topic, []).append(obj)
            elif typ == "nav_msgs/msg/Odometry":
                lst = od.setdefault(topic, [])
                lst.append((obj["t"], rx) + obj["pos"] + obj["q"] + obj["v"])
                fr = bd.frames.setdefault(topic, set())
                if len(fr) < 4:
                    fr.add(obj["frame"])
            elif typ == "sensor_msgs/msg/CameraInfo":
                lst = ci.setdefault(topic, [])
                lst.append((obj["t"], rx, obj["w"], obj["h"]) + tuple(obj["k"][:9]))
            elif typ == "geometry_msgs/msg/PoseArray":
                if topic == T_HAZCAM:
                    bd.hazcam.append((obj["t"], rx, obj["xy"]))
            elif typ == "nav_msgs/msg/Path":
                d = dict(obj)
                d["rx"] = rx
                bd.paths.setdefault(topic, []).append(d)
            elif typ == "nav_msgs/msg/OccupancyGrid":
                d = dict(obj)
                d["rx"] = rx
                bd.grids.setdefault(topic, []).append(d)
            elif typ == "geometry_msgs/msg/PoseStamped":
                d = dict(obj)
                d["rx"] = rx
                bd.posestamped.setdefault(topic, []).append(d)
    except Exception as exc:  # noqa: BLE001
        bd.error = "bag could not be read (%s: %s)" % (type(exc).__name__, str(exc)[:200])
        return bd

    def _sorted(rx, vals):
        rx = np.asarray(rx, dtype=np.float64)
        order = np.argsort(rx, kind="stable")
        return rx[order], order

    ca = np.asarray(clock_rx, dtype=np.float64)
    cs = np.asarray(clock_sim, dtype=np.float64)
    order = np.argsort(ca, kind="stable")
    bd.clock_rx, bd.clock_sim = ca[order], cs[order]
    for topic in tw_rx:
        rx, order = _sorted(tw_rx[topic], None)
        bd.twists[topic] = (rx, np.asarray(tw_v[topic], dtype=np.float64).reshape(-1, 6)[order])
    for topic in bo_rx:
        rx, order = _sorted(bo_rx[topic], None)
        bd.bools[topic] = (rx, np.asarray(bo_v[topic], dtype=bool)[order])
    keys = ("t", "rx", "x", "y", "z", "qx", "qy", "qz", "qw", "vx", "vy", "vz")
    for topic, rows in od.items():
        a = np.asarray(rows, dtype=np.float64).reshape(-1, len(keys))
        a = a[np.argsort(a[:, 0], kind="stable")]
        bd.odoms[topic] = {k: a[:, i].copy() for i, k in enumerate(keys)}
    for topic, rows in ci.items():
        a = np.asarray(rows, dtype=np.float64).reshape(-1, 13)
        a = a[np.argsort(a[:, 0], kind="stable")]
        bd.caminfos[topic] = {"t": a[:, 0].copy(), "rx": a[:, 1].copy(), "w": a[:, 2].copy(), "h": a[:, 3].copy(),
                              "k": a[:, 4:13].copy()}
    for topic in bd.strings:
        bd.strings[topic].sort(key=lambda r: r[0])
    for topic in bd.paths:
        bd.paths[topic].sort(key=lambda r: r["rx"])
    for topic in bd.grids:
        bd.grids[topic].sort(key=lambda r: r["rx"])
    for topic in bd.posestamped:
        bd.posestamped[topic].sort(key=lambda r: r["rx"])
    bd.hazcam.sort(key=lambda r: r[1])
    try:
        bd.history = retime_history(bd)
    except Exception as exc:  # noqa: BLE001
        bd.history = {"_error": "%s: %s" % (type(exc).__name__, str(exc)[:120])}
    bd.readable = True
    return bd


def forbidden_topics(bd: BagData) -> list:
    return sorted(t for t in bd.topics if IMAGE_RE.search(t))
