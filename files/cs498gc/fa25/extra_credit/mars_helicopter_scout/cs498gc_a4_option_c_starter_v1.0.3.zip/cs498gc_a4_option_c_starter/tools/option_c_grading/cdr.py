"""Standard-library rosbag2 sqlite3 reader and CDR decoders (the fallback when rosbags is not installed).

Decoders return the same normalized structures as bagio.normalize() builds from rosbags messages:
  Clock -> float (s); String -> str; Bool -> bool; Twist -> 6-tuple;
  Odometry -> {t, frame, child, pos, q, v, w}; CameraInfo -> {t, frame, w, h, k};
  PoseArray -> {t, frame, xy (N x 2)}; Path -> {t, frame, xyz (N x 3)};
  PoseStamped -> {t, frame, pos, q}; OccupancyGrid -> {t, frame, res, w, h, origin, oq, data (int8)}.
CDR here is XCDR1 (encapsulation CDR_LE or CDR_BE) as written by rosbag2 with Fast DDS or Cyclone DDS;
alignment is relative to the byte after the 4-byte encapsulation header.
"""
from __future__ import annotations

import sqlite3
import struct
from pathlib import Path

try:  # numpy is required by the grader; keep the decoders importable without it for --print-config
    import numpy as np
except ImportError:  # pragma: no cover
    np = None


class CdrError(ValueError):
    pass


class Cdr:
    __slots__ = ("b", "e", "p")

    def __init__(self, data):
        self.b = bytes(data)
        if len(self.b) < 4:
            raise CdrError("CDR payload shorter than its 4-byte header")
        self.e = "<" if (self.b[1] & 1) else ">"
        self.p = 4

    def align(self, n: int) -> None:
        r = (self.p - 4) % n
        if r:
            self.p += n - r

    def _unpack(self, fmt: str, size: int):
        self.align(size)
        if self.p + size > len(self.b):
            raise CdrError("CDR payload truncated")
        v = struct.unpack_from(self.e + fmt, self.b, self.p)[0]
        self.p += size
        return v

    def u8(self):
        if self.p + 1 > len(self.b):
            raise CdrError("CDR payload truncated")
        v = self.b[self.p]
        self.p += 1
        return v

    def i32(self):
        return self._unpack("i", 4)

    def u32(self):
        return self._unpack("I", 4)

    def f32(self):
        return self._unpack("f", 4)

    def f64(self):
        return self._unpack("d", 8)

    def f64n(self, n: int) -> tuple:
        self.align(8)
        if self.p + 8 * n > len(self.b):
            raise CdrError("CDR payload truncated")
        v = struct.unpack_from(self.e + "%dd" % n, self.b, self.p)
        self.p += 8 * n
        return v

    def string(self) -> str:
        n = self.u32()
        if n == 0:
            return ""
        if self.p + n > len(self.b):
            raise CdrError("CDR string truncated")
        raw = self.b[self.p:self.p + n]
        self.p += n
        if raw.endswith(b"\x00"):
            raw = raw[:-1]
        return raw.decode("utf-8", "replace")

    def time(self) -> float:
        sec = self.i32()
        nsec = self.u32()
        return sec + nsec * 1e-9

    def header(self):
        t = self.time()
        return t, self.string()


def dec_clock(data) -> float:
    return Cdr(data).time()


def dec_string(data) -> str:
    return Cdr(data).string()


def dec_bool(data) -> bool:
    return bool(Cdr(data).u8())


def dec_twist(data) -> tuple:
    return tuple(float(v) for v in Cdr(data).f64n(6))


def dec_header(data):
    return Cdr(data).header()


def dec_odom(data) -> dict:
    c = Cdr(data)
    t, frame = c.header()
    child = c.string()
    pose = c.f64n(7)
    c.f64n(36)
    tw = c.f64n(6)
    return {"t": t, "frame": frame, "child": child, "pos": tuple(pose[0:3]), "q": tuple(pose[3:7]),
            "v": tuple(tw[0:3]), "w": tuple(tw[3:6])}


def dec_caminfo(data) -> dict:
    c = Cdr(data)
    t, frame = c.header()
    h = c.u32()
    w = c.u32()
    c.string()
    nd = c.u32()
    if nd:
        c.f64n(nd)
    k = list(c.f64n(9))
    return {"t": t, "frame": frame, "w": int(w), "h": int(h), "k": k}


def dec_posearray(data) -> dict:
    c = Cdr(data)
    t, frame = c.header()
    n = c.u32()
    vals = c.f64n(7 * n) if n else ()
    xy = np.array(vals, dtype=np.float64).reshape(n, 7)[:, 0:2] if n else np.zeros((0, 2))
    return {"t": t, "frame": frame, "xy": np.ascontiguousarray(xy)}


def dec_posearray_count(data):
    c = Cdr(data)
    t, frame = c.header()
    return t, frame, c.u32()


def dec_path(data) -> dict:
    c = Cdr(data)
    t, frame = c.header()
    n = c.u32()
    out = np.zeros((n, 3), dtype=np.float64)
    for i in range(n):
        c.header()
        p = c.f64n(7)
        out[i, 0], out[i, 1], out[i, 2] = p[0], p[1], p[2]
    return {"t": t, "frame": frame, "xyz": out}


def dec_posestamped(data) -> dict:
    c = Cdr(data)
    t, frame = c.header()
    p = c.f64n(7)
    return {"t": t, "frame": frame, "pos": tuple(p[0:3]), "q": tuple(p[3:7])}


def dec_grid(data) -> dict:
    c = Cdr(data)
    t, frame = c.header()
    c.time()                      # map_load_time
    res = c.f32()
    w = c.u32()
    h = c.u32()
    o = c.f64n(7)
    n = c.u32()
    if c.p + n > len(c.b):
        raise CdrError("OccupancyGrid data truncated")
    arr = np.frombuffer(c.b, dtype=np.int8, count=n, offset=c.p).copy()
    return {"t": t, "frame": frame, "res": float(res), "w": int(w), "h": int(h),
            "origin": tuple(o[0:3]), "oq": tuple(o[3:7]), "data": arr}


DECODERS = {
    "rosgraph_msgs/msg/Clock": dec_clock,
    "std_msgs/msg/String": dec_string,
    "std_msgs/msg/Bool": dec_bool,
    "geometry_msgs/msg/Twist": dec_twist,
    "nav_msgs/msg/Odometry": dec_odom,
    "sensor_msgs/msg/CameraInfo": dec_caminfo,
    "geometry_msgs/msg/PoseArray": dec_posearray,
    "nav_msgs/msg/Path": dec_path,
    "geometry_msgs/msg/PoseStamped": dec_posestamped,
    "nav_msgs/msg/OccupancyGrid": dec_grid,
}


class SqliteBag:
    """Minimal rosbag2 sqlite3 reader: topics with types and counts, then messages per file in
    timestamp order. Raises ValueError for anything it cannot read (compressed bags included)."""

    def __init__(self, folder: Path, metadata: dict | None = None):
        self.folder = Path(folder)
        files = []
        md = metadata or {}
        info = md.get("rosbag2_bagfile_information") or {}
        if str(info.get("compression_format") or "").strip():
            raise ValueError("compressed bag (compression_format %r): the standard-library reader cannot "
                             "decode it; install rosbags or record without compression"
                             % info.get("compression_format"))
        for rel in info.get("relative_file_paths") or []:
            p = self.folder / str(rel)
            if p.is_file() and p.suffix == ".db3":
                files.append(p)
        if not files:
            files = sorted(self.folder.glob("*.db3"))
        if not files:
            raise ValueError("no .db3 file (record with -s sqlite3)")
        self.files = files
        self.topics: dict[str, str] = {}
        self.counts: dict[str, int] = {}
        for path in files:
            con = self._open(path)
            try:
                for _tid, name, typ in con.execute("SELECT id, name, type FROM topics"):
                    self.topics.setdefault(name, typ)
                    self.counts.setdefault(name, 0)  # registered but empty topics count 0, as with rosbags
                for name, n in con.execute("SELECT t.name, COUNT(m.id) FROM messages m JOIN topics t "
                                           "ON m.topic_id = t.id GROUP BY t.name"):
                    self.counts[name] = self.counts.get(name, 0) + int(n)
            finally:
                con.close()

    @staticmethod
    def _open(path: Path):
        try:
            con = sqlite3.connect("file:%s?mode=ro&immutable=1" % path.as_posix(), uri=True)
            con.execute("SELECT count(*) FROM sqlite_master").fetchone()
            return con
        except sqlite3.Error as exc:
            raise ValueError("cannot open %s as sqlite3 (%s)" % (path.name, exc)) from exc

    def messages(self, topics):
        """Yield (topic, type, timestamp_ns, raw bytes) for the wanted topics."""
        wanted = set(topics)
        for path in self.files:
            con = self._open(path)
            try:
                ids = {}
                for tid, name, typ in con.execute("SELECT id, name, type FROM topics"):
                    if name in wanted:
                        ids[tid] = (name, typ)
                if not ids:
                    continue
                q = ("SELECT topic_id, timestamp, data FROM messages WHERE topic_id IN (%s) ORDER BY timestamp"
                     % ",".join(str(int(i)) for i in ids))
                for tid, ts, data in con.execute(q):
                    name, typ = ids[tid]
                    yield name, typ, int(ts), data
            except sqlite3.Error as exc:
                raise ValueError("sqlite3 read error in %s (%s)" % (path.name, exc)) from exc
            finally:
                con.close()
