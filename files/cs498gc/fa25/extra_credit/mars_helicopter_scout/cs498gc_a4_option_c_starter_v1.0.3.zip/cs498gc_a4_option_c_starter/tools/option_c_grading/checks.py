"""AG-01 .. AG-26 and AG-B1 of the Option C specification (frozen 2026-11-03), plus two information tests.

Every check reads its points and thresholds from spec_option_c_v1.yaml through Settings. Each scored element
states what was measured, what is required and how to fix it. Student-visible text never contains the NetID,
names, emails or file contents.
"""
from __future__ import annotations

import json
import math
from pathlib import Path

import numpy as np

from . import analysis as A
from . import bagio as B
from . import geometry as geo
from . import groundtruth as GT
from . import submission as SUB
from .util import Outcome, fnum, linear_credit

CONDS = ("orbit_only", "orbit_scout")
MILESTONES = ("M1", "M2", "M3", "M4", "M5")
PATH_ORBITAL = "/option_c/orbital_path"
PATH_FUSED = "/option_c/fused_path"


# ============================================================================================== context
class Ctx:
    """Lazy, cached analysis of one submission."""

    def __init__(self, settings, submission, work, metadata_path=None, stage: str = "M5", local: bool = False,
                 netid_override: str | None = None, force_reader: str | None = None):
        self.s = settings
        self.stage = stage if stage in MILESTONES else "M5"
        self.local = local
        self.force_reader = force_reader
        lim = settings.limit
        self.layout = SUB.discover(submission, work, lim("archive_max_members", 5000),
                                   lim("archive_max_bytes", 400_000_000), lim("archive_max_count", 3))
        self.root = self.layout.root
        self.flags: list = []
        self.notes: list = []
        self.cfg, self.cfg_error = {}, None
        if self.root is not None:
            try:
                self.cfg = SUB.parse_config(self.root / "config" / "option_c.yaml") or {}
                if not isinstance(self.cfg, dict):
                    self.cfg, self.cfg_error = {}, "config/option_c.yaml is not a mapping"
            except Exception as exc:  # noqa: BLE001
                self.cfg_error = "config/option_c.yaml could not be read (%s)" % type(exc).__name__
        self.cfg_netid = str(self.cfg.get("netid", "") or "").strip().lower()
        raw = self.cfg.get("seeds", [])
        raw = raw if isinstance(raw, list) else [raw]
        self.cfg_seeds = [int(x) for x in raw if str(x).strip().lstrip("-").isdigit()]
        self.meta_netids, self.meta_error = SUB.metadata_netids(metadata_path) if not local else ([], None)
        if netid_override:
            self.netid, self.netid_source = netid_override.strip().lower(), "command line"
        elif local or not self.meta_netids:
            self.netid, self.netid_source = self.cfg_netid, "config/option_c.yaml"
            if not local:
                self.notes.append("submission_metadata.json not available: seeds derived from config/option_c.yaml")
        elif self.cfg_netid and self.cfg_netid in self.meta_netids:
            self.netid, self.netid_source = self.cfg_netid, "Gradescope account"
        else:
            self.netid, self.netid_source = self.meta_netids[0], "Gradescope account"
        self.seeds = GT.seeds_for(self.netid) if self.netid else []
        self._bags: dict = {}
        self._ba: dict = {}
        self._ag02: dict = {}
        self._src = None
        self._metrics = None

    # ------------------------------------------------------------------ stage
    def stage_index(self) -> int:
        return MILESTONES.index(self.stage)

    def in_stage(self, milestone: str) -> bool:
        return MILESTONES.index(milestone) <= self.stage_index()

    def conds_in_scope(self) -> tuple:
        return CONDS if self.in_stage("M2") else ("orbit_only",)

    # ------------------------------------------------------------------ flags
    def flag(self, code: str, detail: str) -> None:
        item = {"code": code, "detail": detail}
        if item not in self.flags:
            self.flags.append(item)

    # ------------------------------------------------------------------ paths
    def bag_dir(self, seed: int, cond: str) -> Path | None:
        if self.root is None:
            return None
        if cond == "orbit_scout_drift":
            return self.root / "bonus_drift" / "bags" / ("seed%d_orbit_scout_drift" % seed)
        return self.root / "bags" / ("seed%d_%s" % (seed, cond))

    def results_dir(self, seed: int, drift: bool = False) -> Path | None:
        if self.root is None:
            return None
        if drift:
            return self.root / "bonus_drift" / "results"
        return self.root / "results" / ("seed%d" % seed)

    def unexpected_bags(self) -> list:
        if self.root is None or not (self.root / "bags").is_dir():
            return []
        expect = {"seed%d_%s" % (s, c) for s in self.seeds for c in CONDS}
        return sorted(p.name for p in (self.root / "bags").iterdir() if p.is_dir() and p.name not in expect)

    # ------------------------------------------------------------------ bags
    def bag(self, seed: int, cond: str):
        key = (seed, cond)
        if key not in self._bags:
            p = self.bag_dir(seed, cond)
            if p is None or not p.is_dir():
                self._bags[key] = None
            else:
                self._bags[key] = B.read_bag(p, self.s.required_topics(cond), bool(self.s.policy("accept_mcap", False)),
                                             force_reader=self.force_reader)
        return self._bags[key]

    def run_info(self, seed: int, cond: str):
        bd = self.bag(seed, cond)
        if bd is None or not bd.readable:
            return None
        for _rx, text in bd.strings.get(B.T_RUN_INFO, []):
            try:
                d = json.loads(text)
                if isinstance(d, dict):
                    return d
            except ValueError:
                continue
        return None

    def r_fp(self, seed: int, cond: str) -> float:
        floor = float(self.s.policy("footprint_floor_m", 0.45))
        info = self.run_info(seed, cond) or {}
        try:
            v = float(info.get("rover_footprint_radius_m", floor))
        except (TypeError, ValueError):
            v = floor
        if not math.isfinite(v):
            v = floor
        return max(floor, v)

    def ag02(self, seed: int, cond: str):
        """(ok, problems) of the AG-02 bag rules for one bag."""
        key = (seed, cond)
        if key in self._ag02:
            return self._ag02[key]
        problems = []
        bd = self.bag(seed, cond)
        if bd is None:
            problems.append("bag folder %s missing" % self._bag_rel(seed, cond))
        elif not bd.readable:
            problems.append("bag cannot be read: %s" % bd.error)
        else:
            info = self.run_info(seed, cond)
            if info is None:
                problems.append("no /option_c/run_info message")
            else:
                if str(info.get("seed")) != str(seed):
                    problems.append("run_info seed %s, expected %d" % (info.get("seed"), seed))
                ver = str(info.get("starter_version", ""))
                if ver.split(".")[0] != str(self.s.assignment["starter_major_version"]):
                    problems.append("starter_version %r (major 1 required)" % ver)
                want_mode = "drift" if cond == "orbit_scout_drift" else "truth"
                if info.get("odom_mode") != want_mode:
                    problems.append("odom_mode %r, expected %r" % (info.get("odom_mode"), want_mode))
                want_cond = "orbit_scout" if cond == "orbit_scout_drift" else cond
                if info.get("condition") != want_cond:
                    problems.append("condition %r, expected %r" % (info.get("condition"), want_cond))
                try:
                    w = GT.world(seed)
                    if info.get("world_sha256") != w.sdf_sha256:
                        problems.append("world_sha256 does not match the world regenerated for seed %d" % seed)
                except Exception as exc:  # noqa: BLE001
                    problems.append("world for seed %d could not be regenerated (%s)" % (seed, type(exc).__name__))
        res = (not problems, problems)
        self._ag02[key] = res
        # SEED_MISMATCH: a readable bag whose run_info does not belong to this seed/condition/world (a missing or
        # unreadable bag is reported by AG-03 and needs no TA review)
        if problems and bd is not None and bd.readable and cond != "orbit_scout_drift":
            self.flag("SEED_MISMATCH", "%s: %s" % (self._bag_rel(seed, cond), "; ".join(problems)))
        return res

    def _bag_rel(self, seed: int, cond: str) -> str:
        if cond == "orbit_scout_drift":
            return "bonus_drift/bags/seed%d_orbit_scout_drift" % seed
        return "bags/seed%d_%s" % (seed, cond)

    def analysis(self, seed: int, cond: str):
        """(BagAnalysis or None, reason)."""
        key = (seed, cond)
        if key in self._ba:
            return self._ba[key]
        ok, problems = self.ag02(seed, cond)
        if not ok:
            res = (None, "; ".join(problems))
        else:
            c = "orbit_scout" if cond == "orbit_scout_drift" else cond
            res = (A.BagAnalysis(self.bag(seed, cond), self.s, GT.world(seed), self.r_fp(seed, cond), c), "")
        self._ba[key] = res
        return res

    # ------------------------------------------------------------------ src
    def src(self):
        if self._src is None:
            p = self.root / "src" / "option_c_scout" if self.root is not None else None
            if p is None or not p.is_dir():
                self._src = (None, 0)
            else:
                self._src = SUB.src_tree_sha256(p)
        return self._src

    # ------------------------------------------------------------------ metrics
    def metrics(self) -> dict:
        if self._metrics is None:
            out = {}
            for s in self.seeds:
                for c in CONDS:
                    ba, _why = self.analysis(s, c)
                    out[(s, c)] = ba.metrics() if ba is not None else None
            self._metrics = out
        return self._metrics


# ============================================================================================== helpers
def _o(ctx: Ctx, tid: str) -> Outcome:
    t = ctx.s.test(tid)
    return Outcome(tid, str(t["name"]), float(t.get("points") or 0.0), str(t.get("number", "")))


def _scope(seed, cond) -> str:
    return "seed %d (%s)" % (seed, cond)


def per_seed(ctx: Ctx, o: Outcome, cond: str, fn):
    """Run fn(ba, add) for each of the 3 seeds; add(name, fraction, measured, required, fix=None) scores spec
    element `name` (or the whole check when name is None) at one third of its points."""
    tid = o.test_id
    n = 3
    for s in ctx.seeds:
        scope = _scope(s, cond)
        els = ctx.s.test(tid).get("elements") or {}

        def add(name, frac, measured, required, fix=None, label=None, _scope=scope):
            full = ctx.s.el(tid, name) if name else ctx.s.points(tid)
            o.element(label or (name or o.name), full / n, frac, measured, required, fix, _scope)

        ba, why = ctx.analysis(s, cond)
        if ba is None:
            for name in (els or {None: 0}):
                add(name, 0.0, "not graded: " + why, "a readable bag that passes AG-02",
                    "record the bag for this seed and condition with tools/record_option_c_bag.sh and launch "
                    "student_pkg_src:=<path to src/option_c_scout>")
            continue
        try:
            fn(ba, add)
        except Exception as exc:  # noqa: BLE001
            o.warn("%s: check raised %s; the remaining items for this seed scored 0" % (scope, type(exc).__name__))
            o.extra.setdefault("errors", []).append("%s %s: %s" % (scope, type(exc).__name__, str(exc)[:200]))
    if not ctx.seeds:
        o.element("seeds", o.max_score, 0.0, "no NetID, so no seeds", "netid in config/option_c.yaml",
                  "fill in netid in config/option_c.yaml")


def _last_before(items: list, tb, t_limit: float | None, slack: float = 0.5):
    if t_limit is None:
        return items[-1] if items else None
    ok = [it for it in items if float(tb.sim(it["rx"])) <= t_limit + slack]
    return ok[-1] if ok else None


def _grid_geometry(grid: dict, spec: dict, tol_res: float, tol_org: float) -> dict:
    out = {}
    out["frame"] = grid["frame"] == spec["frame_id"]
    out["resolution"] = abs(grid["res"] - float(spec["resolution_m"])) <= tol_res
    out["size"] = grid["w"] == int(spec["width"]) and grid["h"] == int(spec["height"])
    ox, oy = grid["origin"][0], grid["origin"][1]
    out["origin"] = abs(ox - spec["origin_xy"][0]) <= tol_org and abs(oy - spec["origin_xy"][1]) <= tol_org
    d = grid["data"]
    out["values"] = len(d) == grid["w"] * grid["h"] and (len(d) == 0 or (int(d.min()) >= -1 and int(d.max()) <= 100))
    return out


def _grid_desc(grid: dict) -> str:
    return "frame %r, resolution %s, %d x %d, origin (%s, %s)" % (
        grid["frame"], fnum(grid["res"], 4), grid["w"], grid["h"], fnum(grid["origin"][0], 3), fnum(grid["origin"][1], 3))


def _sand_samples(world, step: float) -> np.ndarray:
    poly = world.sand
    x0, y0 = poly[:, 0].min(), poly[:, 1].min()
    x1, y1 = poly[:, 0].max(), poly[:, 1].max()
    xs = np.arange(math.floor((x0 + 80) / step), math.ceil((x1 + 80) / step) + 1) * step - 80 + step / 2
    ys = np.arange(math.floor((y0 + 80) / step), math.ceil((y1 + 80) / step) + 1) * step - 80 + step / 2
    X, Y = np.meshgrid(xs, ys)
    P = np.stack([X.ravel(), Y.ravel()], axis=1)
    return P[geo.point_in_polygon(P, poly)]


def _lethal_centers(grid: dict, lethal: int, max_cells: int) -> np.ndarray:
    w, h = grid["w"], grid["h"]
    d = grid["data"]
    if w * h != len(d) or w * h > max_cells or grid["res"] <= 0:
        return np.zeros((0, 2))
    idx = np.nonzero(d >= lethal)[0]
    i = idx % w
    j = idx // w
    return np.stack([grid["origin"][0] + (i + 0.5) * grid["res"], grid["origin"][1] + (j + 0.5) * grid["res"]], axis=1)


def _false_lethal(grid: dict, hz: geo.Hazards, margin: float, lethal: int, max_cells: int):
    C = _lethal_centers(grid, lethal, max_cells)
    if len(C) == 0:
        return 0.0, 0
    near = geo.near_hazard_mask(C, hz, margin)
    return float(np.mean(~near)), len(C)


def _path_endpoints(pts: np.ndarray, world, tol: float):
    if len(pts) == 0:
        return False, float("inf"), float("inf")
    ds = float(np.hypot(*(pts[0] - world.S)))
    dg = float(np.hypot(*(pts[-1] - world.G)))
    return ds <= tol and dg <= tol, ds, dg


def active_path_rules(ba: A.BagAnalysis, ref_path: np.ndarray | None) -> dict:
    """AG-12 rules for the active paths of one drive (used by AG-12 and the AG-24 gate)."""
    th = ba.s.th("AG-12")
    d = ba.drive()
    out = {"first_ok": False, "first_h": None, "later_ok": False, "later_bad": [], "count_ok": False, "n": 0}
    total = len(ba.bd.paths.get(B.T_ACTIVE, []))
    out["n"] = total
    out["count_ok"] = total <= int(th["max_messages"])
    ap = d.get("active_paths") or []
    if not d.get("ok") or not ap:
        out["why"] = "no rover_start" if not d.get("ok") else "no /option_c/rover/active_path after rover_start"
        return out
    if ref_path is not None and len(ref_path):
        h = geo.hausdorff(ap[0]["xyz"][:, :2], ref_path, float(th["resample_m"]))
        out["first_h"] = h
        out["first_ok"] = h <= float(th["hausdorff_max_m"])
    bad = []
    G = ba.world.G
    for k, p in enumerate(ap[1:], 1):
        pts = p["xyz"][:, :2]
        if len(pts) == 0:
            bad.append((k, "empty path"))
            continue
        t = p["t"] if p["t"] > 0 else float(ba.tb.sim(p["rx"]))
        rxy = ba.rover_xy_at(t)
        problems = []
        if rxy is None or float(np.hypot(pts[0][0] - rxy[0], pts[0][1] - rxy[1])) > float(th["start_tol_m"]):
            problems.append("starts %s m from the rover" % (fnum(np.hypot(pts[0][0] - rxy[0], pts[0][1] - rxy[1])) if rxy else "?"))
        if float(np.hypot(*(pts[-1] - G))) > float(th["end_tol_m"]):
            problems.append("ends %s m from G" % fnum(np.hypot(*(pts[-1] - G))))
        if geo.max_spacing(pts) > float(th["max_spacing_m"]) + 1e-9:
            problems.append("pose spacing %s m" % fnum(geo.max_spacing(pts)))
        if problems:
            bad.append((k, ", ".join(problems)))
    out["later_bad"] = bad
    out["later_ok"] = not bad
    return out


def _ref_path(ba: A.BagAnalysis, topic: str):
    items = ba.bd.paths.get(topic, [])
    rs = ba.phase("rover_start")
    p = _last_before(items, ba.tb, rs.t_rx if rs else None)
    if p is None and items:
        p = items[-1]
    return p


def greedy_match(D: np.ndarray, radius: float) -> int:
    """One-to-one greedy matching on a (rows x targets) distance matrix within radius; returns matches."""
    if D.size == 0:
        return 0
    ii, jj = np.nonzero(D <= radius)
    if len(ii) == 0:
        return 0
    order = np.argsort(D[ii, jj], kind="stable")
    used_r, used_t = set(), set()
    n = 0
    for k in order:
        a, b = int(ii[k]), int(jj[k])
        if a in used_r or b in used_t:
            continue
        used_r.add(a)
        used_t.add(b)
        n += 1
    return n


# ============================================================================================== C1
def ag01(ctx: Ctx) -> Outcome:
    o = _o(ctx, "AG-01")
    t = ctx.s.test("AG-01")
    if ctx.root is None:
        for name in ("files", "config", "netid", "size"):
            o.element(name, ctx.s.el("AG-01", name), 0.0, "no folder with config/option_c.yaml found in the upload",
                      "an option_c/ folder as in the deliverables tree", "zip the option_c folder with tools/make_submission.sh")
        for n in ctx.layout.notes:
            o.note(n)
        return o
    req = list(t["required_paths"])
    present = [p for p in req if (ctx.root / p).exists()]
    missing = [p for p in req if p not in present]
    o.element("required files and folders", ctx.s.el("AG-01", "files"), len(present) / len(req),
              "%d of %d present%s" % (len(present), len(req), ("; missing: " + ", ".join(missing)) if missing else ""),
              ", ".join(req), "add the missing items (see HANDOUT.md, Deliverables)")
    keys = list(t["required_config_keys"])
    have = [k for k in keys if k in ctx.cfg]
    if ctx.cfg_error:
        o.element("config/option_c.yaml", ctx.s.el("AG-01", "config"), 0.0, ctx.cfg_error,
                  "a YAML mapping with keys " + ", ".join(keys), "copy config/option_c_template.yaml and fill it in")
    else:
        miss = [k for k in keys if k not in have]
        o.element("config/option_c.yaml keys", ctx.s.el("AG-01", "config"), len(have) / len(keys),
                  "%d of %d keys%s" % (len(have), len(keys), ("; missing: " + ", ".join(miss)) if miss else ""),
                  ", ".join(keys), "add the missing keys (template: config/option_c_template.yaml)")
        try:
            rfp = float(ctx.cfg.get("rover_footprint_radius_m", 0.45))
            if rfp < 0.45:
                o.warn("rover_footprint_radius_m %s is below 0.45: the grader uses 0.45" % fnum(rfp))
        except (TypeError, ValueError):
            o.warn("rover_footprint_radius_m is not a number")
    if ctx.local:
        o.element("netid matches your Gradescope account", ctx.s.el("AG-01", "netid"), 1.0 if ctx.cfg_netid else 0.0,
                  "local check: netid in config is %s" % ("set" if ctx.cfg_netid else "missing"),
                  "on Gradescope: netid = the local part of your account email",
                  "set netid in config/option_c.yaml to your NetID")
    else:
        if len(ctx.meta_netids) > 1:
            ok = 0.0
            meas = "group submission (%d accounts)" % len(ctx.meta_netids)
            ctx.flag("GROUP_SUBMISSION", "%d accounts on one submission" % len(ctx.meta_netids))
        elif not ctx.meta_netids:
            ok = 0.0
            meas = ctx.meta_error or "no account email in submission_metadata.json"
        else:
            ok = 1.0 if ctx.cfg_netid == ctx.meta_netids[0] else 0.0
            meas = "config netid %s the Gradescope account email local part" % ("matches" if ok else "does NOT match")
            if not ok:
                ctx.flag("NETID_MISMATCH", "config netid differs from the submitting account")
        o.element("netid matches the Gradescope account", ctx.s.el("AG-01", "netid"), ok, meas,
                  "individual submission; netid = email local part",
                  "set netid in config/option_c.yaml to your NetID and submit individually")
    limit = int(ctx.s.bag_rule("max_zip_bytes"))
    size = ctx.layout.archive_bytes if ctx.layout.archive_bytes else ctx.layout.upload_bytes
    o.element("upload size", ctx.s.el("AG-01", "size"), 1.0 if size <= limit else 0.0,
              "%.1f MB" % (size / 1e6), "<= 150 MB", "trim bags (no images, no raw /clock) and media")
    for n in ctx.layout.notes:
        o.note(n)
    unexp = ctx.unexpected_bags()
    if unexp:
        o.note("bag folders not named after your seeds are ignored: %s" % ", ".join(unexp))
        ctx.flag("UNEXPECTED_BAGS", ", ".join(unexp))
    return o


def ag02(ctx: Ctx) -> Outcome:
    o = _o(ctx, "AG-02")
    ok = ctx.cfg_seeds == ctx.seeds and len(ctx.seeds) == 3
    o.element("config seeds = your NetID seeds", ctx.s.el("AG-02", "config_seeds"), 1.0 if ok else 0.0,
              "config seeds %s, expected %s" % (ctx.cfg_seeds, ctx.seeds),
              "seeds [s0, s1, s2] printed by tools/option_c_seed.py --netid <your netid>",
              "run tools/option_c_seed.py --netid <netid> and copy the three seeds")
    per = ctx.s.el("AG-02", "bags") / 6.0
    for s in ctx.seeds:
        for c in CONDS:
            scope = _scope(s, c)
            if c not in ctx.conds_in_scope():
                o.info("bag rules", "not checked at stage %s" % ctx.stage, scope=scope)
                continue
            good, problems = ctx.ag02(s, c)
            o.element("run_info seed, starter_version, odom_mode, condition, world_sha256", per, 1.0 if good else 0.0,
                      "all match" if good else "; ".join(problems),
                      "seed %d, starter 1.x, odom_mode truth, condition %s, regenerated world hash" % (s, c),
                      "launch option_c_world.launch.py seed:=%d condition:=%s and record with "
                      "tools/record_option_c_bag.sh %d %s" % (s, c, s, c), scope)
    if any(f["code"] == "SEED_MISMATCH" for f in ctx.flags):
        o.note("SEED_MISMATCH: every automated point that uses a failing bag is 0 (TA review)")
    return o


def _bag_scope_iter(ctx: Ctx):
    for s in ctx.seeds:
        for c in CONDS:
            yield s, c, _scope(s, c), c in ctx.conds_in_scope()


def ag03(ctx: Ctx) -> Outcome:
    o = _o(ctx, "AG-03")
    per = o.max_score / 6.0
    maxb = int(ctx.s.bag_rule("max_bytes"))
    mins = float(ctx.s.bag_rule("min_sim_s"))
    for s, c, scope, active in _bag_scope_iter(ctx):
        if not active:
            o.info("bag", "not checked at stage %s" % ctx.stage, scope=scope)
            continue
        bd = ctx.bag(s, c)
        if bd is None:
            o.element("readable, >= 60 s, <= 25 MB", per, 0.0, "bag folder missing", "bags/seed%d_%s" % (s, c),
                      "record it with tools/record_option_c_bag.sh %d %s" % (s, c), scope)
            continue
        items = []
        items.append(("opens (sqlite3)", bd.readable, bd.error or "ok"))
        span = A.TimeBase(bd.clock_rx, bd.clock_sim).span() if bd.readable and bd.clock_rx is not None else 0.0
        if span <= 0 and bd.readable:
            for od in bd.odoms.values():
                if len(od["t"]) > 1:
                    span = max(span, float(od["t"][-1] - od["t"][0]))
        items.append((">= 60 s sim", span >= mins, "%s s of sim time" % fnum(span, 1)))
        items.append(("<= 25 MB", bd.size_bytes <= maxb, "%.2f MB" % (bd.size_bytes / 1e6)))
        if bd.size_bytes > maxb:
            ctx.flag("OVERSIZE_BAG", "%s is %.1f MB" % (ctx._bag_rel(s, c), bd.size_bytes / 1e6))
        frac = sum(1 for _n, ok, _m in items if ok) / len(items)
        o.element("readable, >= 60 s, <= 25 MB", per, frac, "; ".join("%s: %s" % (n, m) for n, ok, m in items),
                  "opens with rosbags (sqlite3), >= 60 s sim time, <= 25,000,000 bytes",
                  "record with tools/record_option_c_bag.sh (sqlite3, no images); keep runs under the limits", scope)
    return o


def ag04(ctx: Ctx) -> Outcome:
    o = _o(ctx, "AG-04")
    per = o.max_score / 6.0
    empty_ok = ctx.s.may_be_empty()
    for s, c, scope, active in _bag_scope_iter(ctx):
        if not active:
            o.info("topics", "not checked at stage %s" % ctx.stage, scope=scope)
            continue
        bd = ctx.bag(s, c)
        if bd is None or not bd.readable:
            o.element("required topics and types", per, 0.0, "bag missing or unreadable", "see AG-03",
                      "fix the bag first (AG-03)", scope)
            continue
        req = ctx.s.required_topics(c)
        bad = []
        for topic, typ in req.items():
            if topic not in bd.topics:
                bad.append("%s missing" % topic)
            elif bd.topics[topic] != typ:
                bad.append("%s has type %s (need %s)" % (topic, bd.topics[topic], typ))
            elif topic not in empty_ok and bd.count(topic) == 0:
                bad.append("%s has no messages" % topic)
        # split (implementation): 0.8 required topics, 0.1 mission_phase JSON, 0.1 no image topics / raw /clock
        frac = 0.8 * (len(req) - len(bad)) / len(req)
        phases = bd.strings.get(B.T_PHASE, [])
        badj = 0
        for _rx, text in phases:
            try:
                d = json.loads(text)
                if not isinstance(d, dict) or "event" not in d or "t_sim" not in d:
                    badj += 1
            except ValueError:
                badj += 1
        if phases and not badj:
            frac += 0.1
        else:
            bad.append("mission_phase: %s" % ("no messages" if not phases else "%d messages are not JSON with event and t_sim" % badj))
        forb = B.forbidden_topics(bd)
        if forb:
            bad.append("forbidden topics recorded: %s" % ", ".join(forb))
            ctx.flag("IMAGE_TOPICS", "%s records %s" % (ctx._bag_rel(s, c), ", ".join(forb)))
        else:
            frac += 0.1
        o.element("required topics and types", per, frac,
                  "all present" if not bad else "; ".join(bad[:8]) + (" (+%d more)" % (len(bad) - 8) if len(bad) > 8 else ""),
                  "%d required topics with exact types (%s), mission_phase JSON {event, t_sim}, no image topics or raw /clock"
                  % (len(req), c), "record with tools/record_option_c_bag.sh %d %s while all nodes run" % (s, c), scope)
    return o


def ag05(ctx: Ctx) -> Outcome:
    o = _o(ctx, "AG-05")
    th = ctx.s.th("AG-05")
    per = o.max_score / 6.0
    for s, c, scope, active in _bag_scope_iter(ctx):
        if not active:
            o.info("rates", "not checked at stage %s" % ctx.stage, scope=scope)
            continue
        bd = ctx.bag(s, c)
        if bd is None or not bd.readable:
            o.element("rates and time base", per, 0.0, "bag missing or unreadable", "see AG-03", "fix the bag first", scope)
            continue
        ba = A.BagAnalysis(bd, ctx.s, None, 0.45, c)
        items = []
        clk = ba.tb.simv
        hz = (len(clk) - 1) / (clk[-1] - clk[0]) if len(clk) > 1 and clk[-1] > clk[0] else 0.0
        items.append(("clock_20hz", hz >= th["clock_hz"], "%s Hz" % fnum(hz)))
        rov = bd.odoms.get(B.T_ROVER)
        r_hz = A.rate_hz(rov["t"]) if rov is not None else 0.0
        items.append(("rover odom_truth", r_hz >= th["rover_odom_hz"], "%s Hz" % fnum(r_hz)))
        h_hz = A.rate_hz([t for t, _rx, _xy in bd.hazcam])
        items.append(("hazcam", h_hz >= th["hazcam_hz"], "%s Hz" % fnum(h_hz)))
        n_orb = bd.count(B.T_ORB_CI)
        items.append(("orbiter camera_info", n_orb >= 1, "%d messages" % n_orb))
        bad_ev = 0
        n_ev = 0
        for topic in (B.T_WD, B.T_PHASE):
            for rx, text in bd.strings.get(topic, []):
                try:
                    d = json.loads(text)
                    ts = float(d.get("t_sim"))
                except (ValueError, TypeError, AttributeError):
                    continue
                n_ev += 1
                if not math.isfinite(ts) or abs(ts - float(ba.tb.sim(rx))) > th["event_tsim_tol_s"]:
                    bad_ev += 1
        hist = ba.history_note()
        items.append(("event t_sim vs clock", bad_ev == 0, "%d of %d events off by > %s s%s" % (
            bad_ev, n_ev, fnum(th["event_tsim_tol_s"]), (" (%s)" % hist) if hist else "")))
        if c == "orbit_scout":
            iv = ba.airborne_intervals()
            if not iv:
                for name in ("scout odom (airborne)", "nadir camera_info (airborne)", "command twist (airborne)"):
                    items.append((name, False, "no airborne interval"))
            else:
                md = th["interval_min_s"]
                sc = bd.odoms.get(B.T_SCOUT)
                pooled, per_iv = A.interval_rates(iv, sc["t"], md)
                items.append(("scout odom (airborne)", pooled >= th["scout_odom_hz"] and all(h >= th["scout_odom_hz"] for _i, h in per_iv),
                              "pooled %s Hz, per interval %s" % (fnum(pooled), [fnum(h) for _i, h in per_iv])))
                ci = bd.caminfos.get(B.T_NADIR)
                pooled, per_iv = A.interval_rates(iv, ci["t"] if ci is not None else [], md)
                items.append(("nadir camera_info (airborne)", pooled >= th["nadir_caminfo_hz"] and all(h >= th["nadir_caminfo_hz"] for _i, h in per_iv),
                              "pooled %s Hz" % fnum(pooled)))
                tw = bd.twists.get(B.T_CMD_TWIST)
                stamps = ba.tb.sim(tw[0]) if tw is not None else []
                pooled, per_iv = A.interval_rates(iv, stamps, md)
                items.append(("command twist (airborne)", pooled >= th["cmd_twist_hz"] and all(h >= th["cmd_twist_hz"] for _i, h in per_iv),
                              "pooled %s Hz" % fnum(pooled)))
        frac = sum(1 for _n, ok, _m in items if ok) / len(items)
        failed = [("%s %s" % (n, m)) for n, ok, m in items if not ok]
        o.element("rates and time base", per, frac,
                  ("; ".join("%s %s" % (n, m) for n, ok, m in items)) if not failed else "failing: " + "; ".join(failed),
                  "clock >= %s Hz, rover odom >= %s Hz, hazcam >= %s Hz, >= 1 orbiter camera_info, events within %s s; "
                  "airborne: scout odom >= %s Hz, nadir camera_info >= %s Hz, command twist >= %s Hz"
                  % (fnum(th["clock_hz"]), fnum(th["rover_odom_hz"]), fnum(th["hazcam_hz"]), fnum(th["event_tsim_tol_s"]),
                     fnum(th["scout_odom_hz"]), fnum(th["nadir_caminfo_hz"]), fnum(th["cmd_twist_hz"])),
                  "keep all TA nodes running, stream /option_c/scout/cmd_vel at >= 10 Hz while airborne, stamp "
                  "mission_phase t_sim with the node's sim clock (use_sim_time true)", scope)
    return o


def ag06(ctx: Ctx) -> Outcome:
    o = _o(ctx, "AG-06")
    digest, nfiles = ctx.src()
    if digest is None:
        o.element("src_sha256", o.max_score, 0.0, "src/option_c_scout not found", "your package in src/option_c_scout",
                  "put your ROS 2 package in option_c/src/option_c_scout")
        return o
    got = {}
    for s, c, _scope_, active in _bag_scope_iter(ctx):
        if not active:
            continue
        info = ctx.run_info(s, c)
        if info is not None:
            got[(s, c)] = str(info.get("src_sha256", ""))
    if not got:
        o.element("src_sha256", o.max_score, 0.0, "no readable bag with run_info", "src_sha256 in every bag",
                  "record the bags (AG-03)")
        return o
    vals = set(got.values())
    ok = vals == {digest}
    mism = sorted("%s" % ctx._bag_rel(s, c) for (s, c), v in got.items() if v != digest)
    o.element("src_sha256 identical in every bag and equal to src/option_c_scout", o.max_score, 1.0 if ok else 0.0,
              "%d bags, %d distinct values; the submitted package hashes to %s... (%d files)%s" % (
                  len(got), len(vals), digest[:12], nfiles, ("; mismatching: " + ", ".join(mism)) if mism else ""),
              "one value, equal to the hash of the submitted src/option_c_scout",
              "re-record every bag with the final code and launch argument student_pkg_src:=<path to src/option_c_scout>")
    if not ok:
        ctx.flag("HASH_MISMATCH", "%d bag(s) whose run_info src_sha256 does not match the submitted source (%s...): %s" % (
            len(mism), digest[:12], ", ".join(mism)))
    return o


# ============================================================================================== C2
def _orbital_grid(ba: A.BagAnalysis):
    grids = ba.bd.grids.get(B.T_ORB_GRID, [])
    if not grids:
        return None, "no /option_c/orbital_costmap message"
    orp = ba.phase("orbital_plan_ready")
    if orp is None:
        hint = ba.recording_hint()
        return grids[0], "no orbital_plan_ready event: graded the first orbital costmap" + ((" (%s)" % hint) if hint else "")
    g = _last_before(grids, ba.tb, orp.t_rx)
    if g is None:
        return grids[0], "no orbital costmap before orbital_plan_ready: graded the first one"
    return g, None


def ag07(ctx: Ctx) -> Outcome:
    o = _o(ctx, "AG-07")
    th = ctx.s.th("AG-07")
    spec = ctx.s.grid("orbital")

    def fn(ba, add):
        g, why = _orbital_grid(ba)
        if g is None:
            for name in ("frame", "resolution", "size", "origin", "values"):
                add(name, 0.0, why, "orbital costmap", "publish /option_c/orbital_costmap (transient_local) before orbital_plan_ready")
            return
        if why:
            o.warn("%s: %s" % (ba.bd.name, why))
        geo_ok = _grid_geometry(g, spec, th["resolution_tol"], th["origin_tol"])
        desc = _grid_desc(g)
        add("frame", geo_ok["frame"], "frame %r" % g["frame"], "'map'", "set header.frame_id = 'map'")
        add("resolution", geo_ok["resolution"], desc, "0.50 +- 0.001 m", "info.resolution = 0.5")
        add("size", geo_ok["size"], "%d x %d" % (g["w"], g["h"]), "320 x 320", "info.width = info.height = 320")
        add("origin", geo_ok["origin"], "origin (%s, %s)" % (fnum(g["origin"][0], 3), fnum(g["origin"][1], 3)),
            "(-80.0, -80.0) +- 0.01", "info.origin.position = (-80, -80, 0)")
        dmin = int(g["data"].min()) if len(g["data"]) else None
        dmax = int(g["data"].max()) if len(g["data"]) else None
        add("values", geo_ok["values"], "%d cells, values %s .. %s" % (len(g["data"]), dmin, dmax),
            "width x height cells, each in {-1, 0..100}", "write 0 free, 1-98 cost, 99-100 lethal, -1 unknown")
        n = len(ba.bd.grids.get(B.T_ORB_GRID, []))
        if n > 5:
            o.warn("%s: %d orbital costmap messages (the spec allows <= 5 per run)" % (ba.bd.name, n))
    per_seed(ctx, o, "orbit_only", fn)
    return o


def ag08(ctx: Ctx) -> Outcome:
    o = _o(ctx, "AG-08")
    th = ctx.s.th("AG-08")
    L = ctx.s.lethal()

    def fn(ba, add):
        g, why = _orbital_grid(ba)
        if g is None:
            add("boulders", 0.0, why, ">= 90% boulder centers lethal", "publish the orbital costmap")
            add("sand", 0.0, why, ">= 80% sand samples lethal", "publish the orbital costmap")
            return
        w = ba.world
        bv = geo.grid_values(g, w.boulders.xy)
        rec = float(np.mean(bv >= L)) if len(bv) else 0.0
        add("boulders", rec >= th["boulder_recall_min"], "%d of %d boulder centers in cells >= 99 (%s%%)" % (
            int(np.sum(bv >= L)), len(bv), fnum(100 * rec, 1)), ">= 90%",
            "detect boulders in the orbital image (2.5-4 m disks, >= 5 px) and mark their cells lethal")
        P = _sand_samples(w, float(th["sand_sample_m"]))
        sv = geo.grid_values(g, P)
        cov = float(np.mean(sv >= L)) if len(sv) else 0.0
        add("sand", cov >= th["sand_coverage_min"], "%s%% of %d sand samples in cells >= 99" % (fnum(100 * cov, 1), len(sv)),
            ">= 80%", "segment the bright sand patch and mark it lethal (it is a rover keep-out)")
    per_seed(ctx, o, "orbit_only", fn)
    return o


def ag09(ctx: Ctx) -> Outcome:
    o = _o(ctx, "AG-09")
    th = ctx.s.th("AG-09")

    def fn(ba, add):
        g, why = _orbital_grid(ba)
        if g is None:
            add(None, 0.0, why, "<= 10% false-lethal", "publish the orbital costmap")
            return
        frac, n = _false_lethal(g, ba.world.hazards, ba.r_fp + float(th["near_margin_m"]), ctx.s.lethal(),
                                int(ctx.s.limit("max_grid_cells")))
        add(None, frac <= th["false_lethal_max"], "%s%% of %d lethal cells lie farther than r_fp + 1.0 = %s m from every hazard"
            % (fnum(100 * frac, 1), n, fnum(ba.r_fp + 1.0)), "<= 10%",
            "inflate only by the rover footprint plus a small margin; do not mark texture or shadows as lethal")
    per_seed(ctx, o, "orbit_only", fn)
    return o


def ag10(ctx: Ctx) -> Outcome:
    o = _o(ctx, "AG-10")
    th = ctx.s.th("AG-10")
    need_ends = bool(ctx.s.policy("path_items_require_endpoints", True))

    def fn(ba, add):
        p = _ref_path(ba, B.T_ORB_PATH)
        if p is None or len(p["xyz"]) == 0:
            for name in ("endpoints", "spacing", "clearance", "length"):
                add(name, 0.0, "no /option_c/orbital_path message", "A* path S to G", "publish /option_c/orbital_path (transient_local)")
            return
        pts = p["xyz"][:, :2]
        w = ba.world
        ends, ds, dg = _path_endpoints(pts, w, th["endpoint_tol_m"])
        add("endpoints", ends, "first pose %s m from S, last %s m from G" % (fnum(ds), fnum(dg)), "<= 1.0 m each",
            "start the path at S and end it at G (from run_info)")
        sp = geo.max_spacing(pts)
        add("spacing", sp <= th["max_spacing_m"] + 1e-9, "max spacing %s m over %d poses" % (fnum(sp), len(pts)),
            "<= 1.0 m", "interpolate the A* cells so consecutive poses are <= 1.0 m apart")
        hz = w.boulders
        samp = geo.resample_polyline(pts, float(th["sample_m"]))
        clear, which = geo.min_clearance(samp, hz, ba.r_fp)
        mc = float(np.min(clear)) if len(clear) else float("inf")
        clear_ok = mc >= 0.0 and (ends or not need_ends)
        add("clearance", clear_ok, "minimum footprint clearance %s m to boulders and sand (r_fp %s m)%s" % (
            fnum(mc), fnum(ba.r_fp), "" if (ends or not need_ends) else "; not credited because the endpoints item failed"),
            ">= 0.0 m along the whole path", "inflate boulders and sand by at least r_fp before searching")
        L = geo.polyline_length(pts)
        ref = w.reference_length(ba.r_fp, float(th["reference_inflate_extra_m"]))
        ratio = L / ref if ref else None
        len_ok = ratio is not None and ratio <= th["length_ratio_max"] and clear_ok
        add("length", len_ok, "length %s m, reference A* %s m (ratio %s)%s" % (
            fnum(L), fnum(ref), fnum(ratio, 3), "" if clear_ok else "; credited only for a valid, clear S-to-G path"),
            "<= 1.15 x reference", "use 8-connected A* with an admissible heuristic and do not over-inflate")
    per_seed(ctx, o, "orbit_only", fn)
    return o


# ============================================================================================== C3
def ag11(ctx: Ctx) -> Outcome:
    o = _o(ctx, "AG-11")
    th = ctx.s.th("AG-11")

    def fn(ba, add):
        orp = ba.phase("orbital_plan_ready")
        rs = ba.phase("rover_start", after=orp.t if orp else None)
        end = None
        if rs is not None:
            for p in ba.phases():
                if p.event in ("rover_goal_reached", "rover_aborted") and p.t >= rs.t:
                    end = p
                    break
        ok = orp is not None and rs is not None and end is not None and orp.t < rs.t < end.t + 1e-9
        hint = ba.recording_hint()
        add("phases", ok, "orbital_plan_ready %s, rover_start %s, end %s" % (
            fnum(orp.t, 1) if orp else "missing", fnum(rs.t, 1) if rs else "missing",
            ("%s at %s" % (end.event, fnum(end.t, 1))) if end else "missing"),
            "orbital_plan_ready < rover_start < rover_goal_reached or rover_aborted",
            hint or "publish the mission_phase events in order with t_sim")
        rs_any = rs or ba.phase("rover_start")
        pt = rs_any.extras.get("path_topic") if rs_any else None
        fh = rs_any.extras.get("follower_params_sha256") if rs_any else None
        add("rover_start", bool(rs_any) and pt == PATH_ORBITAL and isinstance(fh, str) and len(fh) > 0,
            "path_topic %r, follower_params_sha256 %s" % (pt, "present" if fh else "missing"),
            "path_topic '/option_c/orbital_path' and a follower_params_sha256 string",
            (hint if rs_any is None and hint else "add path_topic and follower_params_sha256 to the rover_start event"))
        sc = ba.scout()
        zmax = float(np.max(sc["z"])) if sc is not None and len(sc["z"]) else None
        grounded = zmax is not None and zmax <= float(ctx.s.world("airborne_z_m"))
        add("scout_grounded", grounded, "scout max z %s m" % fnum(zmax), "<= 0.5 m (no sorties in condition O)",
            "launch condition:=orbit_only and do not enable the scout")
        if zmax is not None and not grounded:
            ctx.flag("SCOUT_AIRBORNE_IN_ORBIT_ONLY", "%s: scout reached z %s m" % (ba.bd.name, fnum(zmax)))
        nf = ba.bd.count(B.T_FUSED_GRID)
        add("no_fused", nf == 0, "%d fused_costmap messages" % nf, "none in condition O",
            "do not run map_fuser's scouted fusion in condition O")
        req = ba.bd.twists.get(B.T_REQ)
        cmd = ba.bd.twists.get(B.T_RCMD)
        if req is None or len(req[0]) < 2:
            add("guard_rate", 0.0, "no cmd_vel_request stream", ">= 8 Hz cmd_vel while requests stream",
                "send /option_c/rover/cmd_vel_request through the TA guard")
        else:
            tr = ba.tb.sim(req[0])
            gapv = float(ctx.s.timebase("request_stream_gap_s", th["request_gap_s"]))
            iv = []
            a = tr[0]
            for k in range(1, len(tr)):
                if tr[k] - tr[k - 1] > gapv:
                    iv.append((a, tr[k - 1]))
                    a = tr[k]
            iv.append((a, tr[-1]))
            iv = [x for x in iv if x[1] - x[0] >= 1.0]
            tc = ba.tb.sim(cmd[0]) if cmd is not None else np.zeros(0)
            dur = sum(b - a for a, b in iv)
            n = sum(int(np.sum((tc >= a) & (tc <= b))) for a, b in iv)
            hz = n / dur if dur > 0 else 0.0
            add("guard_rate", hz >= th["guard_hz"], "%s Hz of /option_c/rover/cmd_vel over %s s of request streaming"
                % (fnum(hz), fnum(dur, 1)), ">= 8 Hz", "keep the TA rover_hazard_guard running between your executive and the rover")
        vmax = ba.rover_max_speed()
        add("speed", vmax <= th["max_speed_mps"], "max planar speed %s m/s (0.5 s windows)" % fnum(vmax), "<= 1.1 m/s",
            "drive only through the TA guard (cap 1.0 m/s)")
        if vmax > th["max_speed_mps"]:
            ctx.flag("SPEED_ABOVE_CAP", "%s: rover truth speed %s m/s" % (ba.bd.name, fnum(vmax)))
    per_seed(ctx, o, "orbit_only", fn)
    return o


def _active_rule_elements(ba, add, ref_topic: str, ref_name: str):
    ref = _ref_path(ba, ref_topic)
    rules = active_path_rules(ba, ref["xyz"][:, :2] if ref is not None else None)
    th = ba.s.th("AG-12")
    if rules.get("why"):
        hint = ba.recording_hint()
        add("first", 0.0, rules["why"], "first active_path = the %s" % ref_name,
            hint or "publish /option_c/rover/active_path at rover_start")
        add("later", 0.0, rules["why"], "valid replans", hint or "publish each replan on /option_c/rover/active_path")
    else:
        add("first", rules["first_ok"], "Hausdorff distance %s m to the %s" % (fnum(rules["first_h"]), ref_name)
            if rules["first_h"] is not None else "no %s message" % ref_name, "<= 0.5 m (0.1 m resampling)",
            "publish the %s itself as the first active_path" % ref_name)
        bad = rules["later_bad"]
        n_later = len(ba.drive().get("active_paths", [])) - 1
        add("later", rules["later_ok"], "%d replans, %d invalid%s" % (max(0, n_later), len(bad),
            ("; e.g. #%d %s" % bad[0]) if bad else ""), "start <= 1.5 m from the rover, end <= 1.5 m from G, spacing <= 1.0 m",
            "replan from the rover's current pose to G and densify the path")
    add("count", rules["count_ok"], "%d active_path messages" % rules["n"], "<= %d" % int(th["max_messages"]),
        "replan only when the active path is blocked")
    return rules


def ag12(ctx: Ctx) -> Outcome:
    o = _o(ctx, "AG-12")
    per_seed(ctx, o, "orbit_only", lambda ba, add: _active_rule_elements(ba, add, B.T_ORB_PATH, "orbital path"))
    return o


def ag13(ctx: Ctx) -> Outcome:
    o = _o(ctx, "AG-13")

    def fn(ba, add):
        d = ba.drive()
        if not d.get("ok"):
            add(None, 0.0, "no rover_start event or no rover odometry", "within 1.5 m of G within 900 s",
                ba.recording_hint() or "emit rover_start and drive")
            return
        add(None, d["reached_goal"], "closest approach to G %s m within 900 s of rover_start" % fnum(d["min_goal_dist"]),
            "<= 1.5 m", "tune the follower and hazcam replanning so the rover reaches G")
    per_seed(ctx, o, "orbit_only", fn)
    return o


def ag14(ctx: Ctx) -> Outcome:
    o = _o(ctx, "AG-14")

    def fn(ba, add):
        d = ba.drive()
        if not d.get("ok"):
            add(None, 0.0, "no rover_start event or no rover odometry", "zero intrusions",
                ba.recording_hint() or "emit rover_start and drive")
            return
        add(None, d["intrusions"] == 0, "%d intrusions%s; minimum clearance %s m" % (
            d["intrusions"], (" (%s)" % ", ".join(d["intrusion_ids"][:6])) if d["intrusions"] else "", fnum(d["min_clearance_m"])),
            "0 (footprint overlap >= 0.2 s with a boulder, rock or the sand patch)",
            "insert hazcam detections with enough radius and replan before the guard has to stop you")
    per_seed(ctx, o, "orbit_only", fn)
    return o


# ============================================================================================== C4
def _need_sorties(ba, add, names):
    if ba.sorties():
        return True
    for n in names:
        add(n, 0.0, "the scout never flew (grader scout odometry z never above 0.5 m)", "1 to 3 sorties",
            "launch condition:=orbit_scout and fly your sorties while recording")
    return False


def ag15(ctx: Ctx) -> Outcome:
    o = _o(ctx, "AG-15")
    th = ctx.s.th("AG-15")

    def fn(ba, add):
        if not _need_sorties(ba, add, ("budget", "altitude")):
            return
        ss = ba.sorties()
        durs = [s.duration for s in ss]
        ok = len(ss) <= th["max_sorties"] and all(dd <= th["max_airborne_s"] + 1e-9 for dd in durs)
        add("budget", ok, "%d sorties, airborne %s s" % (len(ss), [fnum(dd, 1) for dd in durs]),
            "<= 3 sorties, each <= 90.0 s", "plan sorties that land within 90 s (the watchdog forces descent at 120 s)")
        sc = ba.scout()
        vh = ba.scout_hspeed()
        z = sc["z"]
        air = np.zeros(len(z), dtype=bool)
        for s in ss:
            air[s.i0:s.i1 + 1] = True
        cruise = air & (vh > th["cruise_speed_mps"])
        band = (z >= th["band_lo_m"]) & (z <= th["band_hi_m"])
        frac = float(np.mean(band[cruise])) if np.any(cruise) else 1.0
        zmax = float(np.max(z))
        add("altitude", zmax <= th["ceiling_m"] and frac >= th["band_fraction_min"],
            "max z %s m; %s%% of %d samples above 0.5 m/s in [8, 15] m" % (fnum(zmax), fnum(100 * frac, 1), int(np.sum(cruise))),
            "z <= 15.5 m; >= 95% of cruise samples in [8, 15] m", "climb to the cruise band before moving horizontally")
    per_seed(ctx, o, "orbit_scout", fn)
    return o


def _event_time(ev):
    rx_t, ts, _name = ev
    return ts if ts is not None and math.isfinite(ts) and abs(ts - rx_t) <= 1.0 else rx_t


def ag16(ctx: Ctx) -> Outcome:
    o = _o(ctx, "AG-16")
    th = ctx.s.th("AG-16")

    def fn(ba, add):
        if not _need_sorties(ba, add, ("events", "cmd_timeout", "xy")):
            return
        ev = ba.events()
        bad = [e for e in ev if e[2] in ("geofence", "ceiling", "forced_descent")]
        add("events", not bad, "%d geofence/ceiling/forced_descent events%s" % (len(bad), (" (%s)" % ", ".join(sorted({e[2] for e in bad}))) if bad else ""),
            "0", "stay inside [-78, 78] m, below 20 m, and land within 120 s")
        m = th["sortie_event_margin_s"]
        worst = 0
        for s in ba.sorties():
            n = sum(1 for e in ev if e[2] == "cmd_timeout" and s.t_takeoff - m <= _event_time(e) <= s.t_land + m)
            worst = max(worst, n)
        add("cmd_timeout", worst <= th["max_cmd_timeouts_per_sortie"], "worst sortie: %d cmd_timeout events" % worst,
            "<= 3 per sortie", "publish /option_c/scout/cmd_vel at >= 10 Hz without pauses while airborne")
        sc = ba.scout()
        ext = float(max(np.max(np.abs(sc["x"])), np.max(np.abs(sc["y"]))))
        add("xy", ext <= th["geofence_m"], "max |x|, |y| = %s m" % fnum(ext), "<= 78 m", "keep sortie plans inside the geofence")
    per_seed(ctx, o, "orbit_scout", fn)
    return o


def ag17(ctx: Ctx) -> Outcome:
    o = _o(ctx, "AG-17")
    th = ctx.s.th("AG-17")

    def fn(ba, add):
        if not _need_sorties(ba, add, ("touchdown", "site")):
            return
        sc = ba.scout()
        t, x, y = sc["t"], sc["x"], sc["y"]
        ss = ba.sorties()
        td_ok, site_ok, details = 0, 0, []
        hz = ba.world.hazards
        for s in ss:
            if not s.landed:
                details.append("#%d never landed" % (s.k + 1))
                continue
            win = (t >= s.t_land - th["window_s"]) & (t <= s.t_land + 1e-9)
            idx = np.nonzero(win)[0]
            vmax = 0.0
            for a, b in zip(idx[:-1], idx[1:]):
                dt = t[b] - t[a]
                if dt > 1e-6:
                    vmax = max(vmax, float(np.hypot(x[b] - x[a], y[b] - y[a]) / dt))
            ok1 = vmax < th["touchdown_speed_max"]
            td_ok += ok1
            if s.landing_xy is None:
                details.append("#%d touchdown %s m/s, no sample with z < 0.2 m after landing" % (s.k + 1, fnum(vmax)))
                continue
            c, _w = geo.min_clearance(np.array([s.landing_xy]), hz, 0.0)
            ok2 = float(c[0]) >= th["site_clearance_m"]
            site_ok += ok2
            details.append("#%d touchdown %s m/s, site clearance %s m" % (s.k + 1, fnum(vmax), fnum(float(c[0]))))
        n = len(ss)
        add("touchdown", td_ok / n, "%d of %d sorties below 0.5 m/s over the 2 s before z < 0.5 m (%s)" % (td_ok, n, "; ".join(details)),
            "< 0.5 m/s horizontal (fraction of sorties)", "stop horizontal motion before descending and descend vertically")
        add("site", site_ok / n, "%d of %d landing sites >= 1.5 m from every hazard edge and off the sand" % (site_ok, n),
            ">= 1.5 m clearance, outside the sand polygon (fraction of sorties)",
            "check landing sites against your orbital and scout hazard maps before descending")
    per_seed(ctx, o, "orbit_scout", fn)
    return o


def _plans_for_sorties(ba):
    plans = ba.bd.paths.get(B.T_PLAN, [])
    tol = float(ba.s.th("AG-18")["receive_after_takeoff_tol_s"])
    out = []
    prev = -float("inf")
    for s in ba.sorties():
        cands = [p for p in plans if prev <= p["t"] < s.t_takeoff and float(ba.tb.sim(p["rx"])) <= s.t_takeoff + tol
                 and len(p["xyz"])]
        out.append(cands[-1] if cands else None)
        prev = s.t_takeoff
    return out


def ag18(ctx: Ctx) -> Outcome:
    o = _o(ctx, "AG-18")
    th = ctx.s.th("AG-18")
    t15 = ctx.s.th("AG-15")

    def fn(ba, add):
        if not _need_sorties(ba, add, ("plans", "crosstrack")):
            return
        plans = _plans_for_sorties(ba)
        have = sum(1 for p in plans if p is not None)
        n = len(plans)
        add("plans", have == n, "%d of %d sorties have a sortie_plan stamped before takeoff" % (have, n),
            "every sortie", "publish one /option_c/sortie_plan (header.stamp = now) before each takeoff")
        sc = ba.scout()
        vh = ba.scout_hspeed()
        sq, cnt = 0.0, 0
        for s, p in zip(ba.sorties(), plans):
            if p is None:
                continue
            sl = slice(s.i0, s.i1 + 1)
            z = sc["z"][sl]
            sel = (vh[sl] > t15["cruise_speed_mps"]) & (z >= t15["band_lo_m"]) & (z <= t15["band_hi_m"])
            if not np.any(sel):
                continue
            P = np.stack([sc["x"][sl][sel], sc["y"][sl][sel]], axis=1)
            dd = geo.dist_points_polyline(P, p["xyz"][:, :2])
            sq += float(np.sum(dd ** 2))
            cnt += len(dd)
        rms = math.sqrt(sq / cnt) if cnt else None
        add("crosstrack", rms is not None and rms <= th["crosstrack_rms_max_m"],
            "cross-track RMS %s m over %d cruise samples" % (fnum(rms), cnt) if rms is not None else
            "no cruise samples (speed > 0.5 m/s, z in [8, 15] m) on a sortie with a plan",
            "<= 1.5 m", "follow the planned polyline with a cross-track correction")
    per_seed(ctx, o, "orbit_scout", fn)
    return o


# ============================================================================================== C5
def ag19(ctx: Ctx) -> Outcome:
    o = _o(ctx, "AG-19")
    for s in ctx.seeds:
        ba, why = ctx.analysis(s, "orbit_scout")
        scope = _scope(s, "orbit_scout")
        if ba is None:
            o.info("footprint union", "not computed: " + why, scope=scope)
            continue
        U, used, total = ba.union_main()
        o.info("footprint union", "%d of %d nadir frames taken at 6-16 m; scouted area %s m2" % (used, total, fnum(ba.area_m2(U), 1)),
               "frames with scout z in [6, 16] m, 0.25 m grid", scope)
    return o


def read_mosaic(ctx: Ctx, seed: int, drift: bool = False):
    """(observed bool [j, i] on the union grid, gray image array, alpha array, problems); cached per seed."""
    cache = ctx.__dict__.setdefault("_mosaic_cache", {})
    if (seed, drift) not in cache:
        cache[(seed, drift)] = _read_mosaic(ctx, seed, drift)
    return cache[(seed, drift)]


def _read_mosaic(ctx: Ctx, seed: int, drift: bool = False):
    rd = ctx.results_dir(seed, drift)
    if rd is None:
        return None, None, None, ["no option_c folder"]
    spec = ctx.s.grid("mosaic")
    problems = []
    jp, pp = rd / "scout_mosaic.json", rd / "scout_mosaic.png"
    if not jp.is_file():
        problems.append("scout_mosaic.json missing")
    else:
        try:
            m = json.loads(jp.read_text(encoding="utf-8"))
            if not isinstance(m, dict):
                raise ValueError
            if abs(float(m.get("resolution_m", -1)) - spec["resolution_m"]) > 1e-9:
                problems.append("resolution_m %r (need 0.10)" % m.get("resolution_m"))
            org = m.get("origin_xy_m")
            if not (isinstance(org, list) and len(org) == 2 and all(abs(float(a) - b) < 1e-9 for a, b in zip(org, spec["origin_xy_m"]))):
                problems.append("origin_xy_m %r (need [-80.0, -80.0])" % (org,))
            if m.get("width_px") != spec["width_px"] or m.get("height_px") != spec["height_px"]:
                problems.append("width_px x height_px %r x %r (need 1600 x 1600)" % (m.get("width_px"), m.get("height_px")))
            if m.get("north_up") is not True:
                problems.append("north_up %r (need true)" % m.get("north_up"))
            if "frame" in m and m.get("frame") != spec["frame"]:
                problems.append("frame %r (need 'map')" % m.get("frame"))
        except (ValueError, TypeError):
            problems.append("scout_mosaic.json does not parse as a JSON object")
    if not pp.is_file():
        problems.append("scout_mosaic.png missing")
        return None, None, None, problems
    try:
        from PIL import Image
        with Image.open(pp) as im:
            if im.size != (spec["width_px"], spec["height_px"]) or im.mode != "RGBA":
                problems.append("scout_mosaic.png is %dx%d %s (need 1600 x 1600 RGBA)" % (im.size[0], im.size[1], im.mode))
                return None, None, None, problems
            arr = np.asarray(im.convert("RGBA"))
    except Exception as exc:  # noqa: BLE001
        problems.append("scout_mosaic.png cannot be read (%s)" % type(exc).__name__)
        return None, None, None, problems
    alpha = arr[:, :, 3]
    gray = (0.299 * arr[:, :, 0] + 0.587 * arr[:, :, 1] + 0.114 * arr[:, :, 2]).astype(np.float32)
    g = ctx.s.grid("union")
    res, W, H = g["resolution_m"], g["width"], g["height"]
    mres = spec["resolution_m"]
    ii = np.arange(W)
    jj = np.arange(H)
    cols = np.clip(np.floor(((ii + 0.5) * res) / mres + 1e-9).astype(int), 0, spec["width_px"] - 1)
    rows = np.clip(spec["height_px"] - 1 - np.floor(((jj + 0.5) * res) / mres + 1e-9).astype(int), 0, spec["height_px"] - 1)
    observed = alpha[rows[:, None], cols[None, :]] == 255
    return observed, gray, alpha, problems


def ag20(ctx: Ctx) -> Outcome:
    o = _o(ctx, "AG-20")
    th = ctx.s.th("AG-20")

    def fn(ba, add):
        s = ba.world.seed
        observed, _g, _a, problems = read_mosaic(ctx, s)
        if problems:
            add(None, 0.0, "; ".join(problems), "scout_mosaic.json exactly as specified and a 1600 x 1600 RGBA PNG",
                "write results/seed%d/scout_mosaic.{png,json} as in the deliverables tree" % s)
            return
        U, used, _tot = ba.union_main()
        if not U.any():
            add(None, 0.0, "the footprint union is empty (no nadir frames at 6-16 m)", "IoU >= 0.80",
                "fly the sorties at 8-15 m with the TA nodes recording camera_info")
            return
        inter = float(np.sum(observed & U))
        union = float(np.sum(observed | U))
        iou = inter / union if union else 0.0
        add(None, linear_credit(iou, th["iou_zero"], th["iou_full"]),
            "IoU %s between observed pixels (alpha 255) and the grader's footprint union (%d frames)" % (fnum(iou, 3), used),
            ">= 0.80 full credit, linear from 0.50", "project every frame with K, the mount and the full 6-DoF pose, and set "
            "alpha 255 only where a frame landed")
    per_seed(ctx, o, "orbit_scout", fn)
    return o


def ag21(ctx: Ctx) -> Outcome:
    o = _o(ctx, "AG-21")
    th = ctx.s.th("AG-21")

    def fn(ba, add):
        s = ba.world.seed
        rows = SUB.read_hazards_csv(ctx.results_dir(s) / "scout_hazards.csv", int(ctx.s.limit("max_hazard_rows")))
        if "missing" in rows.problems:
            add("recall", 0.0, "results/seed%d/scout_hazards.csv missing" % s, "recall >= 0.70", "write scout_hazards.csv")
            add("precision", 0.0, "results/seed%d/scout_hazards.csv missing" % s, "precision >= 0.70", "write scout_hazards.csv")
            return
        U, _used, _tot = ba.union_main()
        rocks = ba.world.rocks
        inside = ba.disks_inside_union(U, rocks)
        R = rocks.xy[inside]
        X = np.array(rows.xy, dtype=np.float64).reshape(-1, 2)
        if len(R) == 0:
            add("recall", 0.0, "no ground-truth small rock lies wholly inside your scouted footprint union",
                "recall >= 0.70 over rocks inside the union", "fly coverage lines over the rock fields on the orbital route")
        else:
            D = np.sqrt(((X[:, None, :] - R[None, :, :]) ** 2).sum(axis=2)) if len(X) else np.zeros((0, len(R)))
            m = greedy_match(D, th["match_m"])
            rec = m / len(R)
            add("recall", linear_credit(rec, th["zero"], th["full"]), "%d of %d rocks inside the union matched within 0.5 m (recall %s)"
                % (m, len(R), fnum(rec, 3)), ">= 0.70 full, linear from 0.40", "detect 0.4-0.9 m rocks in the mosaic and report their centers")
        dil = ba.dilate(U, int(round(th["union_tolerance_m"] / ctx.s.grid("union")["resolution_m"])))
        inu = ba.in_union(dil, X) if len(X) else np.zeros(0, dtype=bool)
        Xi = X[inu]
        if len(Xi) == 0:
            add("precision", 0.0, "no scout_hazards.csv rows inside the scouted footprint union (%d rows in total)" % len(X),
                "precision >= 0.70", "report the rocks you detected in the mosaic")
        else:
            hz = ba.world.hazards
            D = np.sqrt(((Xi[:, None, :] - hz.xy[None, :, :]) ** 2).sum(axis=2))
            true = np.any(D <= hz.r[None, :] + th["match_m"], axis=1)
            prec = float(np.mean(true))
            add("precision", linear_credit(prec, th["zero"], th["full"]), "%d of %d rows inside the union within r_h + 0.5 m of a hazard "
                "center (precision %s)" % (int(true.sum()), len(Xi), fnum(prec, 3)), ">= 0.70 full, linear from 0.40",
                "suppress texture false positives and merge duplicate detections")
        for p in rows.problems:
            o.warn("seed %d scout_hazards.csv: %s" % (s, p))
    per_seed(ctx, o, "orbit_scout", fn)
    return o


# ============================================================================================== C6
def _fused_grid(ba: A.BagAnalysis):
    grids = ba.bd.grids.get(B.T_FUSED_GRID, [])
    t_td = ba.last_touchdown()
    rs = ba.phase("rover_start")
    cands = []
    for g in grids:
        tr = float(ba.tb.sim(g["rx"]))
        if t_td is not None and (g["t"] <= t_td or tr < t_td - 0.5):
            continue
        if rs is not None and (tr > rs.t_rx + 0.5 or g["t"] > rs.t + 0.5):
            continue
        cands.append(g)
    return (cands[-1] if cands else None), len(grids), t_td, rs


def ag22(ctx: Ctx) -> Outcome:
    o = _o(ctx, "AG-22")
    th = ctx.s.th("AG-22")
    spec = ctx.s.grid("fused")
    L = ctx.s.lethal()

    def fn(ba, add):
        g, n, t_td, rs = _fused_grid(ba)

        def zero(msg, fix):
            for name in ("boulders", "rocks", "false_lethal"):
                add(name, 0.0, msg, "a valid fused costmap (gate)", fix)

        if n == 0:
            return zero("no /option_c/fused_costmap message", "publish the fused costmap after the last touchdown")
        if n > th["max_messages"]:
            return zero("%d fused_costmap messages" % n, "publish at most 5 fused costmaps per run")
        if g is None:
            return zero("no fused costmap stamped after the last touchdown (%s s) and before rover_start" % fnum(t_td, 1),
                        "fuse after the last landing, then emit fused_plan_ready and rover_start")
        gg = _grid_geometry(g, spec, th["resolution_tol"], th["origin_tol"])
        if not all(gg.values()):
            return zero("wrong geometry: %s%s" % (_grid_desc(g), "" if gg["values"] else "; values outside {-1, 0..100}"),
                        "frame 'map', 0.25 m, 640 x 640, origin (-80, -80)")
        w = ba.world
        bv = geo.grid_values(g, w.boulders.xy)
        rec = float(np.mean(bv >= L)) if len(bv) else 0.0
        add("boulders", rec >= th["boulder_recall_min"], "boulder recall %s" % fnum(rec, 3), ">= 0.90", "carry the orbital boulders into the fused map")
        U, _u, _t = ba.union_main()
        rocks = w.rocks
        inside = ba.disks_inside_union(U, rocks)
        if not np.any(inside):
            add("rocks", 0.0, "no ground-truth rock lies wholly inside the scouted union", ">= 0.70",
                "scout the rock fields on the orbital route")
        else:
            rv = geo.grid_values(g, rocks.xy[inside])
            rr = float(np.mean(rv >= L))
            add("rocks", rr >= th["rock_recall_min"], "%d of %d scouted rocks lethal (%s)" % (int(np.sum(rv >= L)), int(inside.sum()), fnum(rr, 3)),
                ">= 0.70 with center cell >= 99", "insert scout detections as inflated lethal disks")
        hz = ba.drive_hazards()
        frac, nl = _false_lethal(g, hz, ba.r_fp + float(th["near_margin_m"]), L, int(ctx.s.limit("max_grid_cells")))
        add("false_lethal", frac <= th["false_lethal_max"], "%s%% of %d lethal cells farther than r_fp + 1.0 m from every hazard"
            % (fnum(100 * frac, 1), nl), "<= 15%", "inflate by the footprint plus a small margin only")
    per_seed(ctx, o, "orbit_scout", fn)
    return o


def ag23(ctx: Ctx) -> Outcome:
    o = _o(ctx, "AG-23")
    th = ctx.s.th("AG-23")
    need_ends = bool(ctx.s.policy("path_items_require_endpoints", True))

    def fn(ba, add):
        p = _ref_path(ba, B.T_FUSED_PATH)
        t_td = ba.last_touchdown()
        fpr = ba.phase("fused_plan_ready", last=True)
        if p is None or len(p["xyz"]) == 0:
            add("plan", 0.0, "no /option_c/fused_path message", "fused path S to G", "publish /option_c/fused_path")
            add("clearance", 0.0, "no /option_c/fused_path message", "clearance >= 0", "publish /option_c/fused_path")
            return
        pts = p["xyz"][:, :2]
        w = ba.world
        ends, ds, dg = _path_endpoints(pts, w, th["endpoint_tol_m"])
        sp = geo.max_spacing(pts)
        after = fpr is not None and (t_td is None or fpr.t > t_td)
        add("plan", ends and sp <= th["max_spacing_m"] + 1e-9 and after,
            "fused_plan_ready %s (last touchdown %s s); endpoints %s / %s m; spacing %s m" % (
                ("at %s s" % fnum(fpr.t, 1)) if fpr else "missing", fnum(t_td, 1), fnum(ds), fnum(dg), fnum(sp)),
            "fused_plan_ready after the last touchdown, endpoints <= 1.0 m, spacing <= 1.0 m",
            "replan on the fused costmap after the last landing and emit fused_plan_ready")
        U, _u, _t = ba.union_main()
        hz = w.hazards
        keep = hz.kinds("boulder") | (hz.kinds("rock") & ba.disks_inside_union(U, hz))
        sub = hz.subset(keep)
        xy = ba.scout_rest_xy()
        if xy is not None:
            sub = sub.with_disk(xy[0], xy[1], float(ctx.s.world("landed_scout_radius_m")), "scout", "landed_scout")
        samp = geo.resample_polyline(pts, float(th["sample_m"]))
        c, _w = geo.min_clearance(samp, sub, ba.r_fp)
        mc = float(np.min(c)) if len(c) else float("inf")
        ok = mc >= 0.0 and (ends or not need_ends)
        add("clearance", ok, "minimum clearance %s m to boulders, sand, %d scouted rocks and the landed scout%s" % (
            fnum(mc), int(np.sum(sub.kinds("rock"))), "" if (ends or not need_ends) else "; not credited without valid endpoints"),
            ">= 0.0 m", "inflate every scouted rock and the landed scout (0.35 m) by r_fp before searching")
    per_seed(ctx, o, "orbit_scout", fn)
    return o


def ag24(ctx: Ctx) -> Outcome:
    o = _o(ctx, "AG-24")
    th = ctx.s.th("AG-24")

    def fn(ba, add):
        d = ba.drive()
        rs = d.get("rover_start")
        fpr = ba.phase("fused_plan_ready", last=True, before=rs.t if rs else None)
        ref = _ref_path(ba, B.T_FUSED_PATH)
        rules = active_path_rules(ba, ref["xyz"][:, :2] if ref is not None else None)
        gate = []
        if rs is None:
            gate.append("no rover_start")
        else:
            if rs.extras.get("path_topic") != PATH_FUSED:
                gate.append("rover_start path_topic %r (need '/option_c/fused_path')" % rs.extras.get("path_topic"))
            if fpr is None:
                gate.append("no fused_plan_ready before rover_start")
        if not rules["first_ok"]:
            gate.append("first active_path is not the fused path (Hausdorff %s m)" % fnum(rules["first_h"]))
        if not rules["later_ok"] and not rules.get("why"):
            gate.append("%d invalid replans" % len(rules["later_bad"]))
        if not rules["count_ok"]:
            gate.append("%d active_path messages" % rules["n"])
        if rules.get("why"):
            gate.append(rules["why"])
        hint = ba.recording_hint()
        if not d.get("ok"):
            for name in ("arrival", "intrusions", "stops", "scouted"):
                add(name, 0.0, "no rover_start or no rover odometry", "a scouted drive",
                    hint or "emit rover_start and drive the fused path")
            return
        add("arrival", d["reached_goal"] and not gate, "closest approach to G %s m%s" % (
            fnum(d["min_goal_dist"]), ("; hand-off gate failed: " + "; ".join(gate)) if gate else ""),
            "within 1.5 m of G within 900 s, and the hand-off gate",
            (hint if gate and hint else "start the drive on /option_c/fused_path after fused_plan_ready"))
        add("intrusions", d["intrusions"] == 0, "%d intrusions%s" % (d["intrusions"], (" (%s)" % ", ".join(d["intrusion_ids"][:6])) if d["intrusions"] else ""),
            "0, the landed scout included", "plan around every scouted rock and the landed scout")
        add("stops", d["hazard_stops"] <= th["max_hazard_stops"], "%d hazard stops" % d["hazard_stops"], "<= 1",
            "scout the corridor the rover will drive so the guard does not have to stop it")
        U, _u, _t = ba.union_main()
        frac = ba.scouted_path_fraction(U)
        add("scouted", frac is not None and frac >= th["scouted_fraction_min"],
            "scouted_path_fraction %s" % fnum(frac, 3), ">= 0.90 of the executed length with the footprint inside the union",
            "plan the fused path through scouted ground (unknown-cell policy) or scout the whole corridor")
    per_seed(ctx, o, "orbit_scout", fn)
    return o


# ============================================================================================== C7
def _as_bool(v):
    t = str(v).strip().lower()
    if t in ("1", "true", "yes", "y", "t"):
        return True
    if t in ("0", "false", "no", "n", "f"):
        return False
    try:
        return float(t) != 0.0
    except ValueError:
        return None


def _as_float(v):
    try:
        x = float(str(v).strip())
        return x
    except (TypeError, ValueError):
        return None


def _cond_of(v):
    t = str(v).strip().lower()
    if t in ("orbit_only", "o", "orbit-only", "orbitonly"):
        return "orbit_only"
    if t in ("orbit_scout", "s", "orbit-scout", "orbitscout"):
        return "orbit_scout"
    return None


NA_TOKENS = ("", "n/a", "na", "nan", "none", "null", "-")


def _is_na(v) -> bool:
    """A comparison_table cell that means 'not available': empty, n/a, na, nan, none, null or '-'."""
    if v is None:
        return True
    if isinstance(v, float) and math.isnan(v):
        return True
    return str(v).strip().lower() in NA_TOKENS


def _ref_is_na(ref) -> bool:
    return ref is None or (isinstance(ref, float) and not math.isfinite(ref))


def compare_value(col: str, student, ref, tol: dict):
    """(ok, text) for one comparison_table cell. When the grader cannot compute a value (ref None, for
    example a bag without rover_start), a not-available cell (NA_TOKENS) matches in every column, count
    columns included; when it can, a not-available cell never matches."""
    if _ref_is_na(ref):
        return _is_na(student), "%s vs n/a" % (student if str(student).strip() else "(empty)")
    if _is_na(student):
        return False, "%s vs %s" % ("n/a" if str(student).strip() else "(empty)",
                                    ref if col in tol["counts_exact"] else fnum(ref, 3))
    if col in tol["counts_exact"]:
        if col == "reached_goal":
            sv = _as_bool(student)
            return (sv is not None and bool(sv) == bool(ref)), "%s vs %s" % (student, ref)
        sv = _as_float(student)
        return (sv is not None and math.isfinite(sv) and int(round(sv)) == int(ref)
                and abs(sv - round(sv)) < 1e-6), "%s vs %s" % (student, ref)
    sv = _as_float(student)
    if sv is None or not math.isfinite(sv):
        return False, "%s vs %s" % (student, fnum(ref, 3))
    for kind in ("length", "time", "fraction", "ratio", "energy", "area"):
        spec = tol[kind]
        if col in spec["columns"]:
            allow = max(float(spec.get("rel", 0.0)) * abs(ref), float(spec.get("abs", 0.0)))
            return abs(sv - ref) <= allow + 1e-9, "%s vs %s (tolerance %s)" % (fnum(sv, 3), fnum(ref, 3), fnum(allow, 3))
    return abs(sv - ref) <= 1e-6, "%s vs %s" % (student, ref)


def ag25(ctx: Ctx) -> Outcome:
    o = _o(ctx, "AG-25")
    ct = ctx.s.spec["comparison_table"]
    cols = list(ct["columns"])
    tol = ct["tolerance"]
    path = ctx.root / "results" / "comparison_table.csv" if ctx.root else None
    metrics = ctx.metrics()
    if path is None or not path.is_file():
        o.element("table", ctx.s.el("AG-25", "table"), 0.0, "results/comparison_table.csv missing", "6 rows, every column",
                  "write results/comparison_table.csv from your analysis scripts")
    else:
        try:
            header, rows = SUB.read_csv_dicts(path)
        except Exception as exc:  # noqa: BLE001
            header, rows = [], []
            o.warn("comparison_table.csv could not be parsed (%s)" % type(exc).__name__)
        miss = [c for c in cols if c not in header]
        if miss:
            o.element("table", ctx.s.el("AG-25", "table"), 0.0, "missing columns: " + ", ".join(miss), ", ".join(cols),
                      "use exactly the column names of the deliverables tree")
        else:
            good = 0
            for s in ctx.seeds:
                for c in CONDS:
                    scope = _scope(s, c)
                    cand = [r for r in rows if str(r.get("seed", "")).strip() == str(s) and _cond_of(r.get("condition")) == c]
                    ref = metrics.get((s, c))
                    if not cand:
                        o.info("row", "row missing", "seed %d, condition %s" % (s, c), scope)
                        continue
                    if ref is None:
                        o.info("row", "the bag does not pass AG-02, so the row cannot be verified", "a valid bag", scope)
                        continue
                    row = cand[0]
                    bad = []
                    for col in cols[2:]:
                        ok, text = compare_value(col, row.get(col), ref.get(col), tol)
                        if not ok:
                            bad.append("%s %s" % (col, text))
                    if not bad:
                        good += 1
                        o.info("row", "all values within tolerance", "spec tolerances", scope)
                    else:
                        o.info("row", "%d values differ: %s" % (len(bad), "; ".join(bad[:5])), "spec tolerances", scope)
            o.element("table rows within tolerance", ctx.s.el("AG-25", "table"), good / 6.0,
                      "%d of 6 rows match the grader's recomputation" % good,
                      "lengths max(5%, 0.5 m); times max(5%, 1.0 s); fractions +-0.03; counts exact",
                      "compute the metrics from your bags with the definitions in the handout (see MET-00 for the "
                      "grader's values)")
    good_f = 0
    for s in ctx.seeds:
        vals = []
        for c in CONDS:
            ba, _w = ctx.analysis(s, c)
            rs = ba.phase("rover_start") if ba else None
            vals.append(rs.extras.get("follower_params_sha256") if rs else None)
        if vals[0] and vals[0] == vals[1] and isinstance(vals[0], str):
            good_f += 1
        else:
            o.info("follower_params_sha256", "O %s, S %s" % ("present" if vals[0] else "missing", "present" if vals[1] else "missing")
                   + ("" if not (vals[0] and vals[1]) else (", %s" % ("identical" if vals[0] == vals[1] else "different"))),
                   "identical in both conditions", _scope(s, "both"))
    o.element("follower_params_sha256 identical between O and S", ctx.s.el("AG-25", "follower"), good_f / 3.0,
              "%d of 3 seeds" % good_f, "the same rover executive parameters in both conditions",
              "use one parameter set for the rover executive and publish its hash in rover_start")
    return o


# ============================================================================================== bonus
def agb1(ctx: Ctx) -> Outcome:
    o = _o(ctx, "AG-B1")
    o.max_score = 0.0
    th = ctx.s.th("AG-B1")
    if not ctx.seeds:
        o.info("bonus", "no seeds", "netid in config")
        o.bonus_value = 0.0
        return o
    s0 = ctx.seeds[0]
    cond = "orbit_scout_drift"
    scope = "seed %d (orbit_scout_drift)" % s0
    bd = ctx.bag(s0, cond)
    val = 0.0
    if bd is None:
        o.info("drift bag", "bonus_drift/bags/seed%d_orbit_scout_drift not submitted (the bonus is optional)" % s0,
               "optional", scope)
        o.bonus_value = 0.0
        return o
    gate = []
    good, problems = ctx.ag02(s0, cond)
    if not good:
        gate.extend(problems)
    if bd.readable:
        span = A.TimeBase(bd.clock_rx, bd.clock_sim).span()
        if span < float(ctx.s.bag_rule("min_sim_s")):
            gate.append("%s s of sim time (>= 60 s)" % fnum(span, 1))
        if bd.size_bytes > int(ctx.s.bag_rule("max_bytes")):
            gate.append("%.1f MB (<= 25 MB)" % (bd.size_bytes / 1e6))
        for t in ctx.s.spec["required_topics"]["drift"]:
            if t not in bd.topics or bd.count(t) == 0:
                gate.append("%s missing or empty" % t)
    digest, _n = ctx.src()
    info = ctx.run_info(s0, cond) or {}
    if ctx.s.policy("bonus_requires_matching_src_hash", True) and digest and info.get("src_sha256") != digest:
        gate.append("src_sha256 differs from the submitted src/option_c_scout")
        ctx.flag("HASH_MISMATCH", "bonus drift bag src_sha256 differs from the submitted source")
    if gate:
        o.element("gate (AG-02, AG-03, drift topics)", 0.0, 0.0, "; ".join(gate), "a valid drift bag", "re-record the drift run", scope)
        o.info("bonus value", "0 of 3", "", scope)
        o.bonus_value = 0.0
        return o
    ba, _why = ctx.analysis(s0, cond)
    rows = SUB.read_hazards_csv(ctx.results_dir(s0, drift=True) / "scout_hazards.csv", int(ctx.s.limit("max_hazard_rows")))
    U, _u, _t = ba.union_main()
    X = np.array(rows.xy, dtype=np.float64).reshape(-1, 2)
    dil = ba.dilate(U, 4)
    Xi = X[ba.in_union(dil, X)] if len(X) else X
    if len(Xi) < int(th["min_detections"]):
        loc = 0.0
        meas = "%d detections inside the scouted union (bonus_drift/results/scout_hazards.csv)" % len(Xi)
    else:
        hz = ba.world.hazards
        D = np.sqrt(((Xi[:, None, :] - hz.xy[None, :, :]) ** 2).sum(axis=2))
        err = np.minimum(np.min(D, axis=1), float(th["match_cap_m"]))
        med = float(np.median(err))
        loc = 1.5 if med <= th["median_error_max_m"] else 0.0
        meas = "median localization error %s m over %d detections" % (fnum(med, 3), len(Xi))
    o.info("localization (1.5 bonus pts)", meas + " -> %s" % fnum(loc), "median <= 0.6 m", scope)
    d = ba.drive()
    drv = 1.5 if d.get("ok") and d["reached_goal"] and d["intrusions"] == 0 else 0.0
    o.info("rover drive (1.5 bonus pts)", ("reached G: %s, intrusions %s" % (d.get("reached_goal"), d.get("intrusions")))
           if d.get("ok") else "no drive", "reaches G within 900 s with zero intrusions", scope)
    val = loc + drv
    o.bonus_value = val
    o.info("bonus value (auto part)", "%s of 3; add MR-B (up to 2) in the bonus question" % fnum(val), "", scope)
    if ctx.s.policy("bonus_mode", "separate_question") == "extra_credit":
        o.award_bonus = True
    return o


# ============================================================================================== AG-26
def ag26(ctx: Ctx) -> Outcome:
    o = _o(ctx, "AG-26")
    o.visibility = str(ctx.s.policy("integrity_visibility", "hidden"))
    th = ctx.s.th("AG-26")
    t = ctx.s.test("AG-26")
    L = ctx.s.lethal()
    # (a) source strings
    if ctx.root is not None and (ctx.root / "src" / "option_c_scout").is_dir():
        hits = SUB.scan_source(ctx.root / "src" / "option_c_scout", list(t["source_patterns"]), list(t["source_regex"]),
                               int(ctx.s.limit("max_source_file_bytes")))
        if hits:
            files = sorted({h[0] for h in hits})
            pats = sorted({h[2] for h in hits})
            ctx.flag("SOURCE_STRINGS", "%d hits in %d files (%s): %s" % (len(hits), len(files), ", ".join(pats),
                                                                        ", ".join("%s:%d" % (h[0], h[1]) for h in hits[:10])))
    for s in ctx.seeds:
        ba, _w = ctx.analysis(s, "orbit_scout")
        if ba is not None:
            _oracle_and_mosaic(ctx, ba, th, L)
        for c in CONDS:
            ba, _w = ctx.analysis(s, c)
            if ba is not None:
                _fabricated(ctx, ba, th)
                _world_pose(ctx, ba, th)
    # the optional bonus drift bag gets the same dynamics and spawn-pose checks (only when it passes AG-02)
    if ctx.seeds and ctx.bag(ctx.seeds[0], "orbit_scout_drift") is not None:
        ba, _w = ctx.analysis(ctx.seeds[0], "orbit_scout_drift")
        if ba is not None:
            _fabricated(ctx, ba, th)
            _world_pose(ctx, ba, th)
    if not ctx.flags:
        o.info("integrity flags", "none", "flags go to TA review; they never change the score")
    for f in ctx.flags:
        o.info(f["code"], f["detail"], "TA review (never auto-deducted)")
    o.extra["flags"] = [f["code"] for f in ctx.flags]
    return o


def _oracle_and_mosaic(ctx: Ctx, ba: A.BagAnalysis, th: dict, L: int):
    s = ba.world.seed
    t19 = ctx.s.th("AG-19")
    rocks = ba.world.rocks
    Uor, _u, _t = ba.footprint_union(0.5, float(t19["oracle_z_max_m"]))
    res = ctx.s.grid("union")["resolution_m"]
    Uor = ba.dilate(Uor, int(round(float(t19["oracle_dilate_m"]) / res)))
    outside = ~ba.in_union(Uor, rocks.xy)
    orb = (ba.bd.grids.get(B.T_ORB_GRID) or [None])[-1]
    fused, _n, _td, _rs = _fused_grid(ba)
    rows = SUB.read_hazards_csv(ctx.results_dir(s) / "scout_hazards.csv")
    X = np.array(rows.xy, dtype=np.float64).reshape(-1, 2)
    orb_l = geo.grid_values(orb, rocks.xy) >= L if orb is not None else np.zeros(len(rocks.r), dtype=bool)
    fus_l = geo.grid_values(fused, rocks.xy) >= L if fused is not None else np.zeros(len(rocks.r), dtype=bool)
    listed = np.zeros(len(rocks.r), dtype=bool)
    if len(X):
        D = np.sqrt(((rocks.xy[:, None, :] - X[None, :, :]) ** 2).sum(axis=2))
        listed = np.any(D <= rocks.r[:, None] + 0.5, axis=1)
    leak = outside & ~orb_l & (fus_l | listed)
    if int(leak.sum()) >= int(th["oracle_leak_min"]):
        ctx.flag("ORACLE_LEAK", "seed %d: %d rocks never under any camera footprint (< 24 m, dilated 0.5 m) are lethal in the "
                 "fused map or listed in scout_hazards.csv but not lethal in the orbital map" % (s, int(leak.sum())))
    U, _u, _t = ba.union_main()
    if len(X):
        dil = ba.dilate(U, int(round(0.5 / res)))
        n_out = int(np.sum(~ba.in_union(dil, X)))
        if n_out:
            ctx.flag("HAZARDS_OUTSIDE_UNION", "seed %d: %d scout_hazards.csv rows lie outside the scouted footprint union" % (s, n_out))
    observed, gray, alpha, problems = read_mosaic(ctx, s)
    if not problems and gray is not None:
        mres = ctx.s.grid("mosaic")["resolution_m"]
        H = gray.shape[0]
        checked, visible = 0, 0
        for (bx, by), r in zip(ba.world.boulders.xy, ba.world.boulders.r):
            rad_px = int(math.ceil((r + 1.0) / mres)) + 1
            c0 = int((bx + 80.0) / mres)
            r0 = H - 1 - int((by + 80.0) / mres)
            cs = slice(max(0, c0 - rad_px), min(gray.shape[1], c0 + rad_px + 1))
            rs_ = slice(max(0, r0 - rad_px), min(H, r0 + rad_px + 1))
            gg = gray[rs_, cs]
            aa = alpha[rs_, cs]
            yy, xx = np.mgrid[rs_, cs]
            px = -80.0 + (xx + 0.5) * mres
            py = -80.0 + (H - yy - 0.5) * mres
            dd = np.hypot(px - bx, py - by)
            disk = dd <= r * 0.8
            ring = (dd >= r + 0.2) & (dd <= r + 1.0)
            if not np.all(aa[dd <= r + 1.0] == 255) or disk.sum() < 3 or ring.sum() < 3:
                continue
            checked += 1
            if abs(float(gg[disk].mean()) - float(gg[ring].mean())) >= th["mosaic_contrast_min_levels"]:
                visible += 1
        if checked >= int(th["mosaic_min_boulders"]) and visible / checked < th["mosaic_boulder_fraction_min"]:
            ctx.flag("MOSAIC_CONTENT", "seed %d: only %d of %d boulders inside the observed mosaic differ from their 1 m annulus"
                     % (s, visible, checked))


def _commanded_distance(ba: A.BagAnalysis, tw, windows: list, planar: bool, dt_max: float) -> float:
    """Distance a velocity-command stream asks for inside the (t0, t1) sim-time windows: sum of |v| * dt, with
    each step capped at dt_max (a relay holds a command for at most its staleness limit)."""
    if tw is None or len(tw[0]) < 2:
        return 0.0
    tt = ba.tb.sim(tw[0])
    v_all = np.hypot(tw[1][:, 0], tw[1][:, 1]) if planar else np.abs(tw[1][:, 0])
    total = 0.0
    for t0, t1 in windows:
        sel = (tt >= t0) & (tt <= t1)
        ts, v = tt[sel], v_all[sel]
        if len(ts) > 1:
            total += float(np.sum(v[:-1] * np.clip(np.diff(ts), 0.0, dt_max)))
    return total


def _fabricated(ctx: Ctx, ba: A.BagAnalysis, th: dict):
    """FABRICATED_DYNAMICS: a vehicle moved much farther than the commands that drive it allow. Checked against the
    TA relay (guard output, watchdog twist) with 0.2 s steps, and against the student's own command stream with
    steps up to the relay's 0.5 s staleness limit, so a bag where only one of the two streams was edited is caught."""
    d = ba.drive()
    stale = float(th.get("command_staleness_s", 0.5))
    if d.get("ok") and len(d.get("t", [])) > 1:
        win = [(d["t_start"], d["t_end"])]
        dcmd = _commanded_distance(ba, ba.bd.twists.get(B.T_RCMD), win, planar=False, dt_max=0.2)
        dreq = _commanded_distance(ba, ba.bd.twists.get(B.T_REQ), win, planar=False, dt_max=stale)
        dodo = d["executed_length_m"]
        far = dodo >= th["fabricated_min_distance_m"]
        if far and dodo > th["fabricated_ratio"] * dcmd + th["fabricated_slack_m"]:
            ctx.flag("FABRICATED_DYNAMICS", "%s: rover moved %s m while the guard commanded %s m" % (ba.bd.name, fnum(dodo, 1), fnum(dcmd, 1)))
        elif far and dodo > th["fabricated_ratio"] * dreq + th["fabricated_slack_m"]:
            ctx.flag("FABRICATED_DYNAMICS", "%s: rover moved %s m while the executive requested %s m on %s" % (
                ba.bd.name, fnum(dodo, 1), fnum(dreq, 1), B.T_REQ))
    track = ba.scout_track_length()
    # the command twist is recorded only in orbit_scout bags (an airborne scout in orbit_only has its own flag)
    if ba.condition == "orbit_scout" and track >= th["scout_fabricated_min_track_m"]:
        win = [(s.t_takeoff, s.t_land) for s in ba.sorties()]
        dcmd = _commanded_distance(ba, ba.bd.twists.get(B.T_CMD_TWIST), win, planar=True, dt_max=0.2)
        dstu = _commanded_distance(ba, ba.bd.twists.get(B.T_SCOUT_CMD), win, planar=True, dt_max=stale)
        lim = th["scout_fabricated_slack_m"]
        if track > th["fabricated_ratio"] * dcmd + lim:
            ctx.flag("FABRICATED_DYNAMICS", "%s: scout flew %s m while the watchdog commanded %s m" % (ba.bd.name, fnum(track, 1), fnum(dcmd, 1)))
        elif track > th["fabricated_ratio"] * dstu + lim:
            ctx.flag("FABRICATED_DYNAMICS", "%s: scout flew %s m while the student commanded %s m on %s" % (
                ba.bd.name, fnum(track, 1), fnum(dstu, 1), B.T_SCOUT_CMD))


def _world_pose(ctx: Ctx, ba: A.BagAnalysis, th: dict):
    """WORLD_POSE_MISMATCH: the vehicles do not start where this seed's world spawns them (rover at S, scout on the
    helipad). Catches a run copied from another seed whose run_info was edited to pass AG-02."""
    w = ba.world
    problems = []
    r = ba.rover()
    if r is not None and len(r["t"]):
        d0 = float(math.hypot(r["x"][0] - w.S[0], r["y"][0] - w.S[1]))
        if d0 > float(th.get("start_pose_tol_m", 2.0)):
            problems.append("rover odometry starts %s m from this world's S" % fnum(d0, 1))
    sc = ba.scout()
    if sc is not None and len(sc["t"]):
        air = np.nonzero(sc["z"] > 0.5)[0]
        k = int(air[0]) if len(air) else len(sc["t"])
        if k > 0:
            dh = float(np.median(np.hypot(sc["x"][:k] - w.helipad[0], sc["y"][:k] - w.helipad[1])))
            if dh > float(th.get("helipad_tol_m", 1.5)):
                problems.append("scout rests %s m from this world's helipad before its first takeoff" % fnum(dh, 1))
    if problems:
        ctx.flag("WORLD_POSE_MISMATCH", "%s: %s" % (ba.bd.name, "; ".join(problems)))


# ============================================================================================== info
def info00(ctx: Ctx, settings, reader: str) -> Outcome:
    o = Outcome("INFO-00", "Submission discovery and seeds", 0.0, "0.00")
    o.info("layout", ("option_c root found%s" % ("" if ctx.layout.root == ctx.layout.submission else " inside the upload"))
           if ctx.root is not None else "no option_c/ folder found")
    o.info("NetID", "from %s; seeds %s" % (ctx.netid_source, ctx.seeds), "seed_k from the NetID")
    o.info("bag reader", reader)
    for s in ctx.seeds:
        for c in CONDS:
            bd = ctx.bag(s, c)
            st = "missing" if bd is None else ("unreadable: %s" % bd.error if not bd.readable else
                                              "%.2f MB, %d topics, %d messages" % (bd.size_bytes / 1e6, len(bd.topics), sum(bd.counts.values())))
            o.info("bag", st, scope=_scope(s, c))
    for n in ctx.layout.notes + ctx.notes:
        o.note(n)
    return o


def met00(ctx: Ctx) -> Outcome:
    o = Outcome("MET-00", "Recomputed metrics (compare with your comparison_table.csv)", 0.0, "7.99")
    cols = ctx.s.spec["comparison_table"]["columns"]
    m = ctx.metrics()
    rows = []
    for s in ctx.seeds:
        for c in CONDS:
            r = m.get((s, c))
            if r is None:
                o.info("metrics", "not computed (bag missing or fails AG-02)", scope=_scope(s, c))
                continue
            rows.append(r)
            o.info("metrics", ", ".join("%s=%s" % (k, fnum(r.get(k), 3)) for k in cols[2:]), scope=_scope(s, c))
    o.extra["metrics"] = [{k: (None if v is None else (bool(v) if isinstance(v, (bool, np.bool_)) else
                                                         (float(v) if isinstance(v, (float, np.floating)) else v)))
                           for k, v in r.items()} for r in rows]
    return o


REG = {
    "AG-01": ag01, "AG-02": ag02, "AG-03": ag03, "AG-04": ag04, "AG-05": ag05, "AG-06": ag06,
    "AG-07": ag07, "AG-08": ag08, "AG-09": ag09, "AG-10": ag10,
    "AG-11": ag11, "AG-12": ag12, "AG-13": ag13, "AG-14": ag14,
    "AG-15": ag15, "AG-16": ag16, "AG-17": ag17, "AG-18": ag18,
    "AG-19": ag19, "AG-20": ag20, "AG-21": ag21,
    "AG-22": ag22, "AG-23": ag23, "AG-24": ag24,
    "AG-25": ag25, "AG-B1": agb1, "AG-26": ag26,
}
ORDER = ["AG-01", "AG-02", "AG-03", "AG-04", "AG-05", "AG-06", "AG-07", "AG-08", "AG-09", "AG-10", "AG-11", "AG-12",
         "AG-13", "AG-14", "AG-15", "AG-16", "AG-17", "AG-18", "AG-19", "AG-20", "AG-21", "AG-22", "AG-23", "AG-24",
         "AG-25", "AG-B1", "AG-26"]
