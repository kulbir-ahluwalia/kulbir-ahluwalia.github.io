"""Vectorized 2D/3D geometry on numpy arrays (disks, the sand polygon, polylines, rays, grids)."""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

CHUNK = 20000


# ---------------------------------------------------------------------------------------------- hazards
@dataclass
class Hazards:
    """Disk hazards (boulders, rocks, optional landed scout) plus the sand polygon."""
    xy: np.ndarray            # (M, 2)
    r: np.ndarray             # (M,)
    kind: list                # 'boulder' | 'rock' | 'scout'
    ids: list
    poly: np.ndarray          # (K, 2) sand polygon

    def subset(self, mask) -> "Hazards":
        mask = np.asarray(mask, dtype=bool)
        return Hazards(self.xy[mask], self.r[mask], [k for k, m in zip(self.kind, mask) if m],
                       [i for i, m in zip(self.ids, mask) if m], self.poly)

    def with_disk(self, x: float, y: float, r: float, kind: str, hid: str) -> "Hazards":
        return Hazards(np.vstack([self.xy, [[x, y]]]), np.append(self.r, r), self.kind + [kind], self.ids + [hid],
                       self.poly)

    def kinds(self, *names) -> np.ndarray:
        return np.array([k in names for k in self.kind], dtype=bool)


def point_in_polygon(P: np.ndarray, poly: np.ndarray) -> np.ndarray:
    P = np.asarray(P, dtype=np.float64).reshape(-1, 2)
    x, y = P[:, 0], P[:, 1]
    inside = np.zeros(len(P), dtype=bool)
    n = len(poly)
    j = n - 1
    for i in range(n):
        xi, yi = poly[i]
        xj, yj = poly[j]
        cond = (yi > y) != (yj > y)
        with np.errstate(divide="ignore", invalid="ignore"):
            xc = xi + (y - yi) * (xj - xi) / (yj - yi)
        inside ^= cond & (x < xc)
        j = i
    return inside


def dist_points_segments_min(P: np.ndarray, A: np.ndarray, B: np.ndarray) -> np.ndarray:
    """Distance from each point to the nearest of the segments A[k]-B[k]."""
    P = np.asarray(P, dtype=np.float64).reshape(-1, 2)
    out = np.full(len(P), np.inf)
    if len(A) == 0 or len(P) == 0:
        return out
    V = B - A
    vv = np.einsum("ij,ij->i", V, V)
    vv_safe = np.where(vv > 0, vv, 1.0)
    seg_chunk = max(1, CHUNK // max(1, len(A)))
    for s in range(0, len(P), seg_chunk):
        Q = P[s:s + seg_chunk, None, :]                       # (n, 1, 2)
        W = Q - A[None, :, :]                                  # (n, k, 2)
        t = np.clip(np.einsum("nkj,kj->nk", W, V) / vv_safe[None, :], 0.0, 1.0)
        t = np.where(vv[None, :] > 0, t, 0.0)
        D = W - t[..., None] * V[None, :, :]
        out[s:s + seg_chunk] = np.sqrt(np.min(np.einsum("nkj,nkj->nk", D, D), axis=1))
    return out


def polygon_signed_distance(P: np.ndarray, poly: np.ndarray) -> np.ndarray:
    """Distance to the polygon boundary, negative inside."""
    P = np.asarray(P, dtype=np.float64).reshape(-1, 2)
    poly = np.asarray(poly, dtype=np.float64)
    A = poly
    B = np.roll(poly, -1, axis=0)
    d = dist_points_segments_min(P, A, B)
    inside = point_in_polygon(P, poly)
    return np.where(inside, -d, d)


def disk_edge_distances(P: np.ndarray, hz: Hazards) -> np.ndarray:
    """(N, M) center distance minus disk radius (negative inside a disk). Callers chunk over P."""
    P = np.asarray(P, dtype=np.float64).reshape(-1, 2)
    if len(hz.r) == 0:
        return np.zeros((len(P), 0))
    D = np.sqrt(((P[:, None, :] - hz.xy[None, :, :]) ** 2).sum(axis=2))
    return D - hz.r[None, :]


def min_clearance(P: np.ndarray, hz: Hazards, r_fp: float, include_poly: bool = True):
    """Per point: min over hazards of (edge distance - r_fp), and the index of the closest hazard
    (-1 = sand polygon)."""
    P = np.asarray(P, dtype=np.float64).reshape(-1, 2)
    best = np.full(len(P), np.inf)
    which = np.full(len(P), -2, dtype=np.int64)
    step = max(1, CHUNK // max(1, len(hz.r) or 1))
    for s in range(0, len(P), step):
        Q = P[s:s + step]
        if len(hz.r):
            E = disk_edge_distances(Q, hz) - r_fp
            k = np.argmin(E, axis=1)
            best[s:s + step] = E[np.arange(len(Q)), k]
            which[s:s + step] = k
        if include_poly and hz.poly is not None and len(hz.poly) >= 3:
            sd = polygon_signed_distance(Q, hz.poly) - r_fp
            better = sd < best[s:s + step]
            best[s:s + step] = np.where(better, sd, best[s:s + step])
            which[s:s + step] = np.where(better, -1, which[s:s + step])
    return best, which


def near_hazard_mask(centers: np.ndarray, hz: Hazards, margin: float, include_poly: bool = True) -> np.ndarray:
    """True where the point lies within `margin` of some hazard edge (or inside it)."""
    c, _ = min_clearance(centers, hz, margin, include_poly)
    return c <= 0.0


# ---------------------------------------------------------------------------------------------- polylines
def polyline_length(L: np.ndarray) -> float:
    L = np.asarray(L, dtype=np.float64).reshape(-1, 2)
    if len(L) < 2:
        return 0.0
    return float(np.sum(np.sqrt(np.sum(np.diff(L, axis=0) ** 2, axis=1))))


def max_spacing(L: np.ndarray) -> float:
    L = np.asarray(L, dtype=np.float64).reshape(-1, 2)
    if len(L) < 2:
        return 0.0
    return float(np.max(np.sqrt(np.sum(np.diff(L, axis=0) ** 2, axis=1))))


def resample_polyline(L: np.ndarray, step: float) -> np.ndarray:
    """Points every `step` along the polyline, both endpoints and every vertex included."""
    L = np.asarray(L, dtype=np.float64).reshape(-1, 2)
    if len(L) < 2:
        return L.copy()
    out = [L[:1]]
    for a, b in zip(L[:-1], L[1:]):
        seg = float(np.hypot(*(b - a)))
        n = int(np.ceil(seg / step)) if seg > 0 else 0
        if n > 0:
            t = np.arange(1, n + 1, dtype=np.float64) / n
            out.append(a[None, :] + t[:, None] * (b - a)[None, :])
    return np.vstack(out)


def dist_points_polyline(P: np.ndarray, L: np.ndarray) -> np.ndarray:
    L = np.asarray(L, dtype=np.float64).reshape(-1, 2)
    P = np.asarray(P, dtype=np.float64).reshape(-1, 2)
    if len(L) == 0:
        return np.full(len(P), np.inf)
    if len(L) == 1:
        return np.sqrt(((P - L[0]) ** 2).sum(axis=1))
    return dist_points_segments_min(P, L[:-1], L[1:])


def hausdorff(A: np.ndarray, B: np.ndarray, step: float) -> float:
    A = np.asarray(A, dtype=np.float64).reshape(-1, 2)
    B = np.asarray(B, dtype=np.float64).reshape(-1, 2)
    if len(A) == 0 or len(B) == 0:
        return float("inf")
    a = resample_polyline(A, step)
    b = resample_polyline(B, step)
    return float(max(np.max(dist_points_polyline(a, B)), np.max(dist_points_polyline(b, A))))


def decimate_track(xy: np.ndarray, min_step: float) -> np.ndarray:
    """Keep a sample only when it is at least min_step from the last kept one (always keep the last)."""
    xy = np.asarray(xy, dtype=np.float64).reshape(-1, 2)
    if len(xy) == 0:
        return xy
    keep = [0]
    last = xy[0]
    for i in range(1, len(xy)):
        if np.hypot(*(xy[i] - last)) >= min_step:
            keep.append(i)
            last = xy[i]
    if keep[-1] != len(xy) - 1 and np.hypot(*(xy[-1] - xy[keep[-1]])) > 0:
        keep.append(len(xy) - 1)
    return xy[keep]


# ---------------------------------------------------------------------------------------------- rotations
def quat_normalize(q: np.ndarray) -> np.ndarray:
    q = np.asarray(q, dtype=np.float64).reshape(-1, 4)
    n = np.linalg.norm(q, axis=1, keepdims=True)
    n = np.where(n > 0, n, 1.0)
    return q / n


def quat_rotate(q: np.ndarray, v: np.ndarray) -> np.ndarray:
    """Rotate vectors v (N, 3) by unit quaternions q (N, 4) in (x, y, z, w) order."""
    q = np.asarray(q, dtype=np.float64).reshape(-1, 4)
    v = np.asarray(v, dtype=np.float64).reshape(-1, 3)
    u = q[:, 0:3]
    w = q[:, 3:4]
    t = 2.0 * np.cross(u, v)
    return v + w * t + np.cross(u, t)


def slerp(q0: np.ndarray, q1: np.ndarray, f: np.ndarray) -> np.ndarray:
    q0 = quat_normalize(q0)
    q1 = quat_normalize(q1)
    f = np.asarray(f, dtype=np.float64).reshape(-1, 1)
    dot = np.sum(q0 * q1, axis=1, keepdims=True)
    q1 = np.where(dot < 0, -q1, q1)
    dot = np.abs(dot)
    lin = dot > 0.9995
    theta = np.arccos(np.clip(dot, -1.0, 1.0))
    s = np.sin(theta)
    s = np.where(s > 1e-12, s, 1.0)
    a = np.sin((1.0 - f) * theta) / s
    b = np.sin(f * theta) / s
    out = np.where(lin, (1.0 - f) * q0 + f * q1, a * q0 + b * q1)
    return quat_normalize(out)


def yaw_of(qx, qy, qz, qw):
    return np.arctan2(2.0 * (qw * qz + qx * qy), 1.0 - 2.0 * (qy * qy + qz * qz))


# ---------------------------------------------------------------------------------------------- grids
@dataclass
class GridSpec:
    res: float
    w: int
    h: int
    ox: float
    oy: float

    def cell(self, P: np.ndarray):
        """(i, j, inside) for points; cell (i, j) covers [ox + i*res, ox + (i+1)*res) x [...)."""
        P = np.asarray(P, dtype=np.float64).reshape(-1, 2)
        i = np.floor((P[:, 0] - self.ox) / self.res).astype(np.int64)
        j = np.floor((P[:, 1] - self.oy) / self.res).astype(np.int64)
        inside = (i >= 0) & (j >= 0) & (i < self.w) & (j < self.h)
        return i, j, inside

    def centers(self, mask: np.ndarray | None = None) -> np.ndarray:
        jj, ii = np.mgrid[0:self.h, 0:self.w]
        if mask is not None:
            jj, ii = jj[mask], ii[mask]
        return np.stack([self.ox + (ii.ravel() + 0.5) * self.res, self.oy + (jj.ravel() + 0.5) * self.res], axis=1)


def grid_values(grid: dict, P: np.ndarray) -> np.ndarray:
    """Costmap values at points (row-major data, index j * width + i); -2 outside the grid or for an
    inconsistent message. Rotated origins are ignored (the spec fixes the identity orientation)."""
    P = np.asarray(P, dtype=np.float64).reshape(-1, 2)
    out = np.full(len(P), -2, dtype=np.int16)
    w, h, res = int(grid["w"]), int(grid["h"]), float(grid["res"])
    data = grid["data"]
    if res <= 0 or w <= 0 or h <= 0 or len(data) != w * h:
        return out
    gs = GridSpec(res, w, h, float(grid["origin"][0]), float(grid["origin"][1]))
    i, j, inside = gs.cell(P)
    idx = (j * w + i)[inside]
    out[inside] = data[idx].astype(np.int16)
    return out


def disk_sample_points(x: float, y: float, r: float, n_ring: int = 16) -> np.ndarray:
    """Center plus n_ring points on the circle: used for 'whole disk inside the union' tests."""
    a = np.arange(n_ring) * (2.0 * np.pi / n_ring)
    ring = np.stack([x + r * np.cos(a), y + r * np.sin(a)], axis=1)
    return np.vstack([[[x, y]], ring])
