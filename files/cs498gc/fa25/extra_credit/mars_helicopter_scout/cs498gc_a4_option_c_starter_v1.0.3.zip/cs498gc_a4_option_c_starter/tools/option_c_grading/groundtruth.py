"""Regenerated worlds: the grader never reads a world or ground-truth file from the submission.

gen_option_c_world.py (stdlib only, byte-identical to the starter's tools/gen_option_c_world.py) sits next to
this package in both layouts: <dir>/gen_option_c_world.py + <dir>/option_c_grading/.
"""
from __future__ import annotations

import hashlib
import importlib.util
import sys
from pathlib import Path

import numpy as np

from .geometry import Hazards

GEN_PATH = Path(__file__).resolve().parent.parent / "gen_option_c_world.py"
_GEN = None
_CACHE: dict = {}
_REF_CACHE: dict = {}


def generator():
    global _GEN
    if _GEN is None:
        if not GEN_PATH.is_file():
            raise FileNotFoundError("gen_option_c_world.py not found next to option_c_grading/ (%s)" % GEN_PATH.name)
        spec = importlib.util.spec_from_file_location("option_c_gen_world", str(GEN_PATH))
        mod = importlib.util.module_from_spec(spec)
        sys.modules["option_c_gen_world"] = mod
        spec.loader.exec_module(mod)
        _GEN = mod
    return _GEN


def generator_sha256() -> str:
    return hashlib.sha256(GEN_PATH.read_bytes()).hexdigest()


class World:
    def __init__(self, seed: int, sdf_text: str, gt: dict, attempts: int):
        self.seed = int(seed)
        self.sdf_sha256 = hashlib.sha256(sdf_text.encode("utf-8")).hexdigest()
        self.gt = gt
        self.attempts = attempts
        self.S = np.array(gt["S"], dtype=np.float64)
        self.G = np.array(gt["G"], dtype=np.float64)
        self.helipad = np.array(gt["helipad"], dtype=np.float64)
        b = gt["boulders"]
        r = gt["rocks"]
        xy = np.array([[h["x"], h["y"]] for h in b + r], dtype=np.float64).reshape(-1, 2)
        rad = np.array([h["radius"] for h in b + r], dtype=np.float64)
        self.hazards = Hazards(xy, rad, ["boulder"] * len(b) + ["rock"] * len(r),
                               [h["id"] for h in b + r], np.array(gt["sand_patch"]["polygon"], dtype=np.float64))
        self.n_boulders = len(b)
        self.n_rocks = len(r)

    @property
    def boulders(self) -> Hazards:
        return self.hazards.subset(self.hazards.kinds("boulder"))

    @property
    def rocks(self) -> Hazards:
        return self.hazards.subset(self.hazards.kinds("rock"))

    @property
    def sand(self) -> np.ndarray:
        return self.hazards.poly

    def sg_distance(self) -> float:
        return float(np.hypot(*(self.S - self.G)))

    def reference_length(self, r_fp: float, inflate_extra: float = 0.1) -> float | None:
        """AG-10 reference: 8-connected A*, octile heuristic, 0.5 m grid, boulders + sand inflated by
        r_fp + 0.1 m (gen_option_c_world.reference_astar)."""
        key = (self.seed, round(float(r_fp), 4), round(float(inflate_extra), 4))
        if key in _REF_CACHE:
            return _REF_CACHE[key]
        if abs(r_fp - 0.45) < 1e-9 and abs(inflate_extra - 0.1) < 1e-9:
            val = float(self.gt["reference_path"]["length_m"])
        else:
            _pts, length = generator().reference_astar(self.gt, r_fp=float(r_fp), inflate_extra=float(inflate_extra))
            val = float(length) if length is not None else None
        _REF_CACHE[key] = val
        return val


def world(seed: int) -> World:
    seed = int(seed)
    if seed not in _CACHE:
        sdf, gt, attempts = generator().generate(seed)
        _CACHE[seed] = World(seed, sdf, gt, attempts)
    return _CACHE[seed]


def seeds_for(netid: str) -> list:
    nid = str(netid).strip().lower()
    return [int(hashlib.sha256(("cs498gc-a4c:" + nid + ":" + str(k)).encode()).hexdigest()[:8], 16) for k in range(3)]
