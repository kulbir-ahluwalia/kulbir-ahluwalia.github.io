"""Grade one submission (Gradescope run_tests.py and students' tools/local_check.py share this code)."""
from __future__ import annotations

import json
import math
import re
import time
import traceback
from pathlib import Path

import numpy as np

from . import GRADER_ID, GRADER_VERSION
from . import analysis as A
from . import bagio as B
from . import checks as C
from . import groundtruth as GT
from .util import Outcome, Settings, fnum, pts, round_score

STAGE_OF = {}


def _milestone(settings, tid: str) -> str:
    return str(settings.test(tid).get("milestone", "M5"))


def grade(submission, work, metadata=None, stage: str = "M5", local: bool = False, netid: str | None = None,
          overrides: dict | None = None, force_reader: str | None = None) -> dict:
    t0 = time.monotonic()
    settings = Settings(overrides)
    problems = settings.validate()
    ctx = C.Ctx(settings, submission, work, metadata, stage, local, netid, force_reader)
    reader = force_reader or B.reader_name()
    outcomes = [C.info00(ctx, settings, reader)]
    timings = {}
    for tid in C.ORDER:
        if tid != "AG-26" and not ctx.in_stage(_milestone(settings, tid)):
            continue
        t1 = time.monotonic()
        try:
            o = C.REG[tid](ctx)
        except Exception as exc:  # noqa: BLE001 - one broken check must not sink the others
            t = settings.test(tid)
            o = Outcome(tid, str(t["name"]), float(t.get("points") or 0.0), str(t.get("number", "")))
            if tid == "AG-B1":
                o.max_score = 0.0
                o.bonus_value = 0.0
            o.error = ("internal grader error (%s); this check scored 0 and is flagged for the TA. Please post on the "
                       "forum." % type(exc).__name__)
            o.extra["traceback"] = traceback.format_exc()[-1500:]
        o.extra["seconds"] = round(time.monotonic() - t1, 2)
        timings[tid] = o.extra["seconds"]
        outcomes.append(o)
    try:
        outcomes.append(C.met00(ctx))
    except Exception as exc:  # noqa: BLE001
        o = Outcome("MET-00", "Recomputed metrics", 0.0, "7.99")
        o.error = "metrics table failed (%s)" % type(exc).__name__
        o.extra["traceback"] = traceback.format_exc()[-1500:]
        outcomes.append(o)
    # AG-26 is computed last (it reads flags raised by the other checks) but shown in spec order
    order = {tid: k for k, tid in enumerate(["INFO-00"] + [t for t in C.ORDER if t not in ("AG-B1", "AG-26")]
                                            + ["AG-26", "AG-B1", "MET-00"])}
    outcomes.sort(key=lambda o: order.get(o.test_id, 999))
    return {"settings": settings, "ctx": ctx, "outcomes": outcomes, "problems": problems, "reader": reader,
            "seconds": time.monotonic() - t0, "timings": timings, "stage": ctx.stage}


# ---------------------------------------------------------------------------------------------- rendering
def to_gradescope(o: Outcome) -> dict:
    d = {
        "name": "%s %s" % (o.test_id, o.name),
        "number": o.number,
        "score": o.score,
        "max_score": round_score(o.max_score),
        "status": o.status,
        "output": o.render(),
        "visibility": o.visibility,
        "extra_data": _json_safe({k: v for k, v in o.extra.items() if k != "traceback"}),
    }
    if "traceback" in o.extra:
        d["extra_data"]["traceback"] = _strip_paths(o.extra["traceback"])
    return d


def _json_safe(node):
    if isinstance(node, dict):
        return {str(k): _json_safe(v) for k, v in node.items()}
    if isinstance(node, (list, tuple)):
        return [_json_safe(v) for v in node]
    if isinstance(node, (np.bool_,)):
        return bool(node)
    if isinstance(node, (np.integer,)):
        return int(node)
    if isinstance(node, (np.floating, float)):
        f = float(node)
        return f if math.isfinite(f) else None
    if isinstance(node, Path):
        return node.name
    return node


def _strip_paths(text: str) -> str:
    return re.sub(r"(/[^\s\"']+)+/([^/\s\"']+)", r"<path>/\2", str(text))


def scrub(text: str, roots: list) -> str:
    for r in sorted({str(p).rstrip("/") + "/" for p in roots if p}, key=len, reverse=True):
        text = text.replace(r, "")
    return text


def top_lines(res: dict) -> list:
    s = res["settings"]
    a = s.assignment
    outs = res["outcomes"]
    total = round_score(sum(o.score for o in outs if o.max_score > 0 or o.award_bonus))
    lines = ["%s - automated checks (%s of %s points; the rest is graded manually)" % (
        a["gradescope_title"], pts(s.auto_points()), pts(a["total_points"]))]
    if res["problems"]:
        lines.append("CONFIGURATION WARNING (tell the TA): " + "; ".join(res["problems"]))
    if res["stage"] != "M5":
        lines.append("Stage %s: only checks of milestones up to %s ran." % (res["stage"], res["stage"]))
    lines.append("Automated score: %s / %s" % (pts(total), pts(s.auto_points())))
    bonus = [o for o in outs if o.test_id == "AG-B1"]
    if bonus and bonus[0].bonus_value is not None:
        lines.append("Bonus AG-B1 (auto part, entered in the separate bonus question with MR-B): %s / 3" % pts(bonus[0].bonus_value))
    lines.append("Manual items (graded by the TA in Gradescope, not by this autograder):")
    for m in s.manual_items():
        lines.append("  %s %s (%s pts)" % (m["id"], m["name"], fnum(m["points"])))
    for b in s.bonus_items():
        lines.append("  %s %s (+%s bonus)" % (b["id"], b["name"], fnum(b["points"])))
    lines.append("Bag reader: %s. Grader %s %s, spec %s." % (res["reader"], GRADER_ID, GRADER_VERSION, s.spec["version"]))
    return lines


def results_dict(res: dict, roots: list) -> dict:
    tests = [to_gradescope(o) for o in res["outcomes"]]
    for t in tests:
        t["output"] = scrub(t["output"], roots)
    total = round_score(sum(t["score"] for t in tests))
    ctx = res["ctx"]
    bonus = [o for o in res["outcomes"] if o.test_id == "AG-B1"]
    bonus_auto = round_score(bonus[0].bonus_value) if bonus and bonus[0].bonus_value is not None else None
    return {
        "score": total,
        "execution_time": int(round(res["seconds"])),
        "output": scrub("\n".join(top_lines(res)), roots),
        "visibility": "visible",
        "stdout_visibility": "hidden",
        "extra_data": _json_safe({"grader": GRADER_ID, "version": GRADER_VERSION,
                                  "spec_sha256": res["settings"].spec_sha256,
                                  "generator_sha256": GT.generator_sha256(), "reader": res["reader"],
                                  "bonus_auto_points": bonus_auto, "bonus_mode": res["settings"].policy("bonus_mode"),
                                  "integrity_flags": ctx.flags, "timings_s": res["timings"],
                                  "metrics": metrics_rows(ctx)}),
        "tests": tests,
    }


def metrics_rows(ctx) -> list:
    out = []
    for (s, c), r in ctx.metrics().items():
        if r is not None:
            out.append(_json_safe(r))
    return out


def write_json(path: Path, data: dict) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2, default=str)
    tmp.replace(path)


def print_report(res: dict, roots: list, show_hidden: bool = True) -> None:
    for line in top_lines(res):
        print(scrub(line, roots))
    for o in res["outcomes"]:
        if o.visibility == "hidden" and not show_hidden:
            continue
        print("=" * 78)
        if o.max_score > 0:
            head = "%s %s: %s / %s" % (o.test_id, o.name, pts(o.score), pts(o.max_score))
        else:
            head = "%s %s" % (o.test_id, o.name)
        print(head)
        print(scrub(o.render(), roots))


# ---------------------------------------------------------------------------------------------- M0
def check_m0(bag_dir, seed=None, force_reader=None) -> list:
    """M0 bring-up PASS criteria on one bag: [(status, label, message)].

    The condition comes from the bag's run_info: an orbit_scout bag (or one without run_info)
    gets the hover and landing criteria; an orbit_only bag instead must show no airborne interval
    (takeoff is rejected there). Every other criterion applies to both."""
    s = Settings()
    items = []

    def add(ok, label, msg):
        items.append(("PASS" if ok else "FAIL", label, msg))

    def info(label, msg):
        items.append(("INFO", label, msg))

    bd = B.read_bag(bag_dir, None, False, force_reader=force_reader)
    if not bd.readable:
        add(False, "bag", "cannot read the bag: %s" % bd.error)
        return items
    ba = A.BagAnalysis(bd, s, None, 0.45, "orbit_scout")
    ri_all = []
    for _rx, text in bd.strings.get(B.T_RUN_INFO, []):
        try:
            d = json.loads(text)
            if isinstance(d, dict):
                ri_all.append(d)
        except ValueError:
            pass
    ri = ri_all[0] if ri_all else None
    if ri is None:
        add(False, "run_info", "no /option_c/run_info in the bag")
    else:
        info("run_info", "seed=%s condition=%s scout_dynamics=%s odom_mode=%s" % (
            ri.get("seed"), ri.get("condition"), ri.get("scout_dynamics"), ri.get("odom_mode")))
        if seed is not None:
            add(str(ri.get("seed")) == str(seed), "seed", "run_info seed %s (expected %s)" % (ri.get("seed"), seed))
        try:
            w = GT.world(int(ri.get("seed")))
            ok = ri.get("world_sha256") == w.sdf_sha256
            add(ok, "world", "world_sha256 %s the regenerated world" % ("matches" if ok else "does NOT match"))
        except Exception as exc:  # noqa: BLE001
            add(False, "world", "could not regenerate the world (%s)" % type(exc).__name__)
    sc = bd.odoms.get(B.T_SCOUT)
    ss = ba.sorties()
    orbit_only = ri is not None and ri.get("condition") == "orbit_only"
    if orbit_only:
        # orbit_only: the scout must not fly (takeoff is rejected), so the hover and landing
        # criteria do not apply; the rover, orbital and run_info checks below still do.
        info("condition", "orbit_only bag: the hover and landing criteria apply to orbit_scout bags only")
        add(not ss, "no flight", "orbit_only: %d airborne intervals (z > 0.5 m) in /option_c/grader/scout_odom (0 required)"
            % len(ss))
    else:
        best = 0.0
        if sc is not None and len(sc["t"]):
            start = None
            for t, z in zip(sc["t"], sc["z"]):
                if 9.0 <= z <= 11.0:
                    start = t if start is None else start
                    best = max(best, t - start)
                else:
                    start = None
        add(best >= 15.0, "hover", "scout z in [9, 11] m for %s s continuously (>= 15 s)" % fnum(best, 1))
    if orbit_only:
        pass
    elif not ss:
        add(False, "landing", "no airborne interval (z > 0.5 m) in /option_c/grader/scout_odom")
    else:
        worst = 0.0
        t, x, y = sc["t"], sc["x"], sc["y"]
        for so in ss:
            idx = np.nonzero((t >= so.t_land - 2.0) & (t <= so.t_land + 1e-9))[0]
            for a, b in zip(idx[:-1], idx[1:]):
                if t[b] > t[a]:
                    worst = max(worst, float(np.hypot(x[b] - x[a], y[b] - y[a]) / (t[b] - t[a])))
        add(worst < 0.5, "landing", "landing horizontal speed (max over the 2 s before z < 0.5 m) %s m/s (< 0.5)" % fnum(worst, 3))
    first = None
    for d in ri_all:
        if d.get("first_orbital_t_sim") is not None:
            try:
                first = float(d["first_orbital_t_sim"])
                break
            except (TypeError, ValueError):
                pass
    orb = bd.caminfos.get(B.T_ORB_CI)
    if first is not None:
        add(first <= 15.0, "orbital", "first orbiter camera_info at %s s sim (run_info first_orbital_t_sim; <= 15 s)" % fnum(first, 2))
    elif orb is not None and len(orb["t"]):
        add(float(orb["t"][0]) <= 15.0, "orbital", "first orbiter camera_info in the bag at %s s sim (<= 15 s)" % fnum(float(orb["t"][0]), 2))
    else:
        add(False, "orbital", "no /orbiter/bev_cam/camera_info in the bag")
    rov = bd.odoms.get(B.T_ROVER)
    r_hz = A.rate_hz(rov["t"]) if rov is not None else 0.0
    add(r_hz >= 8.0, "rover odom", "/option_c/rover/odom_truth %s Hz (>= 8)" % fnum(r_hz))
    if rov is not None and len(rov["t"]):
        info("rover", "rover displacement %s m (M0 asks for about 10 m of teleop)" % fnum(
            float(np.hypot(rov["x"][-1] - rov["x"][0], rov["y"][-1] - rov["y"][0]))))
    h_hz = A.rate_hz([t for t, _rx, _xy in bd.hazcam])
    add(h_hz >= 4.0, "hazcam", "/option_c/rover/hazcam %s Hz (>= 4)" % fnum(h_hz))
    ev = ba.events()
    bad = [e for e in ev if e[2] in ("geofence", "ceiling")]
    add(not bad, "watchdog", "%d geofence/ceiling events (0 required); all events: %s" % (
        len(bad), sorted({e[2] for e in ev}) or "none"))
    return items
