"""Submission layout discovery, safe archive extraction, config, NetID, src hash, source scan and results files.

Never executes anything from the submission. Symlinks are never followed. Text files over the size limit are
not read.
"""
from __future__ import annotations

import csv
import hashlib
import io
import json
import math
import os
import re
import shutil
import tarfile
import zipfile
from dataclasses import dataclass, field
from pathlib import Path

SRC_HASH_EXCLUDED_DIRS = {"__pycache__", "build", "install", "log", ".git"}
ARCHIVE_EXT = (".zip", ".tar", ".tar.gz", ".tgz", ".tar.xz", ".txz", ".tar.bz2")
IGNORED_DIRS = {"__MACOSX", ".git"}


# ---------------------------------------------------------------------------------------------- config
def parse_config(path) -> dict:
    """config/option_c.yaml with PyYAML when available, else a small parser for 'key: value', flow lists
    'key: [a, b]' and block lists. Same verdict as make_submission.sh (it calls local_check --print-config)."""
    text = Path(path).read_text(encoding="utf-8", errors="replace")
    try:
        import yaml
        cfg = yaml.safe_load(text)
        if isinstance(cfg, dict):
            return cfg
        if cfg is None:
            return {}
    except Exception:  # noqa: BLE001
        pass
    cfg: dict = {}
    block_key = None
    for line in text.splitlines():
        item = re.match(r"^\s*-\s*(.*?)\s*(#.*)?$", line)
        if block_key is not None and item:
            cfg[block_key].append(item.group(1).strip("'\""))
            continue
        m = re.match(r"^\s*([A-Za-z_][A-Za-z0-9_]*)\s*:\s*(.*?)\s*(#.*)?$", line)
        if not m:
            if line.strip() and not line.lstrip().startswith("#"):
                block_key = None
            continue
        key, val = m.group(1), m.group(2)
        block_key = None
        if val.startswith("["):
            cfg[key] = [v.strip().strip("'\"") for v in val.strip("[]").split(",") if v.strip()]
        elif val == "":
            cfg[key] = []
            block_key = key
        else:
            cfg[key] = val.strip("'\"")
    return cfg


def config_netid_seeds(path):
    cfg = parse_config(path)
    netid = str(cfg.get("netid", "") or "").strip().lower()
    raw = cfg.get("seeds", [])
    if not isinstance(raw, list):
        raw = [raw]
    seeds = [int(s) for s in raw if str(s).strip().isdigit()]
    return netid, seeds


def metadata_netids(path) -> tuple[list, str | None]:
    """Email local parts of the Gradescope submitters (lowercase). Never returned in student output."""
    p = Path(path) if path else None
    if p is None or not p.is_file():
        return [], "submission_metadata.json not found"
    try:
        md = json.loads(p.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001
        return [], "submission_metadata.json does not parse (%s)" % type(exc).__name__
    out = []
    for u in md.get("users") or []:
        email = str((u or {}).get("email") or "").strip().lower()
        if "@" in email:
            out.append(email.split("@", 1)[0])
        elif email:
            out.append(email)
    return out, None


# ---------------------------------------------------------------------------------------------- src hash
def src_tree_lines(root) -> list:
    root = Path(root)
    lines = []
    for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
        dirnames[:] = sorted(d for d in dirnames if d not in SRC_HASH_EXCLUDED_DIRS)
        for fn in filenames:
            if fn.endswith(".pyc"):
                continue
            full = Path(dirpath) / fn
            if not full.is_file():
                continue
            h = hashlib.sha256()
            with open(full, "rb") as fh:
                for chunk in iter(lambda: fh.read(1 << 20), b""):
                    h.update(chunk)
            lines.append("%s %s" % (full.relative_to(root).as_posix(), h.hexdigest()))
    return sorted(lines)


def src_tree_sha256(root):
    """AG-06 (identical to option_c_starter.common.src_tree_sha256): sha256 of the sorted lines
    '<relative path> <file sha256>' joined with newlines plus one trailing newline; (digest, file count)."""
    lines = src_tree_lines(root)
    text = "".join(line + "\n" for line in lines)
    return hashlib.sha256(text.encode("utf-8")).hexdigest(), len(lines)


def scan_source(root, patterns: list, regexes: list, max_bytes: int = 1_000_000) -> list:
    """[(relative path, line number, pattern)] for every hit; file contents are never returned."""
    root = Path(root)
    hits = []
    rx = [(r, re.compile(r)) for r in regexes]
    for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
        dirnames[:] = sorted(d for d in dirnames if d not in SRC_HASH_EXCLUDED_DIRS)
        for fn in sorted(filenames):
            full = Path(dirpath) / fn
            if fn.endswith(".pyc") or not full.is_file() or full.is_symlink():
                continue
            try:
                if full.stat().st_size > max_bytes:
                    continue
                data = full.read_bytes()
            except OSError:
                continue
            if b"\x00" in data[:4096]:
                continue
            rel = full.relative_to(root).as_posix()
            for lineno, line in enumerate(data.decode("utf-8", "replace").splitlines(), 1):
                for pat in patterns:
                    if pat in line:
                        hits.append((rel, lineno, pat))
                for name, cre in rx:
                    if cre.search(line):
                        hits.append((rel, lineno, name))
    return hits


# ---------------------------------------------------------------------------------------------- discovery
@dataclass
class Layout:
    submission: Path
    root: Path | None = None
    notes: list = field(default_factory=list)
    upload_bytes: int = 0
    upload_files: int = 0
    archive_bytes: int = 0
    extracted: list = field(default_factory=list)


def _walk_files(top: Path):
    for dirpath, dirnames, filenames in os.walk(top, followlinks=False):
        dirnames[:] = [d for d in dirnames if d not in IGNORED_DIRS]
        for fn in filenames:
            p = Path(dirpath) / fn
            if p.is_symlink():
                continue
            yield p


def _is_archive(p: Path) -> bool:
    n = p.name.lower()
    return n.endswith(ARCHIVE_EXT)


def _safe_member(name: str) -> bool:
    if name.startswith("/") or name.startswith("\\") or re.match(r"^[A-Za-z]:", name):
        return False
    parts = re.split(r"[\\/]+", name)
    return ".." not in parts and "__MACOSX" not in parts


def extract_archive(arc: Path, dest: Path, max_members: int, max_bytes: int) -> tuple[int, str | None]:
    """Extract regular files only (no links, no absolute or '..' paths) within member and byte limits."""
    dest.mkdir(parents=True, exist_ok=True)
    count = 0
    total = 0
    try:
        if arc.name.lower().endswith(".zip"):
            with zipfile.ZipFile(arc) as zf:
                for info in zf.infolist():
                    if info.is_dir() or not _safe_member(info.filename):
                        continue
                    mode = (info.external_attr >> 16) & 0o170000
                    if mode == 0o120000:            # symlink
                        continue
                    count += 1
                    total += info.file_size
                    if count > max_members or total > max_bytes:
                        return count, "archive limits reached (%d members, %d bytes)" % (max_members, max_bytes)
                    out = dest / info.filename
                    out.parent.mkdir(parents=True, exist_ok=True)
                    with zf.open(info) as src, open(out, "wb") as dst:
                        shutil.copyfileobj(src, dst, 1 << 20)
        else:
            with tarfile.open(arc) as tf:
                for m in tf:
                    if not m.isfile() or not _safe_member(m.name):
                        continue
                    count += 1
                    total += m.size
                    if count > max_members or total > max_bytes:
                        return count, "archive limits reached (%d members, %d bytes)" % (max_members, max_bytes)
                    out = dest / m.name
                    out.parent.mkdir(parents=True, exist_ok=True)
                    src = tf.extractfile(m)
                    if src is None:
                        continue
                    with src, open(out, "wb") as dst:
                        shutil.copyfileobj(src, dst, 1 << 20)
    except (zipfile.BadZipFile, tarfile.TarError, OSError, EOFError) as exc:
        return count, "could not extract (%s)" % type(exc).__name__
    return count, None


def _find_roots(top: Path) -> list:
    out = []
    for dirpath, dirnames, filenames in os.walk(top, followlinks=False):
        dirnames[:] = sorted(d for d in dirnames if d not in IGNORED_DIRS and d not in SRC_HASH_EXCLUDED_DIRS)
        p = Path(dirpath)
        if (p / "config" / "option_c.yaml").is_file():
            out.append(p)
            dirnames[:] = []       # do not descend into a found root
    return out


def discover(submission, work, max_members=5000, max_bytes=400_000_000, max_archives=3) -> Layout:
    sub = Path(submission)
    lay = Layout(submission=sub)
    if not sub.is_dir():
        lay.notes.append("submission folder does not exist")
        return lay
    for p in _walk_files(sub):
        try:
            sz = p.stat().st_size
        except OSError:
            continue
        lay.upload_bytes += sz
        lay.upload_files += 1
        if _is_archive(p):
            lay.archive_bytes = max(lay.archive_bytes, sz)
    roots = _find_roots(sub)
    if not roots:
        arcs = sorted((p for p in _walk_files(sub) if _is_archive(p)), key=lambda q: (len(q.parts), str(q)))
        work = Path(work)
        for k, arc in enumerate(arcs[:max_archives]):
            dest = work / "extracted" / ("a%d" % k)
            n, err = extract_archive(arc, dest, max_members, max_bytes)
            lay.extracted.append((arc.name, n, err))
            lay.notes.append("extracted archive %s: %d files%s" % (arc.name, n, (" (%s)" % err) if err else ""))
            inner = sorted(q for q in _walk_files(dest) if _is_archive(q))
            for j, arc2 in enumerate(inner[:1]):
                dest2 = work / "extracted" / ("a%d_%d" % (k, j))
                n2, err2 = extract_archive(arc2, dest2, max_members, max_bytes)
                lay.notes.append("extracted nested archive %s: %d files%s" % (arc2.name, n2, (" (%s)" % err2) if err2 else ""))
            roots = _find_roots(work / "extracted")
            if roots:
                break
    if roots:
        roots.sort(key=lambda r: (r.name != "option_c", len(r.parts), str(r)))
        lay.root = roots[0]
        if len(roots) > 1:
            lay.notes.append("%d folders contain config/option_c.yaml; graded the one named option_c or the "
                             "shallowest" % len(roots))
    return lay


def tree_bytes(root: Path) -> int:
    return sum(p.stat().st_size for p in _walk_files(root))


# ---------------------------------------------------------------------------------------------- results files
@dataclass
class HazardRows:
    xy: list
    diam: list
    cls: list
    problems: list
    rows_total: int = 0


def read_hazards_csv(path, max_rows: int = 20000) -> HazardRows:
    out = HazardRows([], [], [], [])
    p = Path(path)
    if not p.is_file():
        out.problems.append("missing")
        return out
    try:
        text = p.read_text(encoding="utf-8-sig", errors="replace")
    except OSError as exc:
        out.problems.append("unreadable (%s)" % type(exc).__name__)
        return out
    rdr = csv.reader(io.StringIO(text))
    try:
        header = [h.strip().lower() for h in next(rdr)]
    except StopIteration:
        out.problems.append("empty file")
        return out
    need = ["x_m", "y_m", "diameter_m", "class", "source", "confidence"]
    missing = [c for c in need if c not in header]
    if missing:
        out.problems.append("missing columns: " + ", ".join(missing))
        if "x_m" in missing or "y_m" in missing:
            return out
    ix, iy = header.index("x_m"), header.index("y_m")
    idm = header.index("diameter_m") if "diameter_m" in header else None
    icl = header.index("class") if "class" in header else None
    bad = 0
    for row in rdr:
        if not row or all(not c.strip() for c in row):
            continue
        out.rows_total += 1
        if out.rows_total > max_rows:
            out.problems.append("more than %d rows: the rest is ignored" % max_rows)
            break
        try:
            x = float(row[ix])
            y = float(row[iy])
        except (ValueError, IndexError):
            bad += 1
            continue
        if not (math.isfinite(x) and math.isfinite(y)):
            bad += 1
            continue
        d = None
        if idm is not None:
            try:
                d = float(row[idm])
            except (ValueError, IndexError):
                d = None
        out.xy.append((x, y))
        out.diam.append(d)
        out.cls.append((row[icl].strip().lower() if icl is not None and icl < len(row) else ""))
    if bad:
        out.problems.append("%d rows without finite x_m, y_m were skipped" % bad)
    return out


def read_csv_dicts(path):
    p = Path(path)
    text = p.read_text(encoding="utf-8-sig", errors="replace")
    rdr = csv.DictReader(io.StringIO(text))
    rows = []
    for row in rdr:
        rows.append({(k or "").strip().lower(): (v.strip() if isinstance(v, str) else v) for k, v in row.items()})
    header = [(h or "").strip().lower() for h in (rdr.fieldnames or [])]
    return header, rows
