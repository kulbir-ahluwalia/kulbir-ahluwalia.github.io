"""Helpers, the result model and the settings loader (no ROS, no student code)."""
from __future__ import annotations

import copy
import hashlib
import math
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

PKG_DIR = Path(__file__).resolve().parent
SPEC_FILE = PKG_DIR / "spec_option_c_v1.yaml"
POLICY_FILE = PKG_DIR / "policy_defaults.yaml"


# ---------------------------------------------------------------------------------------------- numbers
def fnum(x, nd: int = 2) -> str:
    """Compact number: no trailing zeros beyond what is needed; 'n/a' for None."""
    if x is None:
        return "n/a"
    if isinstance(x, bool):
        return "true" if x else "false"
    if isinstance(x, int):
        return str(x)
    try:
        xf = float(x)
    except (TypeError, ValueError):
        return str(x)
    if math.isnan(xf) or math.isinf(xf):
        return str(xf)
    text = f"{xf:.{nd}f}"
    if "." in text:
        text = text.rstrip("0").rstrip(".")
    return text if text not in ("-0", "") else "0"


def pts(x: float) -> str:
    return f"{float(x):.2f}"


def round_score(x: float) -> float:
    return round(float(x) + 1e-12, 2)


def clip01(x: float) -> float:
    if x is None or (isinstance(x, float) and math.isnan(x)):
        return 0.0
    return min(max(float(x), 0.0), 1.0)


def linear_credit(value, zero: float, full: float) -> float:
    """0 at or below `zero`, 1 at or above `full`, linear in between."""
    if value is None:
        return 0.0
    if full <= zero:
        return 1.0 if value >= full else 0.0
    return clip01((float(value) - zero) / (full - zero))


def sha256_file(path, chunk: int = 1 << 20) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        while True:
            block = fh.read(chunk)
            if not block:
                break
            h.update(block)
    return h.hexdigest()


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


class Deadline:
    def __init__(self, seconds: float):
        self.start = time.monotonic()
        self.seconds = float(seconds)

    def elapsed(self) -> float:
        return time.monotonic() - self.start

    def expired(self) -> bool:
        return self.elapsed() > self.seconds


# ---------------------------------------------------------------------------------------------- results
@dataclass
class Element:
    label: str
    points: float
    earned: float
    measured: str
    threshold: str
    fix: str | None = None
    scope: str = ""

    @property
    def status(self) -> str:
        if self.points <= 0:
            return "INFO"
        if self.earned >= self.points - 1e-9:
            return "PASS"
        if self.earned > 1e-9:
            return "PARTIAL"
        return "FAIL"


@dataclass
class Outcome:
    test_id: str
    name: str
    max_score: float
    number: str = ""
    elements: list = field(default_factory=list)
    notes: list = field(default_factory=list)
    warnings: list = field(default_factory=list)
    extra: dict = field(default_factory=dict)
    error: str | None = None
    visibility: str = "visible"
    bonus_value: float | None = None       # AG-B1: value computed for the bonus question
    award_bonus: bool = False              # policy bonus_mode = extra_credit

    def element(self, label: str, points: float, fraction: float, measured: str, threshold: str,
                fix: str | None = None, scope: str = "") -> Element:
        fraction = clip01(fraction)
        el = Element(label, float(points), float(points) * fraction, measured, threshold,
                     fix if fraction < 1.0 - 1e-9 else None, scope)
        self.elements.append(el)
        return el

    def info(self, label: str, measured: str, threshold: str = "information only", scope: str = "") -> None:
        self.elements.append(Element(label, 0.0, 0.0, measured, threshold, None, scope))

    def note(self, text: str) -> None:
        if text and text not in self.notes:
            self.notes.append(text)

    def warn(self, text: str) -> None:
        if text and text not in self.warnings:
            self.warnings.append(text)

    @property
    def raw(self) -> float:
        return sum(e.earned for e in self.elements)

    @property
    def score(self) -> float:
        if self.award_bonus and self.bonus_value is not None:
            return round_score(max(self.bonus_value, 0.0))
        return round_score(min(max(self.raw, 0.0), self.max_score))

    @property
    def status(self) -> str:
        if self.max_score <= 0:
            return "passed" if not self.error else "failed"
        return "passed" if self.score >= self.max_score - 1e-9 else "failed"

    def render(self) -> str:
        if self.max_score > 0:
            lines = [f"Score: {pts(self.score)} / {pts(self.max_score)}"]
        elif self.bonus_value is not None:
            lines = [f"Bonus value (auto part, enter in the bonus question): {pts(self.bonus_value)}"]
        else:
            lines = ["Information only (0 points)"]
        scope = None
        for e in self.elements:
            if e.scope and e.scope != scope:
                lines.append(f"-- {e.scope}")
                scope = e.scope
            pts_txt = f" ({fnum(e.earned)}/{fnum(e.points)} pts)" if e.points > 0 else ""
            lines.append(f"[{e.status}] {e.label}{pts_txt}")
            lines.append(f"    measured: {e.measured}")
            lines.append(f"    required: {e.threshold}")
            if e.fix:
                lines.append(f"    how to fix: {e.fix}")
        if self.error:
            lines.append(f"[ERROR] {self.error}")
        for w in self.warnings:
            lines.append(f"[WARNING] {w}")
        for n in self.notes:
            lines.append(f"[NOTE] {n}")
        return "\n".join(lines)


# ---------------------------------------------------------------------------------------------- settings
def deep_merge(base: Any, override: Any) -> Any:
    if isinstance(base, dict) and isinstance(override, dict):
        out = dict(base)
        for k, v in override.items():
            out[k] = deep_merge(base.get(k), v) if k in base else copy.deepcopy(v)
        return out
    return copy.deepcopy(override)


def load_yaml(path: Path):
    import yaml
    with open(path, "r", encoding="utf-8") as fh:
        return yaml.safe_load(fh)


class Settings:
    """Frozen spec (spec_option_c_v1.yaml) + policy defaults (policy_defaults.yaml) + optional overrides
    (the Gradescope config.yaml section autograder_overrides.a4_ec_mars_helicopter)."""

    def __init__(self, overrides: dict | None = None):
        self.spec = load_yaml(SPEC_FILE)
        self.spec_sha256 = sha256_file(SPEC_FILE)
        defaults = load_yaml(POLICY_FILE) or {}
        self.impl = deep_merge(defaults, overrides) if overrides else defaults
        self.assignment = self.spec["assignment"]
        self._tests = {t["id"]: t for t in (self.spec.get("auto_tests") or []) + (self.spec.get("bonus_tests") or [])}

    # tests
    def auto_tests(self) -> list:
        return list(self.spec.get("auto_tests") or [])

    def bonus_tests(self) -> list:
        return list(self.spec.get("bonus_tests") or [])

    def manual_items(self) -> list:
        return list(self.spec.get("manual_items") or [])

    def bonus_items(self) -> list:
        return list(self.spec.get("bonus_items") or [])

    def test(self, tid: str) -> dict:
        return self._tests[tid]

    def points(self, tid: str) -> float:
        return float(self._tests[tid].get("points") or 0.0)

    def el(self, tid: str, name: str) -> float:
        return float((self._tests[tid].get("elements") or {})[name])

    def th(self, tid: str) -> dict:
        return dict(self._tests[tid].get("thresholds") or {})

    def auto_points(self) -> float:
        return round(sum(float(t.get("points") or 0) for t in self.auto_tests()), 2)

    def manual_points(self) -> float:
        return round(sum(float(m.get("points") or 0) for m in self.manual_items()), 2)

    # rules
    def world(self, key: str):
        return self.spec["world"][key]

    def bag_rule(self, key: str):
        return self.spec["bag_rules"][key]

    def grid(self, name: str) -> dict:
        return dict(self.spec["grids"][name])

    def camera(self, name: str) -> dict:
        return dict(self.spec["cameras"][name])

    def lethal(self) -> int:
        return int(self.spec["grids"]["lethal_min"])

    def required_topics(self, condition: str) -> dict:
        rt = self.spec["required_topics"]
        out = dict(rt["common"])
        if condition in ("orbit_scout", "orbit_scout_drift"):
            out.update(rt["orbit_scout"])
        if condition == "orbit_scout_drift":
            out.update(rt["drift"])
        return out

    def may_be_empty(self) -> set:
        return set(self.spec["required_topics"].get("may_be_empty") or [])

    def policy(self, name: str, default=None):
        return (self.impl.get("policies") or {}).get(name, default)

    def limit(self, name: str, default=None):
        return (self.impl.get("limits") or {}).get(name, default)

    def timebase(self, name: str, default=None):
        return (self.impl.get("timebase") or {}).get(name, default)

    def validate(self) -> list:
        problems = []
        a = self.assignment
        if abs(self.auto_points() - float(a["auto_points"])) > 1e-6:
            problems.append(f"auto test points {self.auto_points()} != spec auto_points {a['auto_points']}")
        if abs(self.manual_points() - float(a["manual_points"])) > 1e-6:
            problems.append(f"manual points {self.manual_points()} != spec manual_points {a['manual_points']}")
        if abs(float(a["auto_points"]) + float(a["manual_points"]) - float(a["total_points"])) > 1e-6:
            problems.append("auto + manual != total_points")
        for t in self.auto_tests() + self.bonus_tests():
            els = t.get("elements")
            if els and abs(sum(float(v) for v in els.values()) - float(t.get("points") or 0)) > 1e-6:
                problems.append(f"{t['id']}: element points do not add up to the test points")
        bonus = sum(float(t.get("points") or 0) for t in self.bonus_tests()) + sum(
            float(b.get("points") or 0) for b in self.bonus_items())
        if abs(bonus - float(a["bonus_points"])) > 1e-6:
            problems.append(f"bonus points {bonus} != spec bonus_points {a['bonus_points']}")
        return problems
