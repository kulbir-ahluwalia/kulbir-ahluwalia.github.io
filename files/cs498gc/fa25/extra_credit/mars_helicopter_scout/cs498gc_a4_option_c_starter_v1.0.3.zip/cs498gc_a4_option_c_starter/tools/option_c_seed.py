#!/usr/bin/env python3
"""option_c_seed.py: print your three CS 498 GC A4 Option C world seeds (stdlib only).

  python3 option_c_seed.py --netid yournetid
  ros2 run cs498gc_a4_option_c_starter option_c_seed --netid yournetid

seed_k = int(sha256(('cs498gc-a4c:' + netid.strip().lower() + ':' + str(k)).encode()).hexdigest()[:8], 16)
for k = 0, 1, 2. Practice seed 7 is free to use and is never graded.
"""
import argparse
import hashlib
import json
import sys


def seeds_for(netid):
    nid = netid.strip().lower()
    return [int(hashlib.sha256(("cs498gc-a4c:" + nid + ":" + str(k)).encode()).hexdigest()[:8], 16)
            for k in range(3)]


def main(argv=None):
    ap = argparse.ArgumentParser(description="print the three Option C world seeds for a NetID")
    ap.add_argument("--netid", required=True)
    ap.add_argument("--json", action="store_true", help="print JSON instead of text")
    a = ap.parse_args(argv)
    s = seeds_for(a.netid)
    if a.json:
        print(json.dumps({"netid": a.netid.strip().lower(), "seeds": s}))
    else:
        for k, v in enumerate(s):
            print("seed_%d = %d" % (k, v))
        print("config/option_c.yaml:  seeds: [%d, %d, %d]" % tuple(s))
    return 0


if __name__ == "__main__":
    sys.exit(main())
