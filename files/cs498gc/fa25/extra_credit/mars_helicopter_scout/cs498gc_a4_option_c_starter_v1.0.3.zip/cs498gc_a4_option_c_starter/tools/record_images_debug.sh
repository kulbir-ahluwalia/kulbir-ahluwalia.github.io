#!/usr/bin/env bash
# record_images_debug.sh: record the camera images for YOUR OWN debugging (never submit this bag).
#
#   record_images_debug.sh <name> [output_parent_dir]
#
# Writes <output_parent_dir>/<name>_images/ (default parent: ./debug_bags), sqlite3 storage, with
#   /ingenuity/nadir_cam/image, /ingenuity/nadir_cam/camera_info, /orbiter/bev_cam/image,
#   /orbiter/bev_cam/camera_info, /model/ingenuity_quad_approx/odometry, /option_c/clock_20hz
# so you can replay a flight and develop the mosaicker offline:
#   ros2 bag play <dir> --clock 20      (or read it with rosbag2_py)
# Graded bags come from record_option_c_bag.sh, which refuses image topics. Expect about 0.65 MB
# per second of sim time (the M0 hello_sortie run on seed 7, 116 s of sim time, made a 74 MB bag).
# The spec names this script scripts/record_images_debug.sh; it ships in tools/ with the others.
set -u
if [ $# -lt 1 ] || [ $# -gt 2 ]; then
  echo "usage: $0 <name> [output_parent_dir]" >&2
  exit 2
fi
NAME=$1
PARENT=${2:-debug_bags}
case "$NAME" in ''|*/*) echo "name must be a plain folder name" >&2; exit 2;; esac
if ! command -v ros2 >/dev/null 2>&1; then
  echo "ros2 not found: source /opt/ros/<distro>/setup.bash and your workspace first" >&2
  exit 4
fi
OUT="$PARENT/${NAME}_images"
if [ -e "$OUT" ]; then
  echo "REFUSED: $OUT already exists" >&2
  exit 5
fi
mkdir -p "$PARENT"
TOPICS=(
  /ingenuity/nadir_cam/image
  /ingenuity/nadir_cam/camera_info
  /orbiter/bev_cam/image
  /orbiter/bev_cam/camera_info
  /model/ingenuity_quad_approx/odometry
  /option_c/clock_20hz
)
echo "[record_images_debug] -> $OUT (debug only, do not submit)"
# Foreground recorder (Ctrl-C reaches it); this shell only runs a no-op trap.
trap ':' INT TERM
ros2 bag record -s sqlite3 -o "$OUT" "${TOPICS[@]}"
trap - INT TERM
if [ -d "$OUT" ]; then
  BYTES=$(du -sb "$OUT" 2>/dev/null | cut -f1)
  echo "[record_images_debug] wrote $OUT ($(awk -v b="${BYTES:-0}" 'BEGIN{printf "%.1f", b/1048576}') MiB)"
fi
exit 0
