#!/usr/bin/env bash
# record_option_c_bag.sh: record a graded CS 498 GC A4 Option C bag (exact topic list, sqlite3).
#
#   record_option_c_bag.sh <seed> <orbit_only|orbit_scout|orbit_scout_drift> [output_parent_dir]
#
# Writes <output_parent_dir>/seed<seed>_<condition>/ (default parent: ./bags). Order of a graded run:
#   1. start the world launch;
#   2. start this recorder and wait for its line "[record_option_c_bag] READY ...": rosbag2 has then
#      subscribed to every graded topic that is published (typically 4 to 10 s);
#   3. only then launch your mission nodes; 4. stop the recorder with Ctrl-C after the rover finishes.
# Even with this order rosbag2 needs 1 to 3 s to discover a new node, so publish your event and path
# topics (/option_c/mission_phase, /option_c/rover/active_path, /option_c/sortie_plan, plus the
# costmaps and paths that are already transient_local) with transient_local durability and enough
# depth: rosbag2 then receives what they sent before it subscribed (docs/TOPICS.md, "Durability").
# It records exactly the required topic list with -s sqlite3. It refuses image topics and raw
# /clock (they would blow the 25 MB limit); the grader recomputes coverage from camera_info stamps
# and maps headerless messages to sim time through /option_c/clock_20hz.
# Extra arguments after the third are refused on purpose: graded bags must have this topic list.
set -u
USAGE="usage: record_option_c_bag <seed> <orbit_only|orbit_scout|orbit_scout_drift> [output_parent_dir]"
case "${1:-}" in
  -h|--help)
    # print the header comment above (without the leading '# ') as the help text
    sed -n '2,/^set -u$/p' "${BASH_SOURCE[0]}" | sed '$d' | sed 's/^# \{0,1\}//'
    echo "$USAGE"
    exit 0 ;;
esac
if [ $# -lt 2 ] || [ $# -gt 3 ]; then
  echo "$USAGE   (record_option_c_bag --help for details)" >&2
  exit 2
fi
SEED=$1
COND=$2
PARENT=${3:-bags}
case "$SEED" in ''|*[!0-9]*) echo "seed must be a non-negative integer" >&2; exit 2;; esac

COMMON=(
  /option_c/clock_20hz
  /option_c/run_info
  /orbiter/bev_cam/camera_info
  /option_c/grader/scout_odom
  /option_c/rover/odom_truth
  /option_c/rover/cmd_vel_request
  /option_c/rover/cmd_vel
  /option_c/rover/hazcam
  /option_c/rover/hazard_stop
  /option_c/rover/active_path
  /option_c/orbital_costmap
  /option_c/orbital_path
  /option_c/mission_phase
  /option_c/scout/watchdog_events
)
SCOUT=(
  /ingenuity/nadir_cam/camera_info
  /ingenuity/gazebo/command/twist
  /ingenuity/enable
  /option_c/scout/cmd_vel
  /option_c/sortie_plan
  /option_c/fused_costmap
  /option_c/fused_path
)
DRIFT=(
  /ingenuity/odom_est
  /ingenuity/nav_status
  /option_c/scout/registration_offset
)
# Topics published by TA nodes of the world launch (the READY check waits for these); every other
# recorded topic is published by your mission.
TA_PUBLISHED=(
  /option_c/clock_20hz /option_c/run_info /orbiter/bev_cam/camera_info /option_c/grader/scout_odom
  /option_c/rover/odom_truth /option_c/rover/cmd_vel /option_c/rover/hazcam /option_c/rover/hazard_stop
  /option_c/scout/watchdog_events /ingenuity/nadir_cam/camera_info /ingenuity/gazebo/command/twist
  /ingenuity/odom_est /ingenuity/nav_status
)
case "$COND" in
  orbit_only)        TOPICS=("${COMMON[@]}") ;;
  orbit_scout)       TOPICS=("${COMMON[@]}" "${SCOUT[@]}") ;;
  orbit_scout_drift) TOPICS=("${COMMON[@]}" "${SCOUT[@]}" "${DRIFT[@]}") ;;
  *) echo "condition must be orbit_only, orbit_scout or orbit_scout_drift" >&2; exit 2 ;;
esac

# Belt and braces: never record images or raw /clock.
for t in "${TOPICS[@]}"; do
  case "$t" in
    /clock|*/image|*/image_raw|*image*compressed*) echo "REFUSED: $t is an image topic or raw /clock" >&2; exit 3 ;;
  esac
done

if ! command -v ros2 >/dev/null 2>&1; then
  echo "ros2 not found: source /opt/ros/<distro>/setup.bash and your workspace first" >&2
  exit 4
fi

OUT="$PARENT/seed${SEED}_${COND}"
if [ -e "$OUT" ]; then
  echo "REFUSED: $OUT already exists (move or delete it first; bags are never overwritten)" >&2
  exit 5
fi
mkdir -p "$PARENT"
echo "[record_option_c_bag] seed=$SEED condition=$COND -> $OUT"
echo "[record_option_c_bag] ${#TOPICS[@]} topics: ${TOPICS[*]}"
echo "[record_option_c_bag] wait for the READY line below before you launch your mission nodes"
echo "[record_option_c_bag] press Ctrl-C to stop after the rover finishes"

# The recorder runs in the FOREGROUND: Ctrl-C reaches it directly and it closes the sqlite3 file
# cleanly. (A recorder started with '&' inside a script ignores SIGINT, so Ctrl-C did not stop
# it in an early test version.) This shell only runs a no-op trap, so it survives Ctrl-C and
# prints the summary. Its output goes through recorder_ready_watch.py, which copies every line,
# prints the READY line, ignores Ctrl-C and reads until the recorder closes the pipe.
WATCH="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/recorder_ready_watch.py"
join_csv() { local IFS=,; echo "$*"; }
trap ':' INT TERM
if [ -f "$WATCH" ] && command -v python3 >/dev/null 2>&1; then
  ros2 bag record -s sqlite3 -o "$OUT" "${TOPICS[@]}" 2>&1 \
    | python3 -u "$WATCH" --tag record_option_c_bag --topics "$(join_csv "${TOPICS[@]}")" \
        --ta "$(join_csv "${TA_PUBLISHED[@]}")"
  RC=${PIPESTATUS[0]}
else
  echo "[record_option_c_bag] WARNING: $WATCH or python3 not found, so there is no READY line: wait until" \
       "rosbag2 has printed 'Subscribed to topic' for every TA topic (about 10 s) before you launch your mission" >&2
  ros2 bag record -s sqlite3 -o "$OUT" "${TOPICS[@]}"
  RC=$?
fi
trap - INT TERM

if [ -d "$OUT" ]; then
  BYTES=$(du -sb "$OUT" 2>/dev/null | cut -f1)
  MB=$(awk -v b="${BYTES:-0}" 'BEGIN{printf "%.2f", b/1048576}')
  echo "[record_option_c_bag] wrote $OUT ($MB MiB)"
  if [ "${BYTES:-0}" -gt 25000000 ]; then
    echo "[record_option_c_bag] WARNING: larger than 25 MB (25,000,000 bytes); the grader rejects it (AG-03)" >&2
  fi
  ros2 bag info "$OUT" 2>/dev/null | head -n 60
fi
exit 0
