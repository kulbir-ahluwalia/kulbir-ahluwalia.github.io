#!/usr/bin/env python3
"""Print one READY line once the graded recorder is really recording (used by record_option_c_bag.sh).

    ros2 bag record ... 2>&1 | python3 -u recorder_ready_watch.py --tag record_option_c_bag \
        --topics /a,/b,... --ta /a,...

It copies the recorder's output to stdout unchanged, line by line, and adds lines of its own that
start with "[<tag>]". READY means:

  * rosbag2 printed "All requested topics are subscribed", or
  * rosbag2 has subscribed to /option_c/run_info and /option_c/clock_20hz (the world is up), to
    every recorded topic that has a publisher in the ROS graph right now (a small helper node
    looks), the picture has not changed for 2 s, and at least 4 s have passed. A TA topic with no
    publisher holds READY back for 20 s (a world launch can take that long to bring every TA node
    up); after that READY is printed with a warning naming it.

Without rclpy (no graph view) READY needs the two world topics, 8 s and 3 s without a new
subscription, and says so. Student topics that already have publishers when READY is printed mean
the mission was started before the recorder: only messages from transient_local publishers sent
before that moment reach the bag (TOPICS.md, "Durability").

The watcher ignores SIGINT (Ctrl-C stops the recorder, which then closes the bag and ends the
pipe) and never stops reading its input early, so the recorder can never die of a broken pipe.
"""
from __future__ import annotations

import argparse
import os
import queue
import re
import signal
import sys
import threading
import time

WORLD_TOPICS = ("/option_c/run_info", "/option_c/clock_20hz")
SUB_RE = re.compile(r"Subscribed to topic '([^']+)'")
ALL_RE = re.compile(r"All requested topics are subscribed")
MIN_WAIT_S = 4.0
SETTLE_S = 2.0
TA_GRACE_S = 20.0
NO_GRAPH_MIN_S = 8.0
NO_GRAPH_QUIET_S = 3.0
STATUS_EVERY_S = 10.0


class ReadyState:
    """Decision logic, kept free of ROS so it can be unit tested."""

    def __init__(self, topics, ta, t0):
        self.topics = list(dict.fromkeys(topics))
        self.ta = set(ta) & set(self.topics)
        self.student = [t for t in self.topics if t not in self.ta]
        self.t0 = t0
        self.subscribed = set()
        self.all_seen = False
        self.last_sub_t = t0
        self.last_change_t = t0
        self._last_key = None
        self.ready = False

    def observe(self, line, now):
        m = SUB_RE.search(line)
        if m and m.group(1) in self.topics and m.group(1) not in self.subscribed:
            self.subscribed.add(m.group(1))
            self.last_sub_t = now
            self.last_change_t = now
        if ALL_RE.search(line):
            self.all_seen = True

    def evaluate(self, now, existing):
        """existing: set of recorded topics with >= 1 publisher, or None without a graph view.
        Returns None (not ready yet) or a dict describing the READY decision."""
        if self.ready:
            return None
        if self.all_seen:
            return self._mark(now, "all", existing)
        elapsed = now - self.t0
        world_ok = all(t in self.subscribed for t in WORLD_TOPICS if t in self.topics)
        if existing is None:
            if world_ok and elapsed >= NO_GRAPH_MIN_S and now - self.last_sub_t >= NO_GRAPH_QUIET_S:
                return self._mark(now, "no_graph", None)
            return None
        key = (frozenset(existing), frozenset(self.subscribed))
        if key != self._last_key:
            self._last_key = key
            self.last_change_t = now
        unsubscribed = [t for t in self.topics if t in existing and t not in self.subscribed]
        ta_absent = [t for t in self.topics if t in self.ta and t not in existing and t not in self.subscribed]
        if not world_ok or unsubscribed or elapsed < MIN_WAIT_S or now - self.last_change_t < SETTLE_S:
            return None
        if ta_absent and elapsed < TA_GRACE_S:
            return None
        return self._mark(now, "graph", existing, ta_absent)

    def _mark(self, now, how, existing, ta_absent=()):
        self.ready = True
        early = sorted(t for t in self.student if existing is not None and t in existing)
        if how == "all":
            early = sorted(t for t in self.student if t in self.subscribed)
        return {"t": now - self.t0, "how": how, "n_sub": len(self.subscribed), "n": len(self.topics),
                "early_student": early, "ta_absent": list(ta_absent)}

    def status(self, now, existing):
        world_missing = [t for t in WORLD_TOPICS if t in self.topics and t not in self.subscribed]
        parts = ["subscribed %d of %d" % (len(self.subscribed), len(self.topics))]
        if world_missing:
            parts.append("waiting for the world topics %s (is the world launch running in this "
                         "ROS_DOMAIN_ID?)" % ", ".join(world_missing))
        if existing is not None:
            pend = [t for t in self.topics if t in existing and t not in self.subscribed]
            if pend:
                parts.append("not yet subscribed although published: %s" % ", ".join(pend))
            absent = [t for t in self.topics if t in self.ta and t not in existing and t not in self.subscribed]
            if absent:
                parts.append("TA topics with no publisher yet: %s" % ", ".join(absent))
        return "; ".join(parts)


class Graph:
    """Counts publishers per topic through a small rclpy node (no spinning needed)."""

    def __init__(self):
        self.node = None
        self.err = None
        try:
            import rclpy
            from rclpy.node import Node
            self._rclpy = rclpy
            try:
                from rclpy.signals import SignalHandlerOptions
                rclpy.init(args=None, signal_handler_options=SignalHandlerOptions.NO)
            except (ImportError, TypeError):
                rclpy.init(args=None)
            self.node = Node("option_c_recorder_ready_%d" % os.getpid(), enable_rosout=False,
                             start_parameter_services=False)
        except Exception as exc:  # noqa: BLE001
            self.err = "%s: %s" % (type(exc).__name__, str(exc)[:120])
            self.node = None

    def existing(self, topics):
        if self.node is None:
            return None
        try:
            return {t for t in topics if len(self.node.get_publishers_info_by_topic(t)) > 0}
        except Exception as exc:  # noqa: BLE001
            self.err = "%s: %s" % (type(exc).__name__, str(exc)[:120])
            self.close()
            return None

    def close(self):
        try:
            if self.node is not None:
                self.node.destroy_node()
            self.node = None
            self._rclpy.try_shutdown()
        except Exception:  # noqa: BLE001
            pass


def _say(tag, text):
    _out("[%s] %s\n" % (tag, text))


_OUT_OK = [True]


def _out(text):
    if not _OUT_OK[0]:
        return
    try:
        sys.stdout.write(text)
        sys.stdout.flush()
    except (BrokenPipeError, OSError, ValueError):
        _OUT_OK[0] = False   # keep reading the input anyway: the recorder must never see a broken pipe


def _reader(q):
    stream = sys.stdin.buffer
    while True:
        try:
            raw = stream.readline()
        except Exception:  # noqa: BLE001
            raw = b""
        if not raw:
            q.put(None)
            return
        q.put(raw.decode("utf-8", "replace"))


def main(argv=None):
    signal.signal(signal.SIGINT, signal.SIG_IGN)
    try:
        signal.signal(signal.SIGPIPE, signal.SIG_IGN)
    except (AttributeError, ValueError):
        pass
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--tag", default="record_option_c_bag")
    ap.add_argument("--topics", required=True, help="comma-separated recorded topics")
    ap.add_argument("--ta", default="", help="comma-separated topics published by TA nodes")
    args = ap.parse_args(argv)
    topics = [t for t in args.topics.split(",") if t]
    ta = [t for t in args.ta.split(",") if t]

    q = queue.Queue()
    th = threading.Thread(target=_reader, args=(q,), daemon=True)
    th.start()

    t0 = time.monotonic()
    st = ReadyState(topics, ta, t0)
    graph = None if os.environ.get("OPTION_C_READY_NO_GRAPH") == "1" else Graph()
    if graph is not None and graph.node is None:
        _say(args.tag, "note: no ROS graph view for the READY check (%s); using the subscription log only"
             % graph.err)
        graph = None
    try:
        # rclpy.init may have installed its own SIGINT handler: keep Ctrl-C for the recorder only.
        signal.signal(signal.SIGINT, signal.SIG_IGN)
    except ValueError:
        pass
    next_status = t0 + STATUS_EVERY_S
    while True:
        try:
            line = q.get(timeout=0.5)
        except queue.Empty:
            line = ""
        now = time.monotonic()
        if line is None:
            break
        if line:
            _out(line if line.endswith("\n") else line + "\n")
            st.observe(line, now)
        if st.ready:
            continue
        existing = graph.existing(topics) if graph is not None else None
        if graph is not None and existing is None:
            _say(args.tag, "note: the ROS graph view failed (%s); using the subscription log only" % graph.err)
            graph = None
        res = st.evaluate(now, existing)
        if res is None:
            if now >= next_status:
                _say(args.tag, "not READY yet after %.0f s: %s" % (now - t0, st.status(now, existing)))
                next_status = now + STATUS_EVERY_S
            continue
        if res["how"] == "no_graph":
            msg = ("READY after %.1f s: subscribed to %d of %d topics, none new for %.0f s (no ROS graph view, so "
                   "topics that exist but were not discovered yet cannot be ruled out)"
                   % (res["t"], res["n_sub"], res["n"], NO_GRAPH_QUIET_S))
        else:
            rest = res["n"] - res["n_sub"]
            msg = ("READY after %.1f s: subscribed to %d of %d topics%s"
                   % (res["t"], res["n_sub"], res["n"],
                      "" if rest == 0 else ", every one that has a publisher now; the other %d (your mission "
                      "topics) are added when their publishers appear" % rest))
        _say(args.tag, msg + ". Start your mission nodes now.")
        if res["ta_absent"]:
            _say(args.tag, "WARNING: TA topics with no publisher after %.0f s: %s. They will be missing from the "
                 "bag unless they appear later: check the world launch and its condition." % (TA_GRACE_S, ", ".join(res["ta_absent"])))
        if res["early_student"]:
            _say(args.tag, "WARNING: these student topics already had publishers when the recorder started: %s. "
                 "Your mission seems to be running already. Messages sent before now are in the bag only if "
                 "their publishers use transient_local durability (TOPICS.md, Durability); for a clean graded "
                 "bag restart the mission after READY." % ", ".join(res["early_student"]))
        if graph is not None:
            graph.close()
            graph = None
    if graph is not None:
        graph.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
